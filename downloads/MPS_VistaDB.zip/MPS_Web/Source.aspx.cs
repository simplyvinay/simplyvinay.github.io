﻿using System;

namespace MPS.UI
{
    public partial class Source : PageBase
    {

		#region Methods (1) 


		// Protected Methods (1) 

        protected void Page_Load(object sender, EventArgs e)
        {

        }


		#endregion Methods 

    }
}