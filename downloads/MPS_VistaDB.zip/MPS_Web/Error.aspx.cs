using System;

namespace MPS.UI
{
    public partial class Error : PageBase
    {

		#region�Methods�(1)�


		//�Protected�Methods�(1)�

        protected void Page_Load(object sender, EventArgs e)
        {
            lbl404.Visible = (this.Request.QueryString["code"] != null && this.Request.QueryString["code"] == "404");
            lbl408.Visible = (this.Request.QueryString["code"] != null && this.Request.QueryString["code"] == "408");
            lbl505.Visible = (this.Request.QueryString["code"] != null && this.Request.QueryString["code"] == "505");
            lblError.Visible = (string.IsNullOrEmpty(this.Request.QueryString["code"]));

        }


		#endregion�Methods�

    }
}