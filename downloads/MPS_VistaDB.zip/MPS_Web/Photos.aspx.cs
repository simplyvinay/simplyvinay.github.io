﻿using System;
using MPS.BLL.PhotoGallery;

namespace MPS.UI
{
    public partial class Photos : PageBase
    {

		#region Fields (1) 

        private int albumID = 0;

		#endregion Fields 

		#region Methods (2) 


		// Protected Methods (2) 

        protected void Page_Init(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["AlbumID"] != null)
                {
                    albumID = Convert.ToInt32(Request.QueryString["AlbumID"]);
                }
                objPhotos.SelectParameters.Add("albumID", albumID.ToString());
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["AlbumID"] != null)
            {
                albumID = Convert.ToInt32(Request.QueryString["AlbumID"]);
            }
            else
            {
                if (string.IsNullOrEmpty(Request.QueryString["AlbumID"]))
                    throw new ApplicationException("Missing parameter on the querystring.");
                else
                    albumID = int.Parse(Request.QueryString["AlbumID"]);
            }

            // try to load the album with the specified ID, and raise an exception
            // if it doesn't exist
            Album album = Album.GetAlbumsByID(albumID);
            if (album == null)
                throw new ApplicationException("No album was found for the specified ID.");
            else
            {
                int photoCount = Photo.GetPhotoCount(albumID);
                lblHead.Text = string.Format(lblHead.Text, album.Caption, photoCount.ToString());
            }

            // if the album has the IsPublic = false, and the current user is anonymous,
            // redirect to the login page
            if (!album.IsPublic && !User.Identity.IsAuthenticated)
                RequestLogin();

        }


		#endregion Methods 

    }
}
