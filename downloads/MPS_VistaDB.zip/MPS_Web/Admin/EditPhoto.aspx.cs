﻿using System;
using MPS.BLL.PhotoGallery;

namespace MPS.UI
{
    public partial class Admin_EditPhoto : PageBase
    {

		#region Methods (2) 


		// Protected Methods (2) 

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            int photoID = 0;
            photoID = int.Parse(Request.QueryString["ID"]);
            Photo photo = Photo.GetPhotoByID(photoID);
            if (photo != null)
            {
                if (Photo.UpdatePhoto(photo.Id, photo.AlbumID, txtCaption.Text.Trim(), photo.Location))
                {
                    lblMsg.Visible = true;
                    lblMsg.Text = "Photo updated successfully";
                }
                else
                {
                    lblMsg.Visible = true;
                    lblMsg.Text = "There was a problem updating the photo";
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int photoID = 0;
                photoID = int.Parse(Request.QueryString["ID"]);
                Photo photo = Photo.GetPhotoByID(photoID);
                if (photo != null)
                {
                    txtCaption.Text = photo.PhotoCaption.ToString();
                    imgP.ImageUrl = "~/Handler.ashx?PhotoID=" + photoID + "&Size=M";
                }
            }
        }


		#endregion Methods 

    }
}
