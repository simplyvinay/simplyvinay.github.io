﻿using System;
using System.Web.UI.WebControls;

namespace MPS.UI
{
    public partial class Admin_AddEditBlog : PageBase
    {

		#region Methods (4) 


		// Protected Methods (3) 

        protected void dvwBlog_DataBound(object sender, EventArgs e)
        {
            // Tn InserMode, preselect the checkboxes to make the article listed and to allow comments
            // The Approved checkbox is selected and enabled only if the user belongs to the
            // Administrators group.
            if (dvwBlog.CurrentMode == DetailsViewMode.Insert)
            {
                CheckBox chkApproved = dvwBlog.FindControl("chkApproved") as CheckBox;
                CheckBox chkCommentsEnabled = dvwBlog.FindControl("chkCommentsEnabled") as CheckBox;

                chkCommentsEnabled.Checked = true;

                bool canApprove = (User.IsInRole("Administrators"));
                chkApproved.Enabled = canApprove;
                chkApproved.Checked = canApprove;
            }
        }

        protected void dvwBlog_ModeChanged(object sender, EventArgs e)
        {
            UpdateTitle();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // if a ID param is present on the querystring, switch to Edit mode for that blog,
                // but only after checking that the current user is an Administrator
                if (!string.IsNullOrEmpty(Request.QueryString["ID"]))
                {
                    if (User.Identity.IsAuthenticated &&
                        (User.IsInRole("Administrators")))
                    {
                        dvwBlog.ChangeMode(DetailsViewMode.Edit);
                        UpdateTitle();
                    }
                    else
                    {
                        //   throw new SecurityException("You are not allowed to edit existent articles!");
                    }
                }
            }
        }



		// Private Methods (1) 

        private void UpdateTitle()
        {
            lblNewBlog.Visible = (dvwBlog.CurrentMode == DetailsViewMode.Insert);
            lblEditBlog.Visible = !lblNewBlog.Visible;
        }


		#endregion Methods 

    }
}
