using System;
using System.Web.UI.HtmlControls;
using MPS.BLL.SiteSettings;

namespace MPS.UI
{
    public partial class MPSM : System.Web.UI.MasterPage
    {

		#region�Methods�(4)�


		//�Protected�Methods�(4)�

        protected void Login_LoggedIn(object sender, EventArgs e)
        {
            if (Helpers.URLRewritten(Request.Url.LocalPath))
            {
                if (Request.Url.PathAndQuery.Contains("ReturnUrl"))
                    Response.Redirect(Request.Params["ReturnUrl"].ToString());
                else
                    Response.Redirect(Request.Url.LocalPath);
            }
            else
            {
                if (Request.Url.PathAndQuery.Contains("ReturnUrl"))
                    Response.Redirect(Request.Params["ReturnUrl"].ToString());
                else
                    Response.Redirect(Request.Url.PathAndQuery);
            }
        }

        protected void LoginStatus1_LoggedOut(object sender, EventArgs e)
        {
            if (Helpers.URLRewritten(Request.Url.LocalPath))
            {
                Response.Redirect(Request.Url.LocalPath);
            }
            else
            {
                Response.Redirect(Request.Url.PathAndQuery);
            }
        }

        protected void menua_MenuItemDataBound(object sender, System.Web.UI.WebControls.MenuEventArgs e)
        {
            if (e.Item.Text == "Blog Entry")
            {
                e.Item.Parent.ChildItems.Remove(e.Item);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                SiteSettings settings = SiteSettings.GetSiteSettings(1);
                Head.HRef = "~/Default.aspx";
                Head.InnerHtml = settings.SiteName;
                lblSiteSlogan.Text = settings.SiteSlogan;
                lblFooter.Text = settings.Footer;

                HtmlMeta metaTag = new HtmlMeta();
                HtmlHead HeadTag = (HtmlHead)Page.Header;

                metaTag.Attributes.Add("name", "description");
                metaTag.Attributes.Add("content", settings.MetaDescription);
                HeadTag.Controls.Add(metaTag);

                metaTag = new HtmlMeta();
                metaTag.Attributes.Add("name", "keywords");
                metaTag.Attributes.Add("content", settings.MetaKeywords);
                HeadTag.Controls.Add(metaTag);



                Page.Title = settings.SitePageTitle + " | " + this.Page.Title;
            }
        }


		#endregion�Methods�

    }
}
