using System;
using System.Net.Mail;

namespace MPS.UI
{
    public partial class Contact : PageBase
    {

		#region�Methods�(3)�


		//�Protected�Methods�(3)�

        protected void btnSend_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                try
                {
                    // send the mail
                    MailMessage msg = new MailMessage();
                    msg.IsBodyHtml = true;
                    msg.From = new MailAddress(txtEmail.Text, txtName.Text);
                    msg.To.Add(new MailAddress(Globals.Settings.ContactForm.MailTo));
                    if (!string.IsNullOrEmpty(Globals.Settings.ContactForm.MailCC))
                        msg.CC.Add(new MailAddress(Globals.Settings.ContactForm.MailCC));
                    msg.Subject = string.Format(
                       Globals.Settings.ContactForm.MailSubject, txtSubject.Text);
                    msg.Body = "From : " + txtEmail.Text + "<br/>" + txtBody.Text;

                    SmtpClient smtp = new SmtpClient(Globals.Settings.Mail.Smtp,Globals.Settings.Mail.Port);
                    smtp.EnableSsl = true;

                    smtp.Credentials = new System.Net.NetworkCredential(Globals.Settings.Mail.Username,Globals.Settings.Mail.Password);
                    
                    smtp.Send(msg);

                    // show a confirmation message, and reset the fields
                    lblFeedbackOK.Visible = true;
                    lblFeedbackKO.Visible = false;
                    txtName.Text = "";
                    txtEmail.Text = "";
                    txtSubject.Text = "";
                    txtAntiBotImage.Text = "";
                    txtBody.Text = "";
                }
                catch (Exception ex)
                {
                    lblFeedbackOK.Visible = false;
                    lblFeedbackKO.Visible = true;
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void valAntiBotImage_ServerValidate(object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            args.IsValid = (Session["antibotimage"] != null) && (txtAntiBotImage.Text.Trim().ToUpper() == (string)Session["antibotimage"]);
        }


		#endregion�Methods�

    }
}
