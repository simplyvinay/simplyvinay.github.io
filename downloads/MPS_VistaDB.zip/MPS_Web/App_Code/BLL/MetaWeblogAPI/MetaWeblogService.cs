﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using CookComputing.XmlRpc;
using MPS.BLL.Blogs;
using MPS.BLL.MetaWeblogAPI.Blogger;
using MPS.BLL.MetaWeblogAPI.MetaWeblog;

namespace MPS.BLL.MetaWeblogAPI
{
	public class MetaWeblogService : XmlRpcService, IMetaWeblog, IBlogger
	{
        object IMetaWeblog.editPost(string postid, string username, string password, PostInfo postInfo, bool publish)
		{
			AssertCredentials(username, password);
            bool result = false;

            string catName = postInfo.categories[0];

            List<Category> catList = Category.GetCategories();
            Category cat = catList.Find(delegate(Category c) { return c.Description.Contains(catName); });

            if (cat != null)
            {
                result = Blog.UpdateBlog(Convert.ToInt32(postid), cat.Id, postInfo.title, postInfo.description, postInfo.dateCreated, publish, true, false);
            }
            else
            {
                int catId = Category.InsertCategory(catName, 0, catName);
                if (catId > 0)
                {
                    result = Blog.UpdateBlog(Convert.ToInt32(postid), catId, postInfo.title, postInfo.description, postInfo.dateCreated, publish, true, false);
                }
                else
                    throw new XmlRpcFaultException(0, "Unable to Post");
            }

            return result;
		}

		CategoryInfo[] IMetaWeblog.getCategories(string blogid, string username, string password)
		{
			AssertCredentials(username, password);
            List<CategoryInfo> categoryInfos = new List<CategoryInfo>();

            List<Category> catList = Category.GetCategories();

            foreach (Category cat in catList)
            {
                CategoryInfo c = new CategoryInfo();
                c.categoryid = cat.Id.ToString();
                c.description = cat.Description;
                c.title = cat.Title;
                c.htmlUrl = "http://www.simplyvinay.com/Category/" + cat.Id + "/Default.aspx";
                c.rssUrl = "http://www.simplyvinay.com/GetBlogRss.aspx?CatID=" + cat.Id;
                categoryInfos.Add(c);
            }

            return categoryInfos.ToArray();
		}

		PostInfo IMetaWeblog.getPost(string postid, string username, string password)
		{
			AssertCredentials(username, password);
            PostInfo post = new PostInfo();

            Blog b = Blog.GetBlogByID(Convert.ToInt32(postid));

            post.postid = b.Id;
            post.categories = new string[] { b.CategoryTitle };
            post.dateCreated = b.AddedDate;
            post.description = b.BlogText;
            post.title = b.BlogTitle;
            post.userid = username;

            return post;
		}

		PostInfo[] IMetaWeblog.getRecentPosts(string blogid, string username, string password, int numberOfPosts)
		{
			AssertCredentials(username, password);

            List<PostInfo> posts = new List<PostInfo>();

            List<Blog> blogList = Blog.GetBlogs(true, 0, numberOfPosts);

            foreach (Blog b in blogList)
            {
                PostInfo p = new PostInfo();
                p.categories = new string[] { b.CategoryTitle };
                p.dateCreated = b.AddedDate;
                p.description = b.BlogText;
                p.postid = b.Id;
                p.title = b.BlogTitle;
                p.userid = username;

                posts.Add(p);
            }

            return posts.ToArray();
		}

		string IMetaWeblog.newPost(string blogid, string username, string password, PostInfo postInfo, bool publish)
		{
			AssertCredentials(username, password);

            if (Roles.IsUserInRole(username, "Administrators"))
            {
                GenericIdentity gI = new GenericIdentity(username);
                GenericPrincipal gP = new GenericPrincipal(gI, new string[] { "Administrators" });
                this.Context.User = gP;
            }

            int id = 0;

            string catName = postInfo.categories[0];

            List<Category> catList = Category.GetCategories();
            Category cat = catList.Find(delegate(Category c) { return c.Title == catName; });

            if (cat != null)
            {
                id = Blog.InsertBlog(cat.Id, postInfo.title, postInfo.description, postInfo.dateCreated, publish, true, false);
            }
            else
            {
                int catId = Category.InsertCategory(catName, 0, catName);
                if (catId > 0)
                {
                    id = Blog.InsertBlog(catId, postInfo.title, postInfo.description, postInfo.dateCreated, publish, true, false);
                }
                else
                    throw new XmlRpcFaultException(0, "Unable to Post");
            }

            return id.ToString();
		}

		UrlData IMetaWeblog.newMediaObject(string blogid, string username, string password, FileData file)
		{
			AssertCredentials(username, password);

            UrlData urlInfo = new UrlData();

            String basePath = this.Context.Server.MapPath("~/images/blogimages/");
            String fixedName = file.name.Replace("/", "\\");
            FileInfo fi = new FileInfo(basePath + "\\" + fixedName);

            if (!fi.Exists)
            {
                if (!fi.Directory.Exists)
                {
                    fi.Directory.Create();
                }
                using (FileStream fs = fi.Create())
                {
                    fs.Write(file.bits, 0, file.bits.Length);
                }
            }

            urlInfo.url = GetBlogUrl() + "/images/blogimages/" + file.name.ToString();

            return urlInfo;

		}

		bool IBlogger.blogger_deletePost(string appKey, string postid, string username, string password, bool publish)
		{
			AssertCredentials(username, password);
            
            bool result = false;
            result = Blog.DeleteBlog(Convert.ToInt32(postid));
            return result;
		}

		BlogInfo[] IBlogger.blogger_getUsersBlogs(string appKey, string username, string password)
		{
			AssertCredentials(username, password);
			BlogInfo b = new BlogInfo();
			b.blogid = "1";
			b.blogName = "Vinay's Blog";
            b.url = GetBlogUrl();
			return new BlogInfo[] { b };
		}

		private void AssertCredentials(string username, string password)
		{
            bool result = Membership.ValidateUser(username, password);
            if(!result)
                throw new XmlRpcFaultException(0, "User is not valid!");
		}

        private static string GetBlogUrl()
        {
            HttpRequest request = HttpContext.Current.Request;
            return
                request.Url.Scheme + "://" +
                request.Url.Authority +
                request.ApplicationPath;
        }

		string IBlogger.blogger_getTemplate(string appKey, string blogid, string username, string password, string templateType)
		{
			//throw new NotImplementedException("IBlogger.blogger_getTemplate");
            return "";
		}


		bool IBlogger.blogger_setTemplate(string appKey, string blogid, string username, string password, string template, string templateType)
		{
			return true;
		}
	}
}
