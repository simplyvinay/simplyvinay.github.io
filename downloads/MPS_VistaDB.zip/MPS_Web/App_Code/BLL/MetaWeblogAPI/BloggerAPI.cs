using CookComputing.XmlRpc;

namespace MPS.BLL.MetaWeblogAPI.Blogger
{
	/// <summary>
	/// XmlRpc definitions for Blogger API methods and structures
	/// </summary>

	public struct BlogInfo
	{
		public string blogid;
		public string url;
		public string blogName;
	}

	public interface IBlogger
	{
		[XmlRpcMethod("blogger.deletePost", Description = "Deletes a post.")]
		[return: XmlRpcReturnValue(Description = "Always returns true.")]
		bool blogger_deletePost(
			string appKey,
			string postid,
			string username,
			string password,
			[XmlRpcParameter(Description = "Where applicable, this specifies whether the blog should be republished after the post has been deleted.")]
			bool publish);

		[XmlRpcMethod("blogger.getUsersBlogs", Description = "Returns information on all the blogs a given user is a member.")]
		BlogInfo[] blogger_getUsersBlogs(
			string appKey,
			string username,
			string password);


		[XmlRpcMethod("blogger.getTemplate", Description = "Returns the main or archive index template of a given blog.")]
		string blogger_getTemplate(
			string appKey,
			string blogid,
			string username,
			string password,
			string templateType);


		[XmlRpcMethod("blogger.setTemplate", Description = "Edits the main or archive index template of a given blog.")]
		bool blogger_setTemplate(
			string appKey,
			string blogid,
			string username,
			string password,
			string template,
			string templateType);
	}
}


