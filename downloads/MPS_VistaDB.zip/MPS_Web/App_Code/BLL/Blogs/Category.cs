using System;
using System.Collections.Generic;
using MPS.DAL;

namespace MPS.BLL.Blogs
{
    public class Category : BaseBlog
    {

		#region�Fields�(5)�

        private List<Blog> allBlogs = null;
        private string description = "";
        private int importance = 0;
        private List<Blog> publishedBlogs = null;
        private string title = "";

		#endregion�Fields�

		#region�Constructors�(1)�

        public Category(int id, DateTime addedDate, string addedBy, string title, int importance, string description)
        {
            Id = id;
            AddedDate = addedDate;
            AddedBy = addedBy;
            Title = title;
            Importance = importance;
            Description = description;
        }

		#endregion�Constructors�

		#region�Properties�(5)�

        public List<Blog> AllBlogs
        {
            get 
            {
                if (allBlogs == null)
                    allBlogs = Blog.GetBlogs(Id, 0, BizObject.MAXROWS);
                return allBlogs; 
            }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public int Importance
        {
            get { return importance; }
            set { importance = value; }
        }

        public List<Blog> PublishedBlogs
        {
            get 
            {
                if (publishedBlogs == null)
                    publishedBlogs = Blog.GetBlogs(true, Id, 0, BizObject.MAXROWS);
                return publishedBlogs; 
            }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

		#endregion�Properties�

		#region�Methods�(9)�


		//�Public�Methods�(7)�

        public bool Delete()
        {
            bool success = Category.DeleteCategory(Id);
            if (success)
                Id = 0;
            return success;
        }

        /// <summary>
        /// Deletes an existing category
        /// </summary>
        public static bool DeleteCategory(int id)
        {
            bool ret = SiteProvider.Blogs.DeleteCategory(id);
            //new RecordDeletedEvent("category", id, null).Raise();
            BizObject.PurgeCacheItems("Blogs_Categor");
            return ret;
        }

        /// <summary>
        /// Returns a collection with all the categories
        /// </summary>
        public static List<Category> GetCategories()
        {
            List<Category> categories = null;
            string key = "Blogs_Categories";

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                categories = (List<Category>)BizObject.Cache[key];
            }
            else
            {
                List<CategoryDetails> recordset = SiteProvider.Blogs.GetCategories();
                categories = GetCategoryListFromCategoryDetailsList(recordset);
                BaseBlog.CacheData(key, categories);
            }
            return categories;
        }

        /// <summary>
        /// Returns a Category object with the specified Id
        /// </summary>
        public static Category GetCategoryByID(int categoryID)
        {
            Category category = null;
            string key = "Blogs_Category_" + categoryID.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                category = (Category)BizObject.Cache[key];
            }
            else
            {
                category = GetCategoryFromCategoryDetails(SiteProvider.Blogs.GetCategoryByID(categoryID));
                BaseBlog.CacheData(key, category);
            }
            return category;
        }

        /// <summary>
        /// Creates a new category
        /// </summary>
        public static int InsertCategory(string title, int importance, string description)
        {
            CategoryDetails record = new CategoryDetails(0, DateTime.Now,
                                                         BizObject.CurrentUserName, title, importance, description);
            int ret = SiteProvider.Blogs.InsertCategory(record);
            BizObject.PurgeCacheItems("Blogs_Categor");
            return ret;
        }

        public bool Update()
        {
            return Category.UpdateCategory(Id, Title, Importance, Description);
        }

        /// <summary>
        /// Updates an existing category
        /// </summary>
        public static bool UpdateCategory(int id, string title, int importance, string description)
        {
            CategoryDetails record = new CategoryDetails(id, DateTime.Now, "", title, importance, description);
            bool ret = SiteProvider.Blogs.UpdateCategory(record);
            BizObject.PurgeCacheItems("Blogs_Categor");
            return ret;
        }



		//�Private�Methods�(2)�

        /// <summary>
        /// Returns a Category object filled with the data taken from the input CategoryDetails
        /// </summary>
        private static Category GetCategoryFromCategoryDetails(CategoryDetails record)
        {
            if (record == null)
                return null;
            else
            {
                return new Category(record.Id, record.AddedDate, record.AddedBy,
                                    record.Title, record.Importance, record.Description);
            }
        }

        /// <summary>
        /// Returns a list of Category objects filled with the data taken from the input list of CategoryDetails
        /// </summary>
        private static List<Category> GetCategoryListFromCategoryDetailsList(List<CategoryDetails> recordset)
        {
            List<Category> categories = new List<Category>();
            foreach (CategoryDetails record in recordset)
                categories.Add(GetCategoryFromCategoryDetails(record));
            return categories;
        }


		#endregion�Methods�

    }
}
