using System;
using System.Collections;
using System.IO;
using System.Net;
using System.Xml;

namespace MPS.BLL.Blogs
{
    public abstract class BaseBlog : BizObject
    {

		#region�Fields�(3)�

        private string addedBy = "";
        private DateTime addedDate = DateTime.Now;
        private int id = 0;

		#endregion�Fields�

		#region�Properties�(4)�

        public string AddedBy
        {
            get { return addedBy; }
            set { addedBy = value; }
        }

        public DateTime AddedDate
        {
            get { return addedDate; }
            set { addedDate = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        protected static BlogElement Settings
        {
            get
            {
                return Globals.Settings.Blogs;
            }
        }

		#endregion�Properties�

		#region�Methods�(2)�


		//�Public�Methods�(1)�

        /// <summary>
        /// Notify technorati about blog addition and updation
        /// </summary>
        public static void TechnoratiUpdatePing()
        {
            ArrayList listToPing = new ArrayList();
            string blogURL = "http://www.simplyvinay.com";
            string blogName = "Vinay's Blog";

            //If you are debugging, don't run this code
            if (System.Diagnostics.Debugger.IsAttached)
                return;

            listToPing.Add("http://rpc.technorati.com/rpc/ping");
            listToPing.Add("http://api.feedster.com/ping");
            listToPing.Add("http://ping.feedburner.com");
            listToPing.Add("http://blog.goo.ne.jp/XMLRPC");
            listToPing.Add("http://ping.blo.gs/");
            listToPing.Add("http://ping.bloggers.jp/rpc/");
            listToPing.Add("http://ping.blogmura.jp/rpc/");
            listToPing.Add("http://ping.cocolog-nifty.com/xmlrpc");
            listToPing.Add("http://ping.syndic8.com/xmlrpc.php");
            listToPing.Add("http://rpc.blogbuzzmachine.com/RPC2");
            listToPing.Add("http://rpc.blogrolling.com/pinger/");
            listToPing.Add("http://api.my.yahoo.com/rss/ping?u=" + blogURL + "/RSSFeed.aspx");
            listToPing.Add("http://rpc.icerocket.com:10080/");
            listToPing.Add("http://blogsearch.google.com/ping/RPC2");


            for (int i = 0; i <= listToPing.Count - 1; i++)
            {
                try
                {
                    string pingURL = listToPing[i].ToString();
                    HttpWebRequest technoratiPing = (HttpWebRequest)WebRequest.Create(pingURL);
                    technoratiPing.Method = "POST";
                    technoratiPing.ContentType = "text/xml";
                    Stream streamPingRequest = (Stream)technoratiPing.GetRequestStream();
                    XmlTextWriter xmlPing = new XmlTextWriter(streamPingRequest, System.Text.Encoding.UTF8);
                    xmlPing.WriteStartDocument();
                    xmlPing.WriteStartElement("methodCall");
                    xmlPing.WriteElementString("methodName", "weblogUpdates.ping");
                    xmlPing.WriteStartElement("params");
                    xmlPing.WriteStartElement("param");
                    xmlPing.WriteElementString("value", blogName);
                    xmlPing.WriteEndElement();
                    xmlPing.WriteStartElement("param");
                    xmlPing.WriteElementString("value", blogURL);
                    xmlPing.WriteEndElement();
                    xmlPing.WriteEndElement();
                    xmlPing.WriteEndElement();
                    xmlPing.Close();
                    HttpWebResponse technoratiPingResponse = (HttpWebResponse)technoratiPing.GetResponse();
                    StreamReader streamPingResponse = new StreamReader(technoratiPingResponse.GetResponseStream());
                    string strResult = streamPingResponse.ReadToEnd();
                    streamPingResponse.Close();
                    technoratiPingResponse.Close();
                }
                catch (Exception ex)
                {
                    //Add code here to flag a service as broken
                }
            }
        }



		//�Protected�Methods�(1)�

        /// <summary>
        /// Cache the input data, if caching is enabled
        /// </summary>
        protected static void CacheData(string key, object data)
        {
            if (Settings.EnableCaching && data != null)
            {
                BizObject.Cache.Insert(key, data, null,
                                       DateTime.Now.AddSeconds(Settings.CacheDuration), TimeSpan.Zero);
            }
        }


		#endregion�Methods�

    }
}
