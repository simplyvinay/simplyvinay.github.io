﻿using System;
using System.Collections.Generic;
using MPS.DAL;

namespace MPS.BLL.GuestBook
{
    public class GuestBook : BaseGuestBook
    {

		#region Fields (3) 

        private string addedByEmail = "";
        private string addedByIP = "";
        private string guestBookText = "";

		#endregion Fields 

		#region Constructors (1) 

        public GuestBook(int id, DateTime addedDate, string addedBy, string addedByEmail,
                       string addedByIP, string guestBookText)
        {
            Id = id;
            AddedDate = addedDate;
            AddedBy = addedBy;
            AddedByEmail = addedByEmail;
            AddedByIP = addedByIP;
            GuestBookText = guestBookText;
        }

		#endregion Constructors 

		#region Properties (4) 

        public string AddedByEmail
        {
            get { return addedByEmail; }
            set { addedByEmail = value; }
        }

        public string AddedByIP
        {
            get { return addedByIP; }
            set { addedByIP = value; }
        }

        public string EncodedBody
        {
            get { return Helpers.ConvertToHtml(GuestBookText); }
        }

        public string GuestBookText
        {
            get { return guestBookText; }
            set { guestBookText = value; }
        }

		#endregion Properties 

		#region Methods (11) 


		// Public Methods (9) 

        public bool Delete()
        {
            bool success =  GuestBook.DeleteGuestBook(Id);
            if (success)
                Id = 0;
            return success;
        }

        /// <summary>
        /// Deletes an existing GuestBook
        /// </summary>
        public static bool DeleteGuestBook(int id)
        {
            bool ret = SiteProvider.GuestBook.DeleteGuestBook(id);
            BizObject.PurgeCacheItems("GuestBook_GuestBook");
            return ret;
        }

        /// <summary>
        /// Returns a collection with all guestBook entries
        /// </summary>
        public static List<GuestBook> GetGuestBook()
        {
            List<GuestBook> guestBook = GetGuestBook(0, BizObject.MAXROWS);
            guestBook.Sort(new GuestBookComparer("AddedDate ASC"));
            return guestBook;
        }

        public static List<GuestBook> GetGuestBook(int startRowIndex, int maximumRows)
        {
            List<GuestBook> guestBook = null;
            string key = "GuestBook_GuestBook_" + startRowIndex.ToString() + "_" + maximumRows.ToString();

            if (BaseGuestBook.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                guestBook = (List<GuestBook>)BizObject.Cache[key];
            }
            else
            {
                List<GuestBookDetails> recordset = SiteProvider.GuestBook.GetGuestBook(GetPageIndex(startRowIndex, maximumRows), maximumRows);
                guestBook = GetGuestBookListFromGuestBookDetailsList(recordset);
                BaseGuestBook.CacheData(key, guestBook);
            }
            return guestBook;
        }

        /// <summary>
        /// Returns a GuestBook object with the specified ID
        /// </summary>
        public static GuestBook GetGuestBookByID(int guestBookID)
        {
            GuestBook guestBook = null;
            string key = "GuestBook_GuestBook_" + guestBookID.ToString();

            if (BaseGuestBook.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                guestBook = (GuestBook)BizObject.Cache[key];
            }
            else
            {
                guestBook = GetGuestBookFromGuestBookDetails(SiteProvider.GuestBook.GetGuestBookByID(guestBookID));
                BaseGuestBook.CacheData(key, guestBook);
            }
            return guestBook;
        }

        /// <summary>
        /// Returns the number of total GuestBook entries
        /// </summary>
        public static int GetGuestBookCount()
        {
            int guestBookCount = 0;
            string key = "GuestBook_GuestBookCount";

            if (BaseGuestBook.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                guestBookCount = (int)BizObject.Cache[key];
            }
            else
            {
                guestBookCount = SiteProvider.GuestBook.GetGuestBookCount();
                BaseGuestBook.CacheData(key, guestBookCount);
            }
            return guestBookCount;
        }

        /// <summary>
        /// Creates a new GuestBook
        /// </summary>
        public static int InsertGuestBook(string addedBy, string addedByEmail, string guestBookText)
        {
            GuestBookDetails record = new GuestBookDetails(0, DateTime.Now, addedBy, addedByEmail, BizObject.CurrentUserIP, guestBookText);
            int ret = SiteProvider.GuestBook.InsertGuestBook(record);
            BizObject.PurgeCacheItems("GuestBook_GuestBook");
            return ret;
        }

        public bool Update()
        {
            return GuestBook.UpdateGuestBook(Id, GuestBookText);
        }

        /// <summary>
        /// Updates an existing GuestBook
        /// </summary>
        public static bool UpdateGuestBook(int id, string guestBookText)
        {
            GuestBookDetails record = new GuestBookDetails(id, DateTime.Now, "", "", "", guestBookText);
            bool ret = SiteProvider.GuestBook.UpdateGuestBook(record);
            BizObject.PurgeCacheItems("GuestBook_GuestBook");
            return ret;
        }



		// Private Methods (2) 

        /// <summary>
        /// Returns a GuestBook object filled with the data taken from the input GuestBookDetails
        /// </summary>
        private static GuestBook GetGuestBookFromGuestBookDetails(GuestBookDetails record)
        {
            if (record == null)
                return null;
            else
            {
                return new GuestBook(record.Id, record.AddedDate, record.AddedBy,
                                   record.AddedByEmail, record.AddedByIP,
                                   record.GuestBookText);
            }
        }

        /// <summary>
        /// Returns a list of GuestBook objects filled with the data taken from the input list of GuestBookDetails
        /// </summary>
        private static List<GuestBook> GetGuestBookListFromGuestBookDetailsList(List<GuestBookDetails> recordset)
        {
            List<GuestBook> guestBook = new List<GuestBook>();
            foreach (GuestBookDetails record in recordset)
                guestBook.Add(GetGuestBookFromGuestBookDetails(record));
            return guestBook;
        }


		#endregion Methods 

		#region Nested Classes (1) 


        /// <summary>
        /// Comparer class, to be used with List<GuestBook>.Sort
        /// </summary>
        public class GuestBookComparer : IComparer<GuestBook>
        {

		#region Fields (2) 

            private bool _reverse;
            private string _sortBy;

		#endregion Fields 

		#region Constructors (1) 

            public GuestBookComparer(string sortBy)
            {
                if (!string.IsNullOrEmpty(sortBy))
                {
                    sortBy = sortBy.ToLower();
                    _reverse = sortBy.EndsWith(" desc");
                    _sortBy = sortBy.Replace(" desc", "").Replace(" asc", "");
                }
            }

		#endregion Constructors 

		#region Methods (2) 


		// Public Methods (2) 

            public int Compare(GuestBook x, GuestBook y)
            {
                int ret = 0;
                switch (_sortBy)
                {
                    case "addeddate":
                        ret = DateTime.Compare(x.AddedDate, y.AddedDate);
                        break;
                    case "addedby":
                        ret = string.Compare(x.AddedBy, y.AddedBy, StringComparison.InvariantCultureIgnoreCase);
                        break;
                }
                return (ret * (_reverse ? -1 : 1));
            }

            public bool Equals(GuestBook x, GuestBook y)
            {
                return (x.Id == y.Id);
            }


		#endregion Methods 




        }
		#endregion Nested Classes 

    }
}
