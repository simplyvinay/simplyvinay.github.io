﻿using System;

namespace MPS.BLL.GuestBook
{
    public abstract class BaseGuestBook : BizObject
    {

		#region Fields (3) 

        private string addedBy = "";
        private DateTime addedDate = DateTime.Now;
        private int id = 0;

		#endregion Fields 

		#region Properties (4) 

        public string AddedBy
        {
            get { return addedBy; }
            set { addedBy = value; }
        }

        public DateTime AddedDate
        {
            get { return addedDate; }
            set { addedDate = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        protected static GuestBookElement Settings
        {
            get
            {
                return Globals.Settings.GuestBook;
            }
        }

		#endregion Properties 

		#region Methods (1) 


		// Protected Methods (1) 

        /// <summary>
        /// Cache the input data, if caching is enabled
        /// </summary>
        protected static void CacheData(string key, object data)
        {
            if (Settings.EnableCaching && data != null)
            {
                BizObject.Cache.Insert(key, data, null,
                                       DateTime.Now.AddSeconds(Settings.CacheDuration), TimeSpan.Zero);
            }
        }


		#endregion Methods 

    }
}
