﻿using System;
using System.Collections.Generic;
using System.IO;
using MPS.DAL;

namespace MPS.BLL.PhotoGallery
{
    public class Album : BasePhotoGallery
    {

		#region Fields (2) 

        private string caption = "";
        private bool isPublic = true;

		#endregion Fields 

		#region Constructors (1) 

        public Album(int id, string caption, bool isPublic )
        {
            Id = id;
            Caption = caption;
            IsPublic = isPublic;
        }

		#endregion Constructors 

		#region Properties (2) 

        public string Caption
        {
            get { return caption; }
            set { caption = value; }
        }

        public bool IsPublic
        {
            get { return isPublic; }
            set { isPublic = value; }
        }

		#endregion Properties 

		#region Methods (11) 


		// Public Methods (9) 

        public bool Delete()
        {
            bool success = Album.DeleteAlbum(Id);
            if (success)
                Id = 0;
            return success;
        }

        /// <summary>
        /// Deletes an existing Album
        /// </summary>
        public static bool DeleteAlbum(int id)
        {
            bool ret = SiteProvider.PhotoGallery.DeleteAlbum(id);
            if (ret)
            {
                try
                {
                    string dirPath = "../" + Globals.Settings.PhotoGallery.AlbumsFolder + "/" + id;
                    Directory.Delete(System.Web.HttpContext.Current.Server.MapPath(dirPath), true);
                }
                catch
                {

                }
                BizObject.PurgeCacheItems("Albums_Album");
            }
            return ret;
        }

        /// <summary>
        /// Returns a collection with all the albums
        /// </summary>
        public static List<Album> GetAlbums()
        {
            List<Album> albums = null;
            string key = "Albums_Albums";

            if (BasePhotoGallery.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                albums = (List<Album>)BizObject.Cache[key];
            }
            else
            {
                List<AlbumDetails> recordset = SiteProvider.PhotoGallery.GetAlbums();
                albums = GetAlbumListFromAlbumDetailsList(recordset);
                BasePhotoGallery.CacheData(key, albums);
            }
            return albums;
        }

        /// <summary>
        /// Returns a Album object with the specified Id
        /// </summary>
        public static Album GetAlbumsByID(int albumID)
        {
            Album album = null;
            string key = "Albums_Album_" + albumID.ToString();

            if (BasePhotoGallery.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                album = (Album)BizObject.Cache[key];
            }
            else
            {
                album = GetAlbumFromAlbumDetails(SiteProvider.PhotoGallery.GetAlbumByID(albumID));
                BasePhotoGallery.CacheData(key, album);
            }
            return album;
        }

        /// <summary>
        /// Returns a collection with all the public albums
        /// </summary>
        public static List<Album> GetPublicAlbums()
        {
            List<Album> albums = null;
            string key = "Albums_AlbumsP";

            if (BasePhotoGallery.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                albums = (List<Album>)BizObject.Cache[key];
            }
            else
            {
                List<AlbumDetails> recordset = SiteProvider.PhotoGallery.GetPublicAlbums();
                albums = GetAlbumListFromAlbumDetailsList(recordset);
                BasePhotoGallery.CacheData(key, albums);
            }
            return albums;
        }

        /// <summary>
        /// Gets a random album id from the public albums
        /// </summary>
        public static int GetRandomAlbumID()
        {
            List<Album> albums = GetPublicAlbums();
            try
            {
                Random r = new Random();
                return albums[r.Next(albums.Count)].Id;
            }
            catch
            {
                return -1;
            }
        }

        /// <summary>
        /// Creates a new Album
        /// </summary>
        public static int InsertAlbum(string caption, bool isPublic)
        {
            AlbumDetails record = new AlbumDetails(0, caption, isPublic);
            int ret = SiteProvider.PhotoGallery.InsertAlbum(record);
            if (ret > 0)
            {
                try
                {
                    string dirPath = "../" + Globals.Settings.PhotoGallery.AlbumsFolder + "/" + ret;
                    System.IO.Directory.CreateDirectory(System.Web.HttpContext.Current.Server.MapPath(dirPath));
                }
                catch
                {

                }
                BizObject.PurgeCacheItems("Albums_Album");
            }
            return ret;
        }

        public bool Update()
        {
            return Album.UpdateAlbum(Id, Caption, IsPublic);
        }

        /// <summary>
        /// Updates an existing Album
        /// </summary>
        public static bool UpdateAlbum(int id, string caption, bool isPublic)
        {
            AlbumDetails record = new AlbumDetails(id, caption, isPublic);
            bool ret = SiteProvider.PhotoGallery.UpdateAlbum(record);
            BizObject.PurgeCacheItems("Albums_Album");
            return ret;
        }



		// Private Methods (2) 

        /// <summary>
        /// Returns a Album object filled with the data taken from the input AlbumDetails
        /// </summary>
        private static Album GetAlbumFromAlbumDetails(AlbumDetails record)
        {
            if (record == null)
                return null;
            else
            {
                return new Album(record.Id, record.Caption, record.IsPublic);
            }
        }

        /// <summary>
        /// Returns a list of Album objects filled with the data taken from the input list of AlbumDetails
        /// </summary>
        private static List<Album> GetAlbumListFromAlbumDetailsList(List<AlbumDetails> recordset)
        {
            List<Album> album = new List<Album>();
            foreach (AlbumDetails record in recordset)
                album.Add(GetAlbumFromAlbumDetails(record));
            return album;
        }


		#endregion Methods 

    }
}
