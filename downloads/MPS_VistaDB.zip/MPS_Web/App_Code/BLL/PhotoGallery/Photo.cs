﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using MPS.DAL;

namespace MPS.BLL.PhotoGallery
{
    public class Photo : BasePhotoGallery
    {

		#region Fields (5) 

        private Album album = null;
        private int albumID = 0;
        private string location = "";
        private string photoCaption = "";
        private int viewCount = 0;

		#endregion Fields 

		#region Constructors (1) 

        public Photo(int id, int albumID, string photoCaption, string location, int viewCount)
        {
            Id = id;
            AlbumID = albumID;
            PhotoCaption = photoCaption;
            Location = location;
            ViewCount = viewCount;
        }

		#endregion Constructors 

		#region Properties (5) 

        public Album Album
        {
            get
            {
                if (album == null)
                    album = Album.GetAlbumsByID(AlbumID);
                return album;
            }
        }

        public int AlbumID
        {
            get { return albumID; }
            set { albumID = value; }
        }

        public string Location
        {
            get { return location; }
            set { location = value; }
        }

        public string PhotoCaption
        {
            get { return photoCaption; }
            set { photoCaption = value; }
        }

        public int ViewCount
        {
            get { return viewCount; }
            set { viewCount = value; }
        }

		#endregion Properties 

		#region Methods (24) 


		// Public Methods (22) 

        public static Size CalculateDimensions(Size oldSize, int targetSize)
        {
            Size newSize = new Size(0, 0);
            if ((oldSize.Height > oldSize.Width))
            {
                newSize.Width = (int)(oldSize.Width * (float)(targetSize / (float)oldSize.Height));
                newSize.Height = targetSize;
            }
            else
            {
                newSize.Width = targetSize;
                newSize.Height = (int)(oldSize.Height * (float)(targetSize / (float)oldSize.Width));
            }
            return newSize;
        }

        public bool Delete()
        {
            bool success = Photo.DeletePhoto(Id);
            if (success)
                Id = 0;
            return success;
        }

        /// <summary>
        /// Deletes an existing Photo
        /// </summary>
        public static bool DeletePhoto(int photoID)
        {
            Photo photo = GetPhotoByID(photoID);
            bool ret = SiteProvider.PhotoGallery.DeletePhoto(photoID);
            if (ret)
            {
                try
                {

                    string filePath = "../" + Globals.Settings.PhotoGallery.AlbumsFolder + photo.Location;
                    File.Delete(System.Web.HttpContext.Current.Server.MapPath(filePath));
                }
                catch
                {

                }
                BizObject.PurgeCacheItems("Photos_Photo");
            }
            return ret;
        }

        /// <summary>
        /// Returns a stream object of the first photo in a album
        /// </summary>
        public static Stream GetFirstPhoto(int albumId, PhotoSize size)
        {
            List<Photo> photos = GetPhotos(albumId);
            if (photos != null && photos.Count > 0)
            {
                string fullPath = System.Web.HttpContext.Current.Server.MapPath(Globals.Settings.PhotoGallery.AlbumsFolder);
                fullPath += photos[0].location.Trim();
                Stream pic = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.Read);
                return ResizeImageFile(pic, size);
            }
            else
                return null;
        }

        public static Stream GetPhoto(PhotoSize size)
        {
            string path = System.Web.HttpContext.Current.Server.MapPath("~/Images/");
            if ((size == PhotoSize.Small))
            {
                path = (path + "placeholder-100.jpg");
            }
            else
            {
                if ((size == PhotoSize.Medium))
                {
                    path = (path + "placeholder-200.jpg");
                }
                else
                {
                    if ((size == PhotoSize.Large))
                    {
                        path = (path + "placeholder-600.jpg");
                    }
                    else
                    {
                        path = (path + "placeholder-600.jpg");
                    }
                }
            }
            return new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        }

        public static Stream GetPhoto(int photoId, PhotoSize size)
        {
            Photo photo = GetPhotoByID(photoId);
            if (photo != null)
            {
                string fullPath = System.Web.HttpContext.Current.Server.MapPath(Globals.Settings.PhotoGallery.AlbumsFolder);
                fullPath += photo.location.Trim();
                Stream pic = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.Read);
                return ResizeImageFile(pic, size);
            }
            else
                return null;
        }

        /// <summary>
        /// Returns an Photo object with the specified ID
        /// </summary>
        public static Photo GetPhotoByID(int photoID)
        {
            Photo photo = null;
            string key = "Photos_Photo_" + photoID.ToString();

            if (BasePhotoGallery.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                photo = (Photo)BizObject.Cache[key];
            }
            else
            {
                photo = GetPhotoFromPhotoDetails(SiteProvider.PhotoGallery.GetPhotoByID(photoID));
                BasePhotoGallery.CacheData(key, photo);
            }
            return photo;
        }

        /// <summary>
        /// Returns the number of total photos
        /// </summary>
        public static int GetPhotoCount()
        {
            int photoCount = 0;
            string key = "Photos_PhotoCount";

            if (BasePhotoGallery.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                photoCount = (int)BizObject.Cache[key];
            }
            else
            {
                photoCount = SiteProvider.PhotoGallery.GetPhotoCount();
                BasePhotoGallery.CacheData(key, photoCount);
            }
            return photoCount;
        }

        /// <summary>
        /// Returns the number of total photos for the specified album
        /// </summary>
        public static int GetPhotoCount(int albumID)
        {
            if (albumID <= 0)
                return GetPhotoCount();

            int photoCount = 0;
            string key = "Photos_PhotoCount" + albumID.ToString();

            if (BasePhotoGallery.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                photoCount = (int)BizObject.Cache[key];
            }
            else
            {
                photoCount = SiteProvider.PhotoGallery.GetPhotoCount(albumID);
                BasePhotoGallery.CacheData(key, photoCount);
            }
            return photoCount;
        }

        /// <summary>
        /// Returns a collection with all photos for the specified album
        /// </summary>
        public static List<Photo> GetPhotos(int albumID)
        {
            return GetPhotos(albumID, 0, BizObject.MAXROWS);
        }

        public static List<Photo> GetPhotos(int albumID, int startRowIndex, int maximumRows)
        {
            if (albumID < 1)
                return null;

            List<Photo> photos = null;
            string key = "Photos_Photos" + albumID.ToString() + "_" + startRowIndex.ToString() + "_" +
                         maximumRows.ToString();

            if (BasePhotoGallery.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                photos = (List<Photo>)BizObject.Cache[key];
            }
            else
            {
                List<PhotoDetails> recordset = SiteProvider.PhotoGallery.GetPhotos(albumID,
                                                                                   GetPageIndex(startRowIndex,
                                                                                                maximumRows),
                                                                                   maximumRows);
                photos = GetPhotoListFromPhotoDetailsList(recordset);
                BasePhotoGallery.CacheData(key, photos);
            }
            return photos;
        }

        /// <summary>
        /// Returns a random photo
        /// </summary>
        public static List<Photo> GetRandomPhoto()
        {
            int randomAlbumID = Album.GetRandomAlbumID();
            int photoID = GetRandomPhotoID(randomAlbumID);
            List<Photo> photo = new List<Photo>();
            photo.Add(GetPhotoByID(photoID));
            return photo;
        }

        public static int GetRandomPhotoID(int albumID)
        {
            List<Photo> photos = GetPhotos(albumID);
            try
            {
                Random r = new Random();
                return photos[r.Next(photos.Count)].Id;
            }
            catch
            {
                return -1;
            }
        }

        /// <summary>
        /// Increments an Photo's view count [ TODO: To be used when not using the HighSlide ]
        /// </summary>
        public static bool IncrementPhotoViewCount(int photoID)
        {
            return SiteProvider.PhotoGallery.IncrementPhotoViewCount(photoID);
        }

        public bool IncrementViewCount()
        {
            return Photo.IncrementPhotoViewCount(Id);
        }

        /// <summary>
        /// Inserts a new Photo [Redundant, check for dependencies and remove]
        /// </summary>
        public static int InsertPhoto(int albumID, string photoCaption, string location)
        {
            photoCaption = BizObject.ConvertNullToEmptyString(photoCaption);

            PhotoDetails record = new PhotoDetails(0, albumID, photoCaption, location, 0);
            int ret = SiteProvider.PhotoGallery.InsertPhoto(record);

            BizObject.PurgeCacheItems("Photos_Photo");
            return ret;
        }

        /// <summary>
        /// Inserts a new Photo
        /// </summary>
        public static int InsertPhoto(int albumID, string photoCaption, string location, string fileName, byte[] buffer)
        {
            photoCaption = BizObject.ConvertNullToEmptyString(photoCaption);

            PhotoDetails record = new PhotoDetails(0, albumID, photoCaption, location, 0);
            int ret = SiteProvider.PhotoGallery.InsertPhoto(record);

            if (ret > 0)
            {
                try
                {
                    string dirPath = "../" + Globals.Settings.PhotoGallery.AlbumsFolder + "/" + albumID + "/";
                    FileStream fs = new FileStream(System.Web.HttpContext.Current.Server.MapPath(dirPath+fileName), FileMode.Create);
                    fs.Write(buffer, 0, buffer.Length);
                    fs.Close();
                }
                catch(Exception exp)
                {

                }
                BizObject.PurgeCacheItems("Photos_Photo");
            }
            return ret;
        }

        public static Stream ResizeImageFile(Stream imageFile, PhotoSize targetSize)
        {
            if (targetSize == PhotoSize.Original)
            {
                //Retun pic without resizing
                return imageFile;
            }
            else
            {
                //Convert pic to byte[]
                byte[] picBuff = StreamToBytes(imageFile);

                //Resize pic
                if (targetSize == PhotoSize.Large)
                {
                    picBuff = ResizeImageFile(picBuff, 800);
                }
                else if (targetSize == PhotoSize.Medium)
                {
                    picBuff = ResizeImageFile(picBuff, 198);
                }
                else if (targetSize == PhotoSize.Small)
                {
                    picBuff = ResizeImageFile(picBuff, 100);
                }
                //Convert buffer back to stream and return
                return new MemoryStream((byte[])picBuff);
            }
        }

        public static byte[] ResizeImageFile(byte[] imageFile, int targetSize)
        {
            Image oldImage = Image.FromStream(new MemoryStream(imageFile));
            Size newSize = CalculateDimensions(oldImage.Size, targetSize);
            Bitmap newImage = new Bitmap(newSize.Width, newSize.Height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            Graphics canvas = Graphics.FromImage(newImage);
            canvas.SmoothingMode = SmoothingMode.AntiAlias;
            canvas.InterpolationMode = InterpolationMode.HighQualityBicubic;
            canvas.PixelOffsetMode = PixelOffsetMode.HighQuality;
            canvas.DrawImage(oldImage, new Rectangle(new Point(0, 0), newSize));

            MemoryStream m = new MemoryStream();
            newImage.Save(m, System.Drawing.Imaging.ImageFormat.Jpeg);
            return m.GetBuffer();
        }

        public static byte[] StreamToBytes(Stream stream)
        {
            //Create buffer
            int byteCount = (int)stream.Length;
            byte[] bytebuffer = new byte[byteCount + 1];

            //Read stream into buffer
            using (stream)
            {
                stream.Seek(0, SeekOrigin.Begin);
                stream.Read(bytebuffer, 0, byteCount);
            }
            return bytebuffer;
        }

        public bool Update()
        {
            return Photo.UpdatePhoto(Id, AlbumID, PhotoCaption, Location);
        }

        /// <summary>
        /// Updates an existing Photo
        /// </summary>
        public static bool UpdatePhoto(int id, int albumID, string photoCaption, string location)
        {
            photoCaption = BizObject.ConvertNullToEmptyString(photoCaption);

            PhotoDetails record = new PhotoDetails(id, albumID, photoCaption, location, 0);
            bool ret = SiteProvider.PhotoGallery.UpdatePhoto(record);

            BizObject.PurgeCacheItems("Photos_Photo_" + id.ToString());
            BizObject.PurgeCacheItems("Photos_Photos");
            return ret;
        }



		// Private Methods (2) 

        /// <summary>
        /// Returns a Photo object filled with the data taken from the input PhotoDetails
        /// </summary>
        private static Photo GetPhotoFromPhotoDetails(PhotoDetails record)
        {
            if (record == null)
                return null;
            else
                return new Photo(record.Id, record.AlbumId, record.PhotoCaption, record.Location, record.ViewCount);
        }

        /// <summary>
        /// Returns a list of Photo objects filled with the data taken from the input list of PhotoDetails
        /// </summary>
        private static List<Photo> GetPhotoListFromPhotoDetailsList(List<PhotoDetails> recordset)
        {
            List<Photo> photos = new List<Photo>();
            foreach (PhotoDetails record in recordset)
                photos.Add(GetPhotoFromPhotoDetails(record));
            return photos;
        }


		#endregion Methods 
 
    }
}
