﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace MPS.DAL.SqlClient
{
    public class SqlSiteSettingsProvider : SiteSettingsProvider
    {

		#region Methods (3) 


		// Public Methods (3) 

        /// <summary>
        /// Retrieves all GuestBook entries
        /// </summary>
        public override List<SiteSettingsDetails> GetSiteSettings()
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_SiteSettings_GetSiteSettings", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetSiteSettingsCollectionFromReader(ExecuteReader(cmd));
            }
        }

        /// <summary>
        /// Retrieves the SiteSettings with the specified ID
        /// </summary>
        public override SiteSettingsDetails GetSiteSettingsByID(int siteID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_SiteSettings_GetSiteSettingsByID", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@siteID", SqlDbType.Int).Value = siteID;
                cn.Open();
                IDataReader reader = ExecuteReader(cmd, CommandBehavior.SingleRow);
                if (reader.Read())
                    return GetSiteSettingsFromReader(reader);
                else
                    return null;
            }
        }

        /// <summary>
        /// Updates the SiteSettings
        /// </summary>
        public override bool UpdateSiteSettings(SiteSettingsDetails siteSettings)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_SiteSettings_UpdateSiteSettings", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@SiteID", SqlDbType.Int).Value = siteSettings.Id;
                cmd.Parameters.Add("@SiteName", SqlDbType.NVarChar).Value = siteSettings.SiteName;
                cmd.Parameters.Add("@SiteSlogan", SqlDbType.NVarChar).Value = siteSettings.SiteSlogan;
                cmd.Parameters.Add("@SitePageTitle", SqlDbType.NVarChar).Value = siteSettings.SitePageTitle;
                cmd.Parameters.Add("@MetaDescription", SqlDbType.NText).Value = siteSettings.MetaDescription;
                cmd.Parameters.Add("@MetaKeywords", SqlDbType.NText).Value = siteSettings.MetaKeywords;
                cmd.Parameters.Add("@Footer", SqlDbType.NText).Value = siteSettings.Footer;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }


		#endregion Methods 

    }
}
