using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace MPS.DAL.SqlClient
{
    public class SqlBlogsProvider : BlogsProvider
    {

		#region�Methods�(34)�


		//�Public�Methods�(34)�

        /// <summary>
        /// Approves an blog
        /// </summary>
        public override bool ApproveBlog(int blogID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_ApproveBlog", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@BlogID", SqlDbType.Int).Value = blogID;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }

        /// <summary>
        /// Deletes an blog
        /// </summary>
        public override bool DeleteBlog(int blogID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_DeleteBlog", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@BlogID", SqlDbType.Int).Value = blogID;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }

        /// <summary>
        /// Deletes a category
        /// </summary>
        public override bool DeleteCategory(int categoryID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_DeleteCategory", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = categoryID;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }

        /// <summary>
        /// deletes a comment
        /// </summary>
        public override bool DeleteComment(int commentID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_DeleteComment", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@CommentID", SqlDbType.Int).Value = commentID;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }

        /// <summary>
        /// Retrieves blog archives
        /// </summary>
        public override List<String> GetArchive()
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetArchive", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                List<String> archive = new List<String>();
                IDataReader reader = ExecuteReader(cmd);
                while (reader.Read())
                {
                    archive.Add(reader["Month1"] + " " + reader["Year1"] + " (" + reader["Total"] + ")");
                }
                return archive;
            }
        }

        /// <summary>
        /// Retrieves the body for the blog with the specified ID
        /// </summary>
        public override string GetBlogBody(int blogID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetBlogBody", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@BlogID", SqlDbType.Int).Value = blogID;
                cn.Open();
                return (string)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Retrieves the blog with the specified ID
        /// </summary>
        public override BlogDetails GetBlogByID(int blogID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetBlogByID", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@BlogID", SqlDbType.Int).Value = blogID;
                cn.Open();
                IDataReader reader = ExecuteReader(cmd, CommandBehavior.SingleRow);
                if (reader.Read())
                    return GetBlogFromReader(reader, true);
                else
                    return null;
            }
        }

        /// <summary>
        /// Retrieves the blog with the specified ID
        /// </summary>
        public override BlogDetails GetBlogByTitle(string blogTitle)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetBlogByTitle", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@BlogTitle", SqlDbType.VarChar).Value = blogTitle;
                cn.Open();
                IDataReader reader = ExecuteReader(cmd, CommandBehavior.SingleRow);
                if (reader.Read())
                    return GetBlogFromReader(reader, true);
                else
                    return null;
            }
        }

        /// <summary>
        /// Returns the total number of blogs
        /// </summary>
        public override int GetBlogCount()
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetBlogCount", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return (int)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Returns the total number of blogs for the specified category
        /// </summary>
        public override int GetBlogCount(int categoryID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetBlogCountByCategory", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = categoryID;
                cn.Open();
                return (int)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Returns the total number of blogs for the specified category
        /// </summary>
        public override int GetBlogCount(DateTime date)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetBlogCountByArchive", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Date", SqlDbType.DateTime).Value = date;
                cn.Open();
                return (int)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Retrieves all blogs
        /// </summary>
        public override List<BlogDetails> GetBlogs(int pageIndex, int pageSize)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetBlogs", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                cmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                cn.Open();
                return GetBlogCollectionFromReader(ExecuteReader(cmd), false);
            }
        }

        /// <summary>
        /// Retrieves all blogs for the specified category
        /// </summary>
        public override List<BlogDetails> GetBlogs(int categoryID, int pageIndex, int pageSize)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetBlogsByCategory", cn);
                cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = categoryID;
                cmd.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                cmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetBlogCollectionFromReader(ExecuteReader(cmd), false);
            }
        }

        /// <summary>
        /// Retrieves all blogs for the specified month
        /// </summary>
        public override List<BlogDetails> GetBlogs(DateTime date, int pageIndex, int pageSize)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetBlogsByDate", cn);
                cmd.Parameters.Add("@Date", SqlDbType.DateTime).Value = date;
                cmd.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                cmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetBlogCollectionFromReader(ExecuteReader(cmd), false);
            }
        }

        /// <summary>
        /// Returns a collection with all the categories
        /// </summary>
        public override List<CategoryDetails> GetCategories()
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetCategories", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetCategoryCollectionFromReader(ExecuteReader(cmd));
            }
        }

        /// <summary>
        /// Returns an existing category with the specified ID
        /// </summary>
        public override CategoryDetails GetCategoryByID(int categoryID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetCategoryByID", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = categoryID;
                cn.Open();
                IDataReader reader = ExecuteReader(cmd, CommandBehavior.SingleRow);
                if (reader.Read())
                    return GetCategoryFromReader(reader);
                else
                    return null;
            }
        }

        /// <summary>
        /// Retrieves the comment with the specified ID
        /// </summary>
        public override CommentDetails GetCommentByID(int commentID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetCommentByID", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@CommentID", SqlDbType.Int).Value = commentID;
                cn.Open();
                IDataReader reader = ExecuteReader(cmd, CommandBehavior.SingleRow);
                if (reader.Read())
                    return GetCommentFromReader(reader);
                else
                    return null;
            }
        }

        /// <summary>
        /// Returns the total number of comments
        /// </summary>
        public override int GetCommentCount()
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetCommentCount", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return (int)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Returns the total number of comments for the specified blog
        /// </summary>
        public override int GetCommentCount(int blogID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetCommentCountByBlog", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@BlogID", SqlDbType.Int).Value = blogID;
                cn.Open();
                return (int)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Retrieves all comments
        /// </summary>
        public override List<CommentDetails> GetComments(int pageIndex, int pageSize)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetComments", cn);
                cmd.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                cmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetCommentCollectionFromReader(ExecuteReader(cmd));
            }
        }

        /// <summary>
        /// Retrieves all comments for the specified blog
        /// </summary>
        public override List<CommentDetails> GetComments(int blogID, int pageIndex, int pageSize)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetCommentsByBlog", cn);
                cmd.Parameters.Add("@BlogID", SqlDbType.Int).Value = blogID;
                cmd.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                cmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetCommentCollectionFromReader(ExecuteReader(cmd));
            }
        }

        /// <summary>
        /// Returns the total number of published blogs
        /// </summary>
        public override int GetPublishedBlogCount(DateTime currentDate)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetPublishedBlogCount", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = currentDate;
                cn.Open();
                return (int)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Returns the total number of published blogs for the specified category
        /// </summary>
        public override int GetPublishedBlogCount(int categoryID, DateTime currentDate)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetPublishedBlogCountByCategory", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = categoryID;
                cmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = currentDate;
                cn.Open();
                return (int)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Returns the total number of published blogs for the specified month
        /// </summary>
        public override int GetPublishedBlogCount(DateTime date, DateTime currentDate)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetPublishedBlogCountByArchive", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Date", SqlDbType.DateTime).Value = date;
                cmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = currentDate;
                cn.Open();
                return (int)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Retrieves all published blogs
        /// </summary>
        public override List<BlogDetails> GetPublishedBlogs(DateTime currentDate, int pageIndex, int pageSize)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetPublishedBlogs", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = currentDate;
                cmd.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                cmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                cn.Open();
                return GetBlogCollectionFromReader(ExecuteReader(cmd), false);
            }
        }

        /// <summary>
        /// Retrieves all published blogs for the specified category
        /// </summary>
        public override List<BlogDetails> GetPublishedBlogs(int categoryID, DateTime currentDate, int pageIndex, int pageSize)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetPublishedBlogsByCategory", cn);
                cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = categoryID;
                cmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = currentDate;
                cmd.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                cmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetBlogCollectionFromReader(ExecuteReader(cmd), false);
            }
        }

        /// <summary>
        /// Retrieves all published blogs for the specified month
        /// </summary>
        public override List<BlogDetails> GetPublishedBlogs(DateTime date, DateTime currentDate, int pageIndex, int pageSize)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_GetPublishedBlogsByArchive", cn);
                cmd.Parameters.Add("@Date", SqlDbType.DateTime).Value = date;
                cmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = currentDate;
                cmd.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                cmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetBlogCollectionFromReader(ExecuteReader(cmd), false);
            }
        }

        /// <summary>
        /// Increments the ViewCount of the specified blog
        /// </summary>
        public override bool IncrementBlogViewCount(int blogID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_IncrementViewCount", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@BlogID", SqlDbType.Int).Value = blogID;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }

        /// <summary>
        /// Inserts a blog
        /// </summary>
        public override int InsertBlog(BlogDetails blog)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_InsertBlog", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@AddedDate", SqlDbType.DateTime).Value = blog.AddedDate;
                cmd.Parameters.Add("@AddedBy", SqlDbType.NVarChar).Value = blog.AddedBy;
                cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = blog.CategoryID;
                cmd.Parameters.Add("@BlogTitle", SqlDbType.NVarChar).Value = blog.BlogTitle;
                cmd.Parameters.Add("@BlogText", SqlDbType.NText).Value = blog.BlogText;
                cmd.Parameters.Add("@ExcerptBlogText", SqlDbType.NText).Value = blog.ExcerptBlogText;
                cmd.Parameters.Add("@ReleaseDate", SqlDbType.DateTime).Value = blog.ReleaseDate;
                cmd.Parameters.Add("@IsPublished", SqlDbType.Bit).Value = blog.IsPublished;
                cmd.Parameters.Add("@IsCommentsEnabled", SqlDbType.Bit).Value = blog.IsCommentsEnabled;
                cmd.Parameters.Add("@IsOnlyForMembers", SqlDbType.Bit).Value = blog.IsOnlyForMembers;
                cmd.Parameters.Add("@BlogID", SqlDbType.Int).Direction = ParameterDirection.Output;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (int)cmd.Parameters["@BlogID"].Value;
            }
        }

        /// <summary>
        /// Inserts a category
        /// </summary>
        public override int InsertCategory(CategoryDetails category)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_InsertCategory", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@AddedDate", SqlDbType.DateTime).Value = category.AddedDate;
                cmd.Parameters.Add("@AddedBy", SqlDbType.NVarChar).Value = category.AddedBy;
                cmd.Parameters.Add("@Title", SqlDbType.NVarChar).Value = category.Title;
                cmd.Parameters.Add("@Importance", SqlDbType.Int).Value = category.Importance;
                cmd.Parameters.Add("@Description", SqlDbType.NVarChar).Value = category.Description;
                cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Direction = ParameterDirection.Output;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (int)cmd.Parameters["@CategoryID"].Value;
            }
        }

        /// <summary>
        /// Inserts a new comment
        /// </summary>
        public override int InsertComment(CommentDetails comment)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_InsertComment", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@AddedDate", SqlDbType.DateTime).Value = comment.AddedDate;
                cmd.Parameters.Add("@AddedBy", SqlDbType.NVarChar).Value = comment.AddedBy;
                cmd.Parameters.Add("@AddedByEmail", SqlDbType.NVarChar).Value = comment.AddedByEmail;
                cmd.Parameters.Add("@AddedByHomePage", SqlDbType.NVarChar).Value = string.IsNullOrEmpty(comment.AddedByHomePage) ? string.Empty : comment.AddedByHomePage;
                cmd.Parameters.Add("@AddedByIP", SqlDbType.NVarChar).Value = comment.AddedByIP;
                cmd.Parameters.Add("@BlogID", SqlDbType.Int).Value = comment.BlogId;
                cmd.Parameters.Add("@CommentText", SqlDbType.NVarChar).Value = comment.CommentText;
                cmd.Parameters.Add("@CommentID", SqlDbType.Int).Direction = ParameterDirection.Output;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (int)cmd.Parameters["@CommentID"].Value;
            }
        }

        /// <summary>
        /// Updates an blog
        /// </summary>
        public override bool UpdateBlog(BlogDetails blog)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_UpdateBlog", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@BlogID", SqlDbType.Int).Value = blog.Id;
                cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = blog.CategoryID;
                cmd.Parameters.Add("@BlogTitle", SqlDbType.NVarChar).Value = blog.BlogTitle;
                cmd.Parameters.Add("@BlogText", SqlDbType.NText).Value = blog.BlogText;
                cmd.Parameters.Add("@ExcerptBlogText", SqlDbType.NText).Value = blog.ExcerptBlogText;
                cmd.Parameters.Add("@ReleaseDate", SqlDbType.DateTime).Value = blog.ReleaseDate;
                cmd.Parameters.Add("@IsPublished", SqlDbType.Bit).Value = blog.IsPublished;
                cmd.Parameters.Add("@IsCommentsEnabled", SqlDbType.Bit).Value = blog.IsCommentsEnabled;
                cmd.Parameters.Add("@IsOnlyForMembers", SqlDbType.Bit).Value = blog.IsOnlyForMembers;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }

        /// <summary>
        /// Updates a category
        /// </summary>
        public override bool UpdateCategory(CategoryDetails category)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_UpdateCategory", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Value = category.Id;
                cmd.Parameters.Add("@Title", SqlDbType.NVarChar).Value = category.Title;
                cmd.Parameters.Add("@Importance", SqlDbType.Int).Value = category.Importance;
                cmd.Parameters.Add("@Description", SqlDbType.NVarChar).Value = category.Description;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }

        /// <summary>
        /// Updates a comment
        /// </summary>
        public override bool UpdateComment(CommentDetails comment)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_Blogs_UpdateComment", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@CommentID", SqlDbType.Int).Value = comment.Id;
                cmd.Parameters.Add("@CommentText", SqlDbType.NVarChar).Value = comment.CommentText;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }


		#endregion�Methods�

    }
}
