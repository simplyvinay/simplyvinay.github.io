﻿using System;

namespace MPS.DAL
{
    public class GuestBookDetails
    {

		#region Fields (6) 

        private string addedBy = "";
        private string addedByEmail = "";
        private string addedByIP = "";
        private DateTime addedDate = DateTime.Now;
        private string guestBookText = "";
        private int id = 0;

		#endregion Fields 

		#region Constructors (2) 

        public GuestBookDetails(int id, DateTime addedDate, string addedBy, string addedByEmail, string addedByIP, string guestBookText)
        {
            Id = id;
            AddedDate = addedDate;
            AddedBy = addedBy;
            AddedByEmail = addedByEmail;
            AddedByIP = addedByIP;
            GuestBookText = guestBookText;
        }

        public GuestBookDetails()
        {
        }

		#endregion Constructors 

		#region Properties (6) 

        public string AddedBy
        {
            get { return addedBy; }
            set { addedBy = value; }
        }

        public string AddedByEmail
        {
            get { return addedByEmail; }
            set { addedByEmail = value; }
        }

        public string AddedByIP
        {
            get { return addedByIP; }
            set { addedByIP = value; }
        }

        public DateTime AddedDate
        {
            get { return addedDate; }
            set { addedDate = value; }
        }

        public string GuestBookText
        {
            get { return guestBookText; }
            set { guestBookText = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

		#endregion Properties 

    }
}
