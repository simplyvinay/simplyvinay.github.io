﻿using System;
using System.Collections.Generic;
using System.Data;

namespace MPS.DAL
{
    public abstract class PhotoGalleryProvider : DataAccess
    {

		#region Fields (1) 

        private static PhotoGalleryProvider instance = null;

		#endregion Fields 

		#region Constructors (1) 

        public PhotoGalleryProvider()
        {
            ConnectionString = Globals.Settings.PhotoGallery.ConnectionString;
            EnableCaching = Globals.Settings.PhotoGallery.EnableCaching;
            CacheDuration = Globals.Settings.PhotoGallery.CacheDuration;
        }

		#endregion Constructors 

		#region Properties (1) 

        /// <summary>
        /// Returns an instance of the provider type specified in the config file
        /// </summary>
        public static PhotoGalleryProvider Instance
        {
            get 
            {
                if (instance == null)
                    instance = (PhotoGalleryProvider)Activator.CreateInstance(Type.GetType(Globals.Settings.PhotoGallery.ProviderType));
                return instance; 
            }
        }

		#endregion Properties 

		#region Methods (18) 


		// Public Methods (14) 

        public abstract bool DeleteAlbum(int albumID);

        public abstract bool DeletePhoto(int photoID);

        public abstract AlbumDetails GetAlbumByID(int albumID);

        public abstract List<AlbumDetails> GetAlbums();

        public abstract PhotoDetails GetPhotoByID(int photoID);

        public abstract int GetPhotoCount();

        public abstract int GetPhotoCount(int albumID);

        // methods that work with photos
        public abstract List<PhotoDetails> GetPhotos(int albumID, int pageIndex, int pageSize);

        // methods that work with albums
        public abstract List<AlbumDetails> GetPublicAlbums();

        public abstract bool IncrementPhotoViewCount(int photoID);

        public abstract int InsertAlbum(AlbumDetails album);

        public abstract int InsertPhoto(PhotoDetails photo);

        public abstract bool UpdateAlbum(AlbumDetails album);

        public abstract bool UpdatePhoto(PhotoDetails photo);



		// Protected Methods (4) 

        /// <summary>
        /// Returns a collection of AlbumDetails objects with the data read from the input DataReader
        /// </summary>
        protected virtual List<AlbumDetails> GetAlbumCollectionFromReader(IDataReader reader)
        {
            List<AlbumDetails> albums = new List<AlbumDetails>();
            while (reader.Read())
                albums.Add(GetAlbumFromReader(reader));
            return albums;
        }

        /// <summary>
        /// Returns a new AlbumDetails instance filled with the DataReader's current record data
        /// </summary>
        protected virtual AlbumDetails GetAlbumFromReader(IDataReader reader)
        {
            return new AlbumDetails(
                (int)reader["AlbumID"],
                reader["Caption"].ToString(),
                (bool)reader["isPublic"]);
        }

        /// <summary>Returns a collection of PhotoDetails objects with the
        /// data read from the input DataReader</summary>
        protected virtual List<PhotoDetails> GetPhotoCollectionFromReader(IDataReader reader)
        {
            List<PhotoDetails> photos = new List<PhotoDetails>();
            while (reader.Read())
                photos.Add(GetPhotoFromReader(reader));
            return photos;
        }

        /// <summary>Returns a new PhotoDetails instance filled with the
        /// DataReader's current record data</summary>
        protected virtual PhotoDetails GetPhotoFromReader(IDataReader reader)
        {
            PhotoDetails photo = new PhotoDetails(
                (int)reader["PhotoID"],
                (int)reader["AlbumID"],
                reader["PhotoCaption"].ToString(),
                reader["Location"].ToString(),
                (int)reader["ViewCount"]);

            return photo;                
        }


		#endregion Methods 

    }
}
