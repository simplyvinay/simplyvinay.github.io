using System;

namespace MPS.DAL
{
    public class BlogDetails
    {

		#region�Fields�(14)�

        private string addedBy = "";
        private DateTime addedDate = DateTime.Now;
        private string blogText = "";
        private string blogTitle = "";
        private int categoryID = 0;
        private string categoryTitle = "";
        private string excerptBlogText = "";
        private int id = 0;
        private bool isCommentsEnabled = true;
        private bool isListed = true;
        private bool isOnlyForMembers = true;
        private bool isPublished = true;
        private DateTime releaseDate = DateTime.Now;
        private int viewCount = 0;

		#endregion�Fields�

		#region�Constructors�(2)�

        public BlogDetails(int id, DateTime addedDate, string addedBy,
                              int categoryID, string categoryTitle, string blogTitle,
                              string blogText, string excerptBlogText, DateTime releaseDate,
                              bool isPublished, bool isCommentsEnabled, bool isOnlyForMembers,
                              int viewCount)
        {
            Id = id;
            AddedDate = addedDate;
            AddedBy = addedBy;
            CategoryID = categoryID;
            CategoryTitle = categoryTitle;
            BlogTitle = blogTitle;
            BlogText = blogText;
            ExcerptBlogText = excerptBlogText; 
            ReleaseDate = releaseDate;
            IsPublished = isPublished;
            IsCommentsEnabled = isCommentsEnabled;
            IsOnlyForMembers = isOnlyForMembers;
            ViewCount = viewCount;
        }

        public BlogDetails(){ }

		#endregion�Constructors�

		#region�Properties�(14)�

        public string AddedBy
        {
            get { return addedBy; }
            set { addedBy = value; }
        }

        public DateTime AddedDate
        {
            get { return addedDate; }
            set { addedDate = value; }
        }

        public string BlogText
        {
            get { return blogText; }
            set { blogText = value; }
        }

        public string BlogTitle
        {
            get { return blogTitle; }
            set { blogTitle = value; }
        }

        public int CategoryID
        {
            get { return categoryID; }
            set { categoryID = value; }
        }

        public string CategoryTitle
        {
            get { return categoryTitle; }
            set { categoryTitle = value; }
        }

        public string ExcerptBlogText
        {
            get { return excerptBlogText; }
            set { excerptBlogText = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public bool IsCommentsEnabled
        {
            get { return isCommentsEnabled; }
            set { isCommentsEnabled = value; }
        }

        public bool IsListed
        {
            get { return isListed; }
            set { isListed = value; }
        }

        public bool IsOnlyForMembers
        {
            get { return isOnlyForMembers; }
            set { isOnlyForMembers = value; }
        }

        public bool IsPublished
        {
            get { return isPublished; }
            set { isPublished = value; }
        }

        public DateTime ReleaseDate
        {
            get { return releaseDate; }
            set { releaseDate = value; }
        }

        public int ViewCount
        {
            get { return viewCount; }
            set { viewCount = value; }
        }

		#endregion�Properties�

    }
}
