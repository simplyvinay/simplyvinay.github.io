using System;

namespace MPS.DAL
{
    public static class SiteProvider
    {

		#region�Properties�(4)�

        public static BlogsProvider Blogs
        {
            get { return BlogsProvider.Instance; }
        }

        public static GuestBookProvider GuestBook
        {
            get { return GuestBookProvider.Instance; }
        }

        public static PhotoGalleryProvider PhotoGallery
        {
            get { return PhotoGalleryProvider.Instance; }
        }

        public static SiteSettingsProvider SiteSettings
        {
            get { return SiteSettingsProvider.Instance; }
        }

		#endregion�Properties�

    }
}
