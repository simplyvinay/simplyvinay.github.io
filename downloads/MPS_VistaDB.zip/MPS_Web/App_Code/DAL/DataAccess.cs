using System.Data;
using System.Data.Common;
using System.Web;
using System.Web.Caching;

namespace MPS.DAL
{
    public abstract class DataAccess
    {

		#region�Fields�(3)�

        private int cacheDuration = 0;
        private string connectionString = "";
        private bool enableCaching = true;

		#endregion�Fields�

		#region�Properties�(4)�

        protected Cache Cache
        {
            get { return HttpContext.Current.Cache; }
        }

        public int CacheDuration
        {
            get { return cacheDuration; }
            set { cacheDuration = value; }
        }

        public string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        public bool EnableCaching
        {
            get { return enableCaching; }
            set { enableCaching = value; }
        }

		#endregion�Properties�

		#region�Methods�(4)�


		//�Protected�Methods�(4)�

        protected int ExecuteNonQuery(DbCommand cmd)
        {
            return cmd.ExecuteNonQuery();
        }

        protected IDataReader ExecuteReader(DbCommand cmd)
        {
            return ExecuteReader(cmd, CommandBehavior.Default);
        }

        protected IDataReader ExecuteReader(DbCommand cmd, CommandBehavior behavior)
        {
            return cmd.ExecuteReader(behavior);
        }

        protected object ExecuteScalar(DbCommand cmd)
        {
            return cmd.ExecuteScalar();
        }


		#endregion�Methods�

    }
}
