﻿using System;

namespace MPS.DAL
{
    public class PhotoDetails
    {

		#region Fields (5) 

        private int albumId = 0;
        private int id = 0;
        private string location = "";
        private string photoCaption = "";
        private int viewCount = 0;

		#endregion Fields 

		#region Constructors (2) 

        public PhotoDetails(int id, int albumId, string photoCaption, string location, int viewCount)
        {
            Id = id;
            AlbumId = albumId;
            PhotoCaption = photoCaption;
            Location = location;
            ViewCount = viewCount;
        }

        public PhotoDetails()
        {
        }

		#endregion Constructors 

		#region Properties (5) 

        public int AlbumId
        {
            get { return albumId; }
            set { albumId = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Location
        {
            get { return location; }
            set { location = value; }
        }

        public string PhotoCaption
        {
            get { return photoCaption; }
            set { photoCaption = value; }
        }

        public int ViewCount
        {
            get { return viewCount; }
            set { viewCount = value; }
        }

		#endregion Properties 

    }
}
