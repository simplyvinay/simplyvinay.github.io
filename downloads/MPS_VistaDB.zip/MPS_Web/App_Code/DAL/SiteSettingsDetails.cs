﻿using System;

namespace MPS.DAL
{
    public class SiteSettingsDetails
    {

		#region Fields (7) 

        private string footer = "";
        private int id = 0;
        private string metaDescription = "";
        private string metaKeywords = "";
        private string siteName = "";
        private string sitePageTitle = "";
        private string siteSlogan = "";

		#endregion Fields 

		#region Constructors (2) 

        public SiteSettingsDetails(int id, string siteName, string siteSlogan, string sitePageTitle, string metaDescription, string metaKeywords, string footer)
        {
            Id = id;
            SiteName = siteName;
            SiteSlogan = siteSlogan;
            SitePageTitle = sitePageTitle;
            MetaDescription = metaDescription;
            MetaKeywords = metaKeywords;
            Footer = footer;
        }

        public SiteSettingsDetails()
        {

        }

		#endregion Constructors 

		#region Properties (7) 

        public string Footer
        {
            get { return footer; }
            set { footer = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string MetaDescription
        {
            get { return metaDescription; }
            set { metaDescription = value; }
        }

        public string MetaKeywords
        {
            get { return metaKeywords; }
            set { metaKeywords = value; }
        }

        public string SiteName
        {
            get { return siteName; }
            set { siteName = value; }
        }

        public string SitePageTitle
        {
            get { return sitePageTitle; }
            set { sitePageTitle = value; }
        }

        public string SiteSlogan
        {
            get { return siteSlogan; }
            set { siteSlogan = value; }
        }

		#endregion Properties 

    }
}
