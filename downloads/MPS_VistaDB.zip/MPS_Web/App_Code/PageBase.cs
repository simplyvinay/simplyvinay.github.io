using System;
using System.Web.Security;
using System.Web.UI;

namespace MPS.UI
{
    public class PageBase : System.Web.UI.Page
    {

		#region�Properties�(2)�

        public string BaseUrl
        {
            get
            {
                string url = Request.ApplicationPath;
                if (url.EndsWith("/"))
                    return url;
                else
                    return url + "/";
            }
        }

        public string FullBaseUrl
        {
            get
            {
                return Request.Url.AbsoluteUri.Replace(
                           Request.Url.PathAndQuery, "") + BaseUrl;
            }
        }

		#endregion�Properties�

		#region�Methods�(4)�


		//�Protected�Methods�(4)�

        protected override void OnLoad(EventArgs e)
        {
            // add onfocus and onblur javascripts to all input controls on the forum,
            // so that the active control has a difference appearance
            Helpers.SetInputControlsHighlight(this, "highlight", false);

            base.OnLoad(e);
        }

        protected override void OnPreInit(EventArgs e)
        {
            Page.Theme = "Blue";
            base.OnPreInit(e);
            
        }

        protected override void Render(HtmlTextWriter writer)
        {
            System.IO.StringWriter stringWriter = new System.IO.StringWriter();
            HtmlTextWriter htmlWriter = new HtmlTextWriter(stringWriter);
            base.Render(htmlWriter);
            string html = stringWriter.ToString();
            int startPoint = html.IndexOf("<input type=\"hidden\" name=\"__VIEWSTATE\"");
            if (startPoint >= 0)
            {
                int endPoint = html.IndexOf("/>", startPoint) + 2;
                string viewStateInput = html.Substring(startPoint, endPoint - startPoint);
                html = html.Remove(startPoint, endPoint - startPoint);
                int formEndStart = html.IndexOf("</form>") - 1;
                if (formEndStart >= 0)
                {
                    html = html.Insert(formEndStart, viewStateInput);
                }
            }
            writer.Write(html);
        }

        protected void RequestLogin()
        {
            if (Helpers.URLRewritten(Request.Url.LocalPath))
            {
                Response.Redirect(FormsAuthentication.LoginUrl +
                              "?ReturnUrl=" + Request.Url.LocalPath);
            }
            else
            {
                Response.Redirect(FormsAuthentication.LoginUrl +
                               "?ReturnUrl=" + Request.Url.PathAndQuery);
            }

        }


		#endregion�Methods�

    }
}
