﻿using System;
using System.Collections.Generic;
using MPS.BLL.Blogs;

namespace MPS.UI
{
    public partial class GetBlogRss : PageBase
    {

		#region Fields (1) 

        private string rssTitle = "Recent Blogs";

		#endregion Fields 

		#region Properties (1) 

        public string RssTitle
        {
            get { return rssTitle; }
            set { rssTitle = value; }
        }

		#endregion Properties 

		#region Methods (1) 


		// Protected Methods (1) 

        protected void Page_Load(object sender, EventArgs e)
        {
            int categoryID = 0;
            List<Blog> blogs = null;
            // if a CatID param is passed on the querystring, load the category with that ID,
            // and use its title for the RSS's title
            if (!string.IsNullOrEmpty(Request.QueryString["CatID"]))
            {
                categoryID = int.Parse(Request.QueryString["CatID"]);
                Category category = Category.GetCategoryByID(categoryID);
                rssTitle = category.Title;
                blogs = Blog.GetBlogs(true, categoryID, 0, Globals.Settings.Blogs.RssItems);
            }
            else
            {
                rssTitle = "RSS Feed";
                blogs = Blog.GetBlogs(true, 0, 30);
            }

            rptRss.DataSource = blogs;
            rptRss.DataBind();
        }


		#endregion Methods 

    }
}
