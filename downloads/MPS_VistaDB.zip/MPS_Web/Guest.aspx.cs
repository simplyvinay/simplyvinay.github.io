﻿using System;
using System.Web.Security;
using System.Web.UI.WebControls;
using MPS.BLL.GuestBook;
using System.Web.UI.HtmlControls;
using System.Web.UI;

namespace MPS.UI
{
    public partial class Guest : PageBase
    {

		#region Fields (1) 

        private bool userCanEdit = false;

		#endregion Fields 

		#region Properties (1) 

        protected bool UserCanEdit
        {
            get { return userCanEdit; }
            set { userCanEdit = value; }
        }

		#endregion Properties 

		#region Methods (9) 


		// Protected Methods (9) 

        protected void dlstComments_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                int guestBookID = int.Parse(e.CommandArgument.ToString());
                GuestBook.DeleteGuestBook(guestBookID);
                dvwComment.ChangeMode(DetailsViewMode.Insert);
                dlstComments.SelectedIndex = -1;
                dlstComments.DataBind();
            }
        }

        protected void dlstComments_SelectedIndexChanged(object sender, EventArgs e)
        {
            dvwComment.ChangeMode(DetailsViewMode.Edit);
        }

        protected void dvwComment_ItemCommand(object sender, DetailsViewCommandEventArgs e)
        {
            if (e.CommandName == "Cancel")
            {
                dlstComments.SelectedIndex = -1;
                dlstComments.DataBind();
            }
        }

        protected void dvwComment_ItemCreated(object sender, EventArgs e)
        {
            // when in Insert Mode, pre-fill the username and e-mail fields with the
            // current user's information, if she is authenticated
            if (dvwComment.CurrentMode == DetailsViewMode.Insert &&
                User.Identity.IsAuthenticated)
            {
                MembershipUser user = Membership.GetUser();
                (dvwComment.FindControl("txtAddedBy") as TextBox).Text = user.UserName;
                (dvwComment.FindControl("txtAddedByEmail") as TextBox).Text = user.Email;
            }
        }

        protected void dvwComment_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
        {
            dlstComments.SelectedIndex = -1;
            dlstComments.DataBind();
        }

        protected void dvwComment_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
        {
            dlstComments.SelectedIndex = -1;
            dlstComments.DataBind();
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            UserCanEdit = (User.Identity.IsAuthenticated &&
                           (User.IsInRole("Administrators")));
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int guestBookCount = GuestBook.GetGuestBookCount();
                lblViews.Text = string.Format(lblViews.Text, guestBookCount);
            }
        }

        protected void valAntiBotImage_ServerValidate(object source, ServerValidateEventArgs args)
        {
            args.IsValid = (Session["antibotimage"] != null) && ((dvwComment.FindControl("txtAntiBotImage") as TextBox).Text.Trim().ToUpper() == (string)Session["antibotimage"]);
        }


		#endregion Methods 

}
}
