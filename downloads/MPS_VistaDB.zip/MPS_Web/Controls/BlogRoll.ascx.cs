﻿using System;
using System.Collections.Generic;
using System.Xml;

namespace MPS.UI
{
    public partial class Controls_BlogRoll : System.Web.UI.UserControl
    {

		#region Methods (1) 


		// Protected Methods (1) 

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<BlogRoll> roll = new List<BlogRoll>();
                try
                {
                    string file = Request.PhysicalApplicationPath + "BlogRoll.config";
                    XmlDocument xDoc = new XmlDocument();
                    xDoc.Load(file);

                    XmlNodeList name = xDoc.GetElementsByTagName("Name");
                    XmlNodeList rss = xDoc.GetElementsByTagName("RssUrl");
                    XmlNodeList url = xDoc.GetElementsByTagName("Url");

                    for (int i = 0; i < name.Count; i++)
                    {
                        BlogRoll b = new BlogRoll();
                        b.BlogName = name[i].InnerText;
                        b.RssAddress = rss[i].InnerText;
                        b.BlogAddress = url[i].InnerText;
                        roll.Add(b);
                    }
                }
                catch (Exception ex)
                { }

                dlstRoll.DataSource = roll;
                dlstRoll.DataBind();
            }
        }


		#endregion Methods 

}

    public class BlogRoll
    {

		#region Fields (3) 

        string blogAddress = "";
        string blogName = "";
        string rssAddress = "";

		#endregion Fields 

		#region Properties (3) 

        public string BlogAddress
        {
            get { return blogAddress; }
            set { blogAddress = value; }
        }

        public string BlogName
        {
            get { return blogName; }
            set { blogName = value; }
        }

        public string RssAddress
        {
            get { return rssAddress; }
            set { rssAddress = value; }
        }

		#endregion Properties 

    }
}