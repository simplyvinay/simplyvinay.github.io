﻿using System;
using MPS.BLL.Blogs;

namespace MPS.UI
{
    public partial class Controls_RecentBlogs : System.Web.UI.UserControl
    {

		#region Methods (1) 


		// Protected Methods (1) 

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dlstCategories.DataSource = Blog.GetBlogs(true, 0, 10);
                dlstCategories.DataBind();
            }
        }


		#endregion Methods 

    }
}
