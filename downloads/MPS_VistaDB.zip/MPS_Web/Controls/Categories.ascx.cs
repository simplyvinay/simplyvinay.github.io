﻿using System;
using MPS.BLL.Blogs;

namespace MPS.UI
{
    public partial class Controls_Categories : System.Web.UI.UserControl
    {

		#region Methods (1) 


		// Protected Methods (1) 

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dlstCategories.DataSource = Category.GetCategories();
                dlstCategories.DataBind();
            }
        }


		#endregion Methods 

    }
}
