using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using MPS.BLL.Blogs;

namespace MPS.UI
{
    public partial class Controls_BlogListing : System.Web.UI.UserControl
    {

		#region�Fields�(2)�

        private bool publishedOnly = true;
        private bool userCanEdit = false;

		#endregion�Fields�

		#region�Properties�(2)�

        public bool PublishedOnly
        {
            get { return publishedOnly; }
            set
            {
                publishedOnly = value;
                objBlogs.SelectParameters["publishedOnly"].DefaultValue = value.ToString();
            }
        }

        public bool UserCanEdit
        {
            get { return userCanEdit; }
            set { userCanEdit = value; }
        }

		#endregion�Properties�

		#region�Methods�(6)�


		//�Protected�Methods�(6)�

        protected void gvwBlogs_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Approve")
            {
                int blogID = int.Parse(e.CommandArgument.ToString());
                Blog.ApproveBlog(blogID);
                gvwBlogs.PageIndex = 0;
                gvwBlogs.DataBind();
            }
        }

        protected void gvwBlogs_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected override void LoadControlState(object savedState)
        {
            object[] ctlState = (object[])savedState;
            base.LoadControlState(ctlState[0]);
            PublishedOnly = (bool)ctlState[1];
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            Page.RegisterRequiresControlState(this);

            UserCanEdit = (Page.User.Identity.IsAuthenticated &&
                           (Page.User.IsInRole("Administrators")));
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Set the page size as indicated in the config file. 

                if (Request.QueryString["CatID"] != null)
                {
                    int catID = Convert.ToInt32(Request.QueryString["CatID"]);
                    objBlogs.SelectParameters.Add("categoryID", TypeCode.Int32, catID.ToString());
                }
                else if (Request.QueryString["month"] != null && Request.QueryString["year"] != null)
                {
                    string dt = Request.QueryString["month"] + "/1/" + Request.QueryString["year"];
                    DateTime date = Convert.ToDateTime(dt);
                    objBlogs.SelectParameters.Add("date", TypeCode.DateTime, date.ToShortDateString());
                }

                int pageSize = Globals.Settings.Blogs.PageSize;
                gvwBlogs.PageSize = pageSize;
                gvwBlogs.DataBind();
            }

        }

        protected override object SaveControlState()
        {
            object[] ctlState = new object[3];
            ctlState[0] = base.SaveControlState();
            ctlState[1] = PublishedOnly;
            return ctlState;
        }


		#endregion�Methods�

}
}
