﻿using System;
using System.Configuration;
using System.Configuration.Provider;
using System.Diagnostics;
using System.Web.Profile;
using VistaDB;
using VistaDB.Diagnostic;
using VistaDB.Provider;

namespace VistaDBProviders.ProfileProvider
{
    public class VistaDBProfile : System.Web.Profile.ProfileProvider
    {
        private string connectionString;
        private string eventLog = "Application";
        private string eventSource = "VistaDBMembershipProvider";
        private string exceptionMessage = "An exception occurred. Please check the Event Log.";
        private string pApplicationName;
        private ConnectionStringSettings pConnectionStringSettings;
        private bool pWriteExceptionsToEventLog;

        public override string ApplicationName
        {
            get { return pApplicationName; }
            set { pApplicationName = value; }
        }

        public bool WriteExceptionsToEventLog
        {
            get { return pWriteExceptionsToEventLog; }
            set { pWriteExceptionsToEventLog = value; }
        }

        public override int DeleteInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
        {
            int total = 0;
            return DeleteProfiles(GetAllInactiveProfiles(authenticationOption, userInactiveSinceDate, -1, -1, out total));
        }

        public override int DeleteProfiles(string[] usernames)
        {
            if (usernames.Length <= 0)
                return 0;

            int result = 0;

            string profileID = string.Empty;
            foreach (string name in usernames)
            {
                profileID = GetProfileID(name, true);
                if (!string.IsNullOrEmpty(profileID))
                {

                    VistaDBConnection conn = new VistaDBConnection(connectionString);
                    VistaDBCommand cmd = new VistaDBCommand("DELETE FROM ProfileData " +
                                "WHERE ProfileID = @ProfileID", conn);

                    cmd.Parameters.Add("@ProfileID", VistaDBType.VarChar, 255).Value = profileID;

                    VistaDBCommand cmd2 = new VistaDBCommand("DELETE FROM Profile " +
                                "WHERE Profile.ID = @ProfileID AND" +
                                " Profile.ApplicationName = @ApplicationName AND Profile.Username = @Username", conn);

                    cmd2.Parameters.Add("@ProfileID", VistaDBType.VarChar, 255).Value = profileID;
                    cmd2.Parameters.Add("@Username", VistaDBType.VarChar, 255).Value = name;
                    cmd2.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

                    VistaDBTransaction tran = null;

                    try
                    {
                        conn.Open();
                        tran = conn.BeginTransaction();
                        cmd.Transaction = tran;
                        cmd2.Transaction = tran;
                        
                        result += (int)cmd.ExecuteNonQuery();
                        result += (int)cmd2.ExecuteNonQuery();

                        tran.Commit();
                    }
                    catch (VistaDBException e)
                    {
                        try
                        {
                            tran.Rollback();
                        }
                        catch { }
                        if (WriteExceptionsToEventLog)
                            WriteToEventLog(e, "RemoveUsersFromRoles");
                        else
                            throw e;
                    }
                    finally
                    {
                        conn.Close();
                    }                
                
                }
            }
            return result;
        }

        public override int DeleteProfiles(ProfileInfoCollection profiles)
        {
            int count = profiles.Count;
            int i = 0;
            string[] usernames = new string[count];

            foreach (ProfileInfo profileOn in profiles)
            {
                usernames[i] = profileOn.UserName;
                i++;
            }

            return DeleteProfiles(usernames);
        }

        public override ProfileInfoCollection FindInactiveProfilesByUserName(ProfileAuthenticationOption authenticationOption, string usernameToMatch, DateTime userInactiveSinceDate, int pageIndex, int pageSize, out int totalRecords)
        {
            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT * FROM Profile  " +
              "WHERE Username = @Username AND LastActivityDate <= @LastActivityDate AND " +
              GetIsAnonymousFilter(authenticationOption) + " AND ApplicationName=@ApplicationName");

            cmd.Parameters.Add("@Username", VistaDBType.VarChar, 255).Value = usernameToMatch;
            cmd.Parameters.Add("@LastActivityDate", VistaDBType.DateTime, 8).Value = userInactiveSinceDate;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            ProfileInfoCollection result = new ProfileInfoCollection();
            VistaDBDataReader reader = null;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                while (reader.Read())
                    result.Add(GetProfileFromReader(reader));
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "FindInactiveProfilesByUserName");
                else
                    throw e;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                conn.Close();
            }

            totalRecords = result.Count;
            return result;
        }

        public override ProfileInfoCollection FindProfilesByUserName(ProfileAuthenticationOption authenticationOption, string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT * FROM Profile  " +
              "WHERE Username = @Username AND " +
              GetIsAnonymousFilter(authenticationOption) + " AND ApplicationName=@ApplicationName");

            cmd.Parameters.Add("@Username", VistaDBType.VarChar, 255).Value = usernameToMatch;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            ProfileInfoCollection result = new ProfileInfoCollection();
            VistaDBDataReader reader = null;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                while (reader.Read())
                    result.Add(GetProfileFromReader(reader));
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "FindProfilesByUserName");
                else
                    throw e;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                conn.Close();
            }

            totalRecords = result.Count;
            return result;
        }

        public override ProfileInfoCollection GetAllInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate, int pageIndex, int pageSize, out int totalRecords)
        {
            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT * FROM Profile  " +
              "WHERE LastActivityDate <= @LastActivityDate AND " +
              GetIsAnonymousFilter(authenticationOption) + " AND ApplicationName=@ApplicationName");

            cmd.Parameters.Add("@LastActivityDate", VistaDBType.DateTime, 8).Value = userInactiveSinceDate;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            ProfileInfoCollection result = new ProfileInfoCollection();
            VistaDBDataReader reader = null;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                while (reader.Read())
                    result.Add(GetProfileFromReader(reader));
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "GetAllInactiveProfiles");
                else
                    throw e;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                conn.Close();
            }

            totalRecords = result.Count;
            return result;
        }

        public override ProfileInfoCollection GetAllProfiles(ProfileAuthenticationOption authenticationOption, int pageIndex, int pageSize, out int totalRecords)
        {
            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT * FROM Profile  " +
              "WHERE " + GetIsAnonymousFilter(authenticationOption) + " AND ApplicationName=@ApplicationName");

            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            ProfileInfoCollection result = new ProfileInfoCollection();
            VistaDBDataReader reader = null;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                while (reader.Read())
                    result.Add(GetProfileFromReader(reader));
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "GetAllProfiles");
                else
                    throw e;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                conn.Close();
            }

            totalRecords = result.Count;
            return result;
        }

        public override int GetNumberOfInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
        {
            int result = -1;
            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT COUNT(*) FROM Profile  " +
              "LastActivityDate <= @LastActivityDate AND ApplicationName=@ApplicationName AND " + GetIsAnonymousFilter(authenticationOption));

            cmd.Parameters.Add("@LastActivityDate", VistaDBType.DateTime, 8).Value = userInactiveSinceDate;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            VistaDBDataReader reader = null;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.Read()) //Parse the count in column 0
                    Int32.TryParse(reader[0].ToString() + "", out result);
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "GetAllProfiles");
                else
                    throw e;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                conn.Close();
            }

            return result;
        }

        public override SettingsPropertyValueCollection GetPropertyValues(SettingsContext context, SettingsPropertyCollection collection)
        {
            SettingsPropertyValueCollection result = new SettingsPropertyValueCollection();
            string username = (string)context["UserName"];

            //Loop through all the properties that we were told to retrieve
            foreach (SettingsProperty propOn in collection)
            {
                //Make a new value to store the retrieved property in
                SettingsPropertyValue propValue = new SettingsPropertyValue(propOn);

                VistaDBConnection conn = new VistaDBConnection(connectionString);
                VistaDBCommand cmd = new VistaDBCommand("SELECT * FROM Profile, ProfileData " +
                        " WHERE Profile.ID = ProfileData.ProfileID AND " +
                        "ProfileData.PropertyName = @PropertyName AND " +
                        "Profile.Username=@Username AND " +
                        "Profile.ApplicationName = @ApplicationName", conn);

                cmd.Parameters.Add("@PropertyName", VistaDBType.VarChar, 255).Value = propOn.Name;
                cmd.Parameters.Add("@Username", VistaDBType.VarChar, 255).Value = username;
                cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

                VistaDBDataReader reader = null;

                try
                {
                    conn.Open();
                    reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        //Found our record, now we need to get it into an object.
                        if (propOn.SerializeAs == SettingsSerializeAs.Xml || propOn.SerializeAs == SettingsSerializeAs.String)
                        {
                            propValue.SerializedValue = reader["PropertyValueString"].ToString() + "";
                            propValue.PropertyValue = reader["PropertyValueString"].ToString() + "";
                        }
                        else if (propOn.SerializeAs == SettingsSerializeAs.Binary)
                        {
                            propValue.SerializedValue = reader["PropertyValueBinary"];
                            propValue.PropertyValue = reader["PropertyValueString"];
                        }
                        else if (propOn.SerializeAs == SettingsSerializeAs.ProviderSpecific)
                        {
                            if (propOn.PropertyType.IsPrimitive || (propOn.PropertyType == typeof(string)))
                            {
                                propValue.SerializedValue = reader["PropertyValueString"].ToString() + "";
                                propValue.PropertyValue = reader["PropertyValueString"].ToString() + "";
                            }
                            else
                            {
                                propValue.SerializedValue = reader["PropertyValueBinary"];
                                propValue.PropertyValue = reader["PropertyValueString"];
                            }
                        }
                    }
                    else
                    {
                        //No value exists in database, just use the default value
                        propValue.PropertyValue = propOn.DefaultValue;
                    }

                    //Return the property value
                    result.Add(propValue);
                }
                catch (VistaDBException e)
                {
                    if (WriteExceptionsToEventLog)
                        WriteToEventLog(e, "GetUsersInRole");
                    else
                        throw e;
                }
                finally
                {
                    if (reader != null)
                        reader.Close();
                    conn.Close();
                }
            }
            return result;
        }

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");

            if (name == null || name.Length == 0)
                name = "OdbcRoleProvider";

            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "VistaDB Profile provider");
            }

            base.Initialize(name, config);


            if (config["applicationName"] == null || config["applicationName"].Trim() == "")
                pApplicationName = System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;
            else
                pApplicationName = config["applicationName"];

            if (config["writeExceptionsToEventLog"] != null)
            {
                if (config["writeExceptionsToEventLog"].ToUpper() == "TRUE")
                    pWriteExceptionsToEventLog = true;
            }

            pConnectionStringSettings = ConfigurationManager.ConnectionStrings[config["connectionStringName"]];

            if (pConnectionStringSettings == null || pConnectionStringSettings.ConnectionString.Trim() == "")
                throw new ProviderException("Connection string cannot be blank.");

            connectionString = pConnectionStringSettings.ConnectionString;
        }

        public override void SetPropertyValues(SettingsContext context, SettingsPropertyValueCollection collection)
        {
            //Get our username and isauthenticated out of the context
            string username = (string)context["UserName"];
            bool isAuthenticated = (bool)context["IsAuthenticated"];

            //Get the profile record's id, which will be created if it doesn't exist
            string existingProfileID = GetProfileID(username, true);

            //Loop through all the properties that we were told to retrieve
            if (!string.IsNullOrEmpty(existingProfileID))
            {
                foreach (SettingsPropertyValue propValueOn in collection)
                {
                    VistaDBConnection conn = new VistaDBConnection(connectionString);
                    VistaDBCommand cmd = new VistaDBCommand("SELECT ProfileData.ID FROM Profile, ProfileData " +
                            " WHERE Profile.ID = ProfileData.ProfileID AND " +
                            "ProfileData.PropertyName = @PropertyName AND " +
                            "Profile.Username=@Username AND " +
                            "Profile.ApplicationName = @ApplicationName", conn);

                    string existingPropertyID = string.Empty;

                    cmd.Parameters.Add("@PropertyName", VistaDBType.VarChar, 255).Value = propValueOn.Name;
                    cmd.Parameters.Add("@Username", VistaDBType.VarChar, 255).Value = username;
                    cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

                    VistaDBDataReader reader = null;

                    try
                    {
                        conn.Open();
                        reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            existingPropertyID = reader[0].ToString();
                        }
                    }
                    catch (VistaDBException e)
                    {
                        if (WriteExceptionsToEventLog)
                            WriteToEventLog(e, "GetUsersInRole");
                        else
                            throw e;
                    }
                    finally
                    {
                        if (reader != null)
                            reader.Close();
                        conn.Close();
                    }

                    //Decide to update or insert based on the existence of the property
                    if (!string.IsNullOrEmpty(existingPropertyID))
                    {
                        conn = new VistaDBConnection(connectionString);
                        cmd = new VistaDBCommand("UPDATE ProfileData Set " +
                            " PropertyValueBinary=@PropertyValueBinary, PropertyValueString=@PropertyValueString " +
                            " WHERE PropertyName=@PropertyName AND profileID=@ProfileID", conn);

                        if (propValueOn.Property.SerializeAs == SettingsSerializeAs.Binary)
                        {
                            cmd.Parameters.Add("@PropertyValueString", VistaDBType.VarChar, 255).Value = DBNull.Value;
                            cmd.Parameters.Add("@PropertyValueBinary", VistaDBType.VarChar, 255).Value = propValueOn.SerializedValue;
                        }
                        else if (propValueOn.Property.SerializeAs == SettingsSerializeAs.Xml || propValueOn.Property.SerializeAs == SettingsSerializeAs.String)
                        {
                            cmd.Parameters.Add("@PropertyValueString", VistaDBType.VarChar, 255).Value = propValueOn.SerializedValue;
                            cmd.Parameters.Add("@PropertyValueBinary", VistaDBType.VarChar, 255).Value = DBNull.Value;
                        }
                        else if (propValueOn.Property.SerializeAs == SettingsSerializeAs.ProviderSpecific)
                        {
                            if (propValueOn.SerializedValue is string && ((string)propValueOn.SerializedValue).Length <= 3000)
                            {
                                cmd.Parameters.Add("@PropertyValueString", VistaDBType.VarChar, 255).Value = propValueOn.SerializedValue;
                                cmd.Parameters.Add("@PropertyValueBinary", VistaDBType.Image, Int16.MaxValue).Value = DBNull.Value;
                            }
                            else
                            {
                                cmd.Parameters.Add("@PropertyValueString", VistaDBType.VarChar, 255).Value = DBNull.Value;
                                cmd.Parameters.Add("@PropertyValueBinary", VistaDBType.Image, Int16.MaxValue).Value = propValueOn.SerializedValue;
                            }
                        }
                        cmd.Parameters.Add("@PropertyName", VistaDBType.VarChar, 255).Value = propValueOn.Name;
                        cmd.Parameters.Add("@ProfileID", VistaDBType.BigInt, 8).Value = existingProfileID;

                        try
                        {
                            conn.Open();
                            cmd.ExecuteNonQuery();

                        }
                        catch (VistaDBException e)
                        {
                            if (WriteExceptionsToEventLog)
                                WriteToEventLog(e, "GetUsersInRole");
                            else
                                throw e;
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                    else
                    {
                        conn = new VistaDBConnection(connectionString);
                        cmd = new VistaDBCommand("INSERT INTO ProfileData " +
                                     " (ProfileID, PropertyName, PropertyValueString, PropertyValueBinary) " +
                                     " Values(@ProfileID, @PropertyName, @PropertyValueString, @PropertyValueBinary)", conn);

                        cmd.Parameters.Add("@ProfileID", VistaDBType.BigInt, 8).Value = existingProfileID;
                        cmd.Parameters.Add("@PropertyName", VistaDBType.VarChar, 255).Value = propValueOn.Name;

                        if (propValueOn.Property.SerializeAs == SettingsSerializeAs.Binary)
                        {
                            cmd.Parameters.Add("@PropertyValueString", VistaDBType.VarChar, 255).Value = DBNull.Value;
                            cmd.Parameters.Add("@PropertyValueBinary", VistaDBType.VarChar, 255).Value = propValueOn.SerializedValue;
                        }
                        else if (propValueOn.Property.SerializeAs == SettingsSerializeAs.Xml || propValueOn.Property.SerializeAs == SettingsSerializeAs.String)
                        {
                            cmd.Parameters.Add("@PropertyValueString", VistaDBType.VarChar, 255).Value = propValueOn.SerializedValue;
                            cmd.Parameters.Add("@PropertyValueBinary", VistaDBType.VarChar, 255).Value = DBNull.Value;
                        }
                        else if (propValueOn.Property.SerializeAs == SettingsSerializeAs.ProviderSpecific)
                        {
                            if (propValueOn.SerializedValue is string && ((string)propValueOn.SerializedValue).Length <= 3000)
                            {
                                cmd.Parameters.Add("@PropertyValueString", VistaDBType.VarChar, 255).Value = propValueOn.SerializedValue;
                                cmd.Parameters.Add("@PropertyValueBinary", VistaDBType.Image, Int16.MaxValue).Value = DBNull.Value;
                            }
                            else
                            {
                                cmd.Parameters.Add("@PropertyValueString", VistaDBType.VarChar, 255).Value = DBNull.Value;
                                cmd.Parameters.Add("@PropertyValueBinary", VistaDBType.Image, Int16.MaxValue).Value = propValueOn.SerializedValue;
                            }
                        }

                        try
                        {
                            conn.Open();
                            cmd.ExecuteNonQuery();
                        }
                        catch (VistaDBException e)
                        {
                            if (WriteExceptionsToEventLog)
                                WriteToEventLog(e, "GetUsersInRole");
                            else
                                throw e;
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                } 
            }
        }

        private string GetIsAnonymousFilter(ProfileAuthenticationOption authenticationOption)
        {
            string result = string.Empty;

            if (authenticationOption == ProfileAuthenticationOption.All)
                result = "IsAnonymous < 99";
            else if (authenticationOption == ProfileAuthenticationOption.Anonymous)
                result = "IsAnonymous >= 1";
            else if (authenticationOption == ProfileAuthenticationOption.Authenticated)
                result = "IsAnonymous <= 0";

            return result;
        }

        private ProfileInfo GetProfileFromReader(VistaDBDataReader reader)
        {
            //Fills out a ProfileInfo object from a datareader
            string username = string.Empty;
            bool authenticated = false;
            DateTime lastActivityDate = DateTime.Now;
            DateTime LastUpdateDate = DateTime.Now;

            username = reader["Username"].ToString() + "";
            DateTime.TryParse(reader["LastActivityDate"].ToString() + "", out lastActivityDate);
            DateTime.TryParse(reader["LastUpdateDate"].ToString() + "", out LastUpdateDate);

            if (reader["IsAnonymous"].ToString().Equals("1"))
                authenticated = true;

            return new ProfileInfo(username, authenticated, lastActivityDate, LastUpdateDate, -1);
        }

        private string GetProfileID(string username, bool isAnonymous)
        {
            string result = string.Empty;
            bool exists = false;

            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT * FROM Profile " +
                      " WHERE Username=@Username AND ApplicationName=@ApplicationName ", conn);

            cmd.Parameters.Add("@Username", VistaDBType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            VistaDBDataReader reader = null;

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    result = reader["id"].ToString() + "";
                    exists = true;
                }
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "GetAllRoles");
                else
                    throw e;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                conn.Close();
            }

            if (!exists && !string.IsNullOrEmpty(username))
            {
                conn = new VistaDBConnection(connectionString);
                cmd = new VistaDBCommand("INSERT INTO Profile " +
                    "(Username,ApplicationName,IsAnonymous,LastActivityDate,LastUpdateDate) " +
                    "VALUES (@Username,@ApplicationName,@IsAnonymous,@LastActivityDate,@LastUpdateDate)", conn);

                cmd.Parameters.Add("@Username", VistaDBType.VarChar, 255).Value = username;
                cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;
                cmd.Parameters.Add("@IsAnonymous", VistaDBType.Bit, 1).Value = isAnonymous;
                cmd.Parameters.Add("@LastActivityDate", VistaDBType.DateTime, 8).Value = DateTime.Now;
                cmd.Parameters.Add("@LastUpdateDate", VistaDBType.DateTime, 8).Value = DateTime.Now;

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (VistaDBException e)
                {
                    if (WriteExceptionsToEventLog)
                        WriteToEventLog(e, "GetAllRoles");
                    else
                        throw e;
                }
                finally
                {
                    conn.Close();
                }
                result = GetProfileID(username, isAnonymous);
            }
            return result;
        }

        private void WriteToEventLog(VistaDBException e, string action)
        {
            EventLog log = new EventLog();
            log.Source = eventSource;
            log.Log = eventLog;

            string message = exceptionMessage + "\n";
            message += "Action: " + action + "\n";
            message += "Exception: " + e.ToString();
            try
            {
                log.WriteEntry(message);
            }
            catch (Exception ex) { }
        }
    }
}
