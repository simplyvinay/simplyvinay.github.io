﻿using System;
using System.Configuration;
using System.Configuration.Provider;
using System.Diagnostics;
using System.Web.Security;
using VistaDB;
using VistaDB.Diagnostic;
using VistaDB.Provider;

namespace VistaDBProviders.RoleProvider
{
    public class VistaDBRole : System.Web.Security.RoleProvider
    {
        private string connectionString;
        private string eventLog = "Application";
        private string eventSource = "VistaDBMembershipProvider";
        private string exceptionMessage = "An exception occurred. Please check the Event Log.";
        private string pApplicationName;
        private ConnectionStringSettings pConnectionStringSettings;
        private bool pWriteExceptionsToEventLog;

        public override string ApplicationName
        {
            get { return pApplicationName; }
            set { pApplicationName = value; }
        }

        public bool WriteExceptionsToEventLog
        {
            get { return pWriteExceptionsToEventLog; }
            set { pWriteExceptionsToEventLog = value; }
        }

        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            foreach (string rolename in roleNames)
            {
                if (!RoleExists(rolename))
                    throw new ProviderException("Role name not found.");
            }

            foreach (string username in usernames)
            {
                if (username.Contains(","))
                    throw new ArgumentException("User names cannot contain commas.");

                foreach (string rolename in roleNames)
                {
                    if (IsUserInRole(username, rolename))
                        throw new ProviderException("User is already in role.");

                }
            }

            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("INSERT INTO UsersInRoles " +
              " (Username, Rolename, ApplicationName) " +
              " Values(@Username, @Rolename, @ApplicationName)", conn);

            VistaDBParameter userParm = cmd.Parameters.Add("@Username", VistaDBType.VarChar, 255);
            VistaDBParameter roleParm = cmd.Parameters.Add("@Rolename", VistaDBType.VarChar, 255);
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            VistaDBTransaction tran = null;

            try
            {
                conn.Open();
                tran = conn.BeginTransaction();
                cmd.Transaction = tran;

                foreach (string username in usernames)
                {
                    foreach (string rolename in roleNames)
                    {
                        userParm.Value = username;
                        roleParm.Value = rolename;
                        cmd.ExecuteNonQuery();
                    }
                }

                tran.Commit();
            }
            catch (VistaDBException e)
            {
                try
                {
                    tran.Rollback();
                }
                catch
                { }

                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "AddUsersToRoles");
                else
                    throw e;
            }
            finally
            {
                conn.Close();
            }
        }

        public override void CreateRole(string roleName)
        {
            if (roleName.Contains(","))
                throw new ArgumentException("Role names cannot contain commas.");

            if (RoleExists(roleName))
                throw new ProviderException("Role name already exists.");

            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("INSERT INTO Roles " +
                    " (Rolename, ApplicationName) " +
                    " Values(@Rolename, @ApplicationName)", conn);

            cmd.Parameters.Add("@Rolename", VistaDBType.VarChar, 255).Value = roleName;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "CreateRole");
                else
                    throw e;
            }
            finally
            {
                conn.Close();
            }
        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            if (!RoleExists(roleName))
                throw new ProviderException("Role does not exist.");

            if (throwOnPopulatedRole && GetUsersInRole(roleName).Length > 0)
                throw new ProviderException("Cannot delete a populated role.");


            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("DELETE FROM Roles " +
                    " WHERE Rolename = @Rolename AND ApplicationName = @ApplicationName", conn);

            cmd.Parameters.Add("@Rolename", VistaDBType.VarChar, 255).Value = roleName;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;


            VistaDBCommand cmd2 = new VistaDBCommand("DELETE FROM UsersInRoles " +
                    " WHERE Rolename = @Rolename AND ApplicationName = @ApplicationName", conn);

            cmd2.Parameters.Add("@Rolename", VistaDBType.VarChar, 255).Value = roleName;
            cmd2.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            VistaDBTransaction tran = null;

            try
            {
                conn.Open();
                tran = conn.BeginTransaction();
                cmd.Transaction = tran;
                cmd2.Transaction = tran;

                cmd2.ExecuteNonQuery();
                cmd.ExecuteNonQuery();

                tran.Commit();
            }
            catch (VistaDBException e)
            {
                try
                {
                    tran.Rollback();
                }
                catch { }

                if (WriteExceptionsToEventLog)
                {
                    WriteToEventLog(e, "DeleteRole");
                    return false;
                }
                else
                    throw e;
            }
            finally
            {
                conn.Close();
            }

            return true;
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT Username FROM UsersInRoles  " +
                      "WHERE Username LIKE @UsernameSearch AND RoleName = @RoleName AND ApplicationName = @ApplicationName", conn);

            cmd.Parameters.Add("@UsernameSearch", VistaDBType.VarChar, 255).Value = usernameToMatch;
            cmd.Parameters.Add("@RoleName", VistaDBType.VarChar, 255).Value = roleName;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = pApplicationName;

            string tmpUserNames = "";
            VistaDBDataReader reader = null;

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();

                while (reader.Read())
                    tmpUserNames += reader.GetString(0) + ",";
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "FindUsersInRole");
                else
                    throw e;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                conn.Close();
            }

            if (tmpUserNames.Length > 0)
            {
                tmpUserNames = tmpUserNames.Substring(0, tmpUserNames.Length - 1);
                return tmpUserNames.Split(',');
            }

            return new string[] { };
        }

        public override string[] GetAllRoles()
        {
            string tmpRoleNames = "";

            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT Rolename FROM Roles " +
                      " WHERE ApplicationName = @ApplicationName", conn);

            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            VistaDBDataReader reader = null;

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();

                while (reader.Read())
                    tmpRoleNames += reader.GetString(0) + ",";
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "GetAllRoles");
                else
                    throw e;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                conn.Close();
            }

            if (tmpRoleNames.Length > 0)
            {
                tmpRoleNames = tmpRoleNames.Substring(0, tmpRoleNames.Length - 1);
                return tmpRoleNames.Split(',');
            }

            return new string[] { };
        }

        public override string[] GetRolesForUser(string username)
        {
            string tmpRoleNames = "";

            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT Rolename FROM UsersInRoles " +
                    " WHERE Username = @Username AND ApplicationName = @ApplicationName", conn);

            cmd.Parameters.Add("@Username", VistaDBType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            VistaDBDataReader reader = null;

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();

                while (reader.Read())
                    tmpRoleNames += reader.GetString(0) + ",";
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "GetRolesForUser");
                else
                    throw e;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                conn.Close();
            }

            if (tmpRoleNames.Length > 0)
            {
                tmpRoleNames = tmpRoleNames.Substring(0, tmpRoleNames.Length - 1);
                return tmpRoleNames.Split(',');
            }

            return new string[] { };
        }

        public override string[] GetUsersInRole(string roleName)
        {
            string tmpRoleNames = "";

            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT Rolename FROM UsersInRoles " +
                    " WHERE Rolename = @Rolename AND ApplicationName = @ApplicationName", conn);

            cmd.Parameters.Add("@Rolename", VistaDBType.VarChar, 255).Value = roleName;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            VistaDBDataReader reader = null;

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();

                while (reader.Read())
                    tmpRoleNames += reader.GetString(0) + ",";
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "GetUsersInRole");
                else
                    throw e;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                conn.Close();
            }

            if (tmpRoleNames.Length > 0)
            {
                tmpRoleNames = tmpRoleNames.Substring(0, tmpRoleNames.Length - 1);
                return tmpRoleNames.Split(',');
            }

            return new string[] { };
        }

        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");

            if (name == null || name.Length == 0)
                name = "OdbcRoleProvider";

            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "VistaDB Role provider");
            }

            base.Initialize(name, config);


            if (config["applicationName"] == null || config["applicationName"].Trim() == "")
                pApplicationName = System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;
            else
                pApplicationName = config["applicationName"];

            if (config["writeExceptionsToEventLog"] != null)
            {
                if (config["writeExceptionsToEventLog"].ToUpper() == "TRUE")
                    pWriteExceptionsToEventLog = true;
            }

            pConnectionStringSettings = ConfigurationManager.ConnectionStrings[config["connectionStringName"]];

            if (pConnectionStringSettings == null || pConnectionStringSettings.ConnectionString.Trim() == "")
                throw new ProviderException("Connection string cannot be blank.");

            connectionString = pConnectionStringSettings.ConnectionString;
        }

        public override bool IsUserInRole(string username, string roleName)
        {
            bool userIsInRole = false;

            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT COUNT(*) FROM UsersInRoles " +
                    " WHERE Username = @Username AND Rolename = @Rolename AND ApplicationName = @ApplicationName", conn);

            cmd.Parameters.Add("@Username", VistaDBType.VarChar, 255).Value = username;
            cmd.Parameters.Add("@Rolename", VistaDBType.VarChar, 255).Value = roleName;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();
                int numRecs = (int)cmd.ExecuteScalar();

                if (numRecs > 0)
                    userIsInRole = true;
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "IsUserInRole");
                else
                    throw e;
            }
            finally
            {
                conn.Close();
            }

            return userIsInRole;
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            foreach (string rolename in roleNames)
            {
                if (!RoleExists(rolename))
                    throw new ProviderException("Role name not found.");
            }

            foreach (string username in usernames)
            {
                foreach (string rolename in roleNames)
                {
                    if (!IsUserInRole(username, rolename))
                        throw new ProviderException("User is not in role.");
                }
            }

            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("DELETE FROM UsersInRoles " +
                    " WHERE Username = @Username AND Rolename = @Rolename AND ApplicationName = @ApplicationName", conn);

            VistaDBParameter userParm = cmd.Parameters.Add("@Username", VistaDBType.VarChar, 255);
            VistaDBParameter roleParm = cmd.Parameters.Add("@Rolename", VistaDBType.VarChar, 255);
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            VistaDBTransaction tran = null;

            try
            {
                conn.Open();
                tran = conn.BeginTransaction();
                cmd.Transaction = tran;

                foreach (string username in usernames)
                {
                    foreach (string rolename in roleNames)
                    {
                        userParm.Value = username;
                        roleParm.Value = rolename;
                        cmd.ExecuteNonQuery();
                    }
                }

                tran.Commit();
            }
            catch (VistaDBException e)
            {
                try
                {
                    tran.Rollback();
                }
                catch { }
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "RemoveUsersFromRoles");
                else
                    throw e;
            }
            finally
            {
                conn.Close();
            }
        }

        public override bool RoleExists(string roleName)
        {
            bool exists = false;

            VistaDBConnection conn = new VistaDBConnection(connectionString);
            VistaDBCommand cmd = new VistaDBCommand("SELECT COUNT(*) FROM Roles " +
                      " WHERE Rolename = @Rolename AND ApplicationName = @ApplicationName", conn);

            cmd.Parameters.Add("@Rolename", VistaDBType.VarChar, 255).Value = roleName;
            cmd.Parameters.Add("@ApplicationName", VistaDBType.VarChar, 255).Value = ApplicationName;

            try
            {
                conn.Open();
                int numRecs = (int)cmd.ExecuteScalar();

                if (numRecs > 0)
                    exists = true;
            }
            catch (VistaDBException e)
            {
                if (WriteExceptionsToEventLog)
                    WriteToEventLog(e, "RoleExists");
                else
                    throw e;
            }
            finally
            {
                conn.Close();
            }

            return exists;
        }

        private void WriteToEventLog(VistaDBException e, string action)
        {
            EventLog log = new EventLog();
            log.Source = eventSource;
            log.Log = eventLog;

            string message = exceptionMessage + "\n";
            message += "Action: " + action + "\n";
            message += "Exception: " + e.ToString();
            try
            {
                log.WriteEntry(message);
            }
            catch (Exception ex) { }
        }
    }
}
