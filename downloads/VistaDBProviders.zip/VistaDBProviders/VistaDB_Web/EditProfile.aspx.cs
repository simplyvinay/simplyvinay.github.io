using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class EditProfile : System.Web.UI.Page
{
    private string userName = "";

    public string UserName
    {
        get { return userName; }
        set { userName = value; }
    }

    public void SaveProfile()
    {
        UserName = this.User.Identity.Name;
        ProfileCommon profile = this.Profile;
        if (this.UserName.Length > 0)
            profile = this.Profile.GetProfile(this.UserName);

        profile.FirstName = txtFirstName.Text;
        profile.LastName = txtLastName.Text;
        profile.Gender = ddlGenders.SelectedValue;
        if (txtBirthDate.Text.Trim().Length > 0)
            profile.BirthDate = txtBirthDate.Text;
        profile.Occupation = ddlOccupations.SelectedValue;
        profile.Website = txtWebsite.Text;
        profile.Address.Street = txtStreet.Text;
        profile.Address.City = txtCity.Text;
        profile.Address.PostalCode = txtPostalCode.Text;
        profile.Address.State = txtState.Text;
        profile.Address.Country = ddlCountries.SelectedValue;
        profile.Save();
        Response.Redirect("~/default.aspx");
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            UserName = this.User.Identity.Name;
            ProfileCommon profile = Profile;
            if (UserName.Length > 0)
                profile = Profile.GetProfile(UserName);

            txtFirstName.Text = profile.FirstName;
            txtLastName.Text = profile.LastName;
            ddlGenders.SelectedValue = profile.Gender;
            if (!string.IsNullOrEmpty(profile.BirthDate))
            {
                if (Convert.ToDateTime(profile.BirthDate) != DateTime.MinValue)
                    txtBirthDate.Text = Convert.ToDateTime(profile.BirthDate).ToShortDateString(); 
            }
            ddlOccupations.SelectedValue = profile.Occupation;
            txtWebsite.Text = profile.Website;
            txtStreet.Text = profile.Address.Street;
            txtCity.Text = profile.Address.City;
            txtPostalCode.Text = profile.Address.PostalCode;
            txtState.Text = profile.Address.State;
            ddlCountries.SelectedValue = profile.Address.Country;
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SaveProfile();
    }
}
