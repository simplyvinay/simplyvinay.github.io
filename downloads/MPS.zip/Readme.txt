Modifiy these file to include your email id and password

1)register.aspx
2)passwordrecovery.aspx
3)web.config


