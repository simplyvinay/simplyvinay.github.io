﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web.UI.WebControls;
using ICSharpCode.SharpZipLib.Zip;
using MPS.BLL.PhotoGallery;

namespace MPS.UI
{
    public partial class Admin_Photos : PageBase
    {

		#region Fields (1) 

        private int albumID = 0;

		#endregion Fields 

		#region Methods (4) 


		// Public Methods (1) 

        public byte[] GetFileStream(System.Web.HttpPostedFile objFile)
        {
            if (objFile != null)
            {
                int len = objFile.ContentLength;
                byte[] input = new byte[len];
                System.IO.Stream file = objFile.InputStream;
                file.Read(input, 0, len);
                return input;
            }
            return null;
        }



		// Protected Methods (3) 

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            int albumID = 0;
            albumID = int.Parse(Request.QueryString["AlbumID"]);

            List<string> goodFiles = new List<string>(),
                badFiles = new List<string>();

            byte[] archiveData = GetFileStream(fileUpload.PostedFile), fileData;
            MemoryStream ms = new MemoryStream(archiveData);

            if (fileUpload.PostedFile.FileName != "")
            {
                if (fileUpload.PostedFile.FileName.EndsWith(".zip"))
                {
                    using (ZipInputStream zip = new ZipInputStream(ms))
                    {
                        ZipEntry theEntry;
                        while ((theEntry = zip.GetNextEntry()) != null)
                        {
                            string fileName = Path.GetFileName(theEntry.Name);

                            if (!String.IsNullOrEmpty(fileName))
                            {
                                Photo photo = new Photo(0, albumID, "", "\\" + int.Parse(Request.QueryString["AlbumID"]) + "\\" + fileName, 0);

                                // Read the next file from the Zip stream
                                using (MemoryStream currentFileData = new MemoryStream((int)theEntry.Size))
                                {
                                    int size = 2048;
                                    byte[] data = new byte[size];
                                    while (true)
                                    {
                                        size = zip.Read(data, 0, data.Length);
                                        if (size > 0)
                                        {
                                            currentFileData.Write(data, 0, size);
                                        }
                                        else break;
                                    }

                                    fileData = currentFileData.ToArray();
                                }

                                try
                                {
                                    if (!File.Exists(System.Web.HttpContext.Current.Server.MapPath("../" + Globals.Settings.PhotoGallery.AlbumsFolder + "/" + int.Parse(Request.QueryString["AlbumID"]) + "/" + fileName)))
                                    {
                                        // Attempt insertion as a new photo
                                        int photoID = Photo.InsertPhoto(photo.AlbumID, photo.PhotoCaption, photo.Location, theEntry.Name, fileData);
                                        if (photoID > 0)
                                        {
                                            goodFiles.Add(theEntry.Name);
                                        }
                                        else
                                        {
                                            badFiles.Add(theEntry.Name);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    badFiles.Add(theEntry.Name + " (" + ex.Message + ")");
                                }
                            }
                        }
                    }
                }
                else
                {
                    Photo photo = new Photo(0, albumID, "", "\\" + int.Parse(Request.QueryString["AlbumID"]) + "\\" + fileUpload.FileName, 0);
                    int photoID = Photo.InsertPhoto(photo.AlbumID, txtCaption.Text, photo.Location, fileUpload.FileName, fileUpload.FileBytes);
                    if (photoID > 0)
                    {
                        goodFiles.Add(fileUpload.FileName);
                    }
                    else
                    {
                        badFiles.Add(fileUpload.FileName);
                    }
                }
                lblMsg.Visible = true;
                lblMsg.Text = string.Format(lblMsg.Text, goodFiles.Count, badFiles.Count);
                dlstPhotos.DataBind();
            }
        }

        protected void dlstPhotos_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                int photoID = int.Parse(e.CommandArgument.ToString());
                Photo.DeletePhoto(photoID);
                dlstPhotos.DataBind();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Request.QueryString["AlbumID"]))
                throw new ApplicationException("Missing parameter on the querystring.");
            else
                albumID = int.Parse(Request.QueryString["AlbumID"]);

            // try to load the album with the specified ID, and raise an exception
            // if it doesn't exist
            Album album = Album.GetAlbumsByID(albumID);
            if (album == null)
                throw new ApplicationException("No album was found for the specified ID.");
            else
            {
                int photoCount = Photo.GetPhotoCount(albumID);
                lblHead.Text = string.Format(lblHead.Text, album.Caption, photoCount.ToString());
            }
            // if the album has the IsPublic = false, and the current user is anonymous,
            // redirect to the login page
            if (!album.IsPublic && !User.Identity.IsAuthenticated)
                RequestLogin();

        }


		#endregion Methods 

    }
}
