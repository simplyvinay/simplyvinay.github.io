﻿using System;
using System.Web.UI.WebControls;

namespace MPS.UI
{
    public partial class Admin_ManageComments : PageBase
    {

		#region Methods (9) 


		// Protected Methods (8) 

        protected void ddlCommentsPerPage_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvwComments.PageIndex = 0;
            gvwComments.PageSize = int.Parse(ddlCommentsPerPage.SelectedValue);
            CancelCurrentEdit();
        }

        protected void dvwComment_ItemCommand(object sender, DetailsViewCommandEventArgs e)
        {
            if (e.CommandName == "Cancel")
                CancelCurrentEdit();
        }

        protected void dvwComment_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
        {
            CancelCurrentEdit();
        }

        protected void gvwComments_PageIndexChanged(object sender, EventArgs e)
        {
            CancelCurrentEdit();
        }

        protected void gvwComments_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton btn = e.Row.Cells[2].Controls[0] as ImageButton;
                btn.OnClientClick =
                    "if (confirm('Are you sure you want to delete this comment?') == false) return false;";
            }
        }

        protected void gvwComments_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            CancelCurrentEdit();
        }

        protected void gvwComments_SelectedIndexChanged(object sender, EventArgs e)
        {
            dvwComment.ChangeMode(DetailsViewMode.Edit);
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }



		// Private Methods (1) 

        private void CancelCurrentEdit()
        {
            dvwComment.ChangeMode(DetailsViewMode.ReadOnly);
            gvwComments.SelectedIndex = -1;
            gvwComments.DataBind();
        }


		#endregion Methods 

    }
}
