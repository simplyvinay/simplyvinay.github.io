﻿using System;
using System.Web.UI.WebControls;

namespace MPS.UI
{
    public partial class Admin_ManageAlbums : PageBase
    {

		#region Methods (8) 


		// Protected Methods (8) 

        protected void dvwAlbum_DataBound(object sender, EventArgs e)
        {
            if (dvwAlbum.CurrentMode == DetailsViewMode.Insert)
            {
                CheckBox chkIsPublic = dvwAlbum.FindControl("chkIsPublic") as CheckBox;
                chkIsPublic.Checked = true;
            }
        }

        protected void dvwAlbum_ItemCommand(object sender, DetailsViewCommandEventArgs e)
        {
            if (e.CommandName == "Cancel")
            {
                gvwCategories.SelectedIndex = -1;
                gvwCategories.DataBind();
            }
        }

        protected void dvwAlbum_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
        {
            gvwCategories.SelectedIndex = -1;
            gvwCategories.DataBind();
        }

        protected void dvwAlbum_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
        {
            gvwCategories.SelectedIndex = -1;
            gvwCategories.DataBind();
        }

        protected void gvwCategories_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton btn = e.Row.Cells[3].Controls[0] as ImageButton;
                btn.OnClientClick =
                    "if (confirm('Are you sure you want to delete this album?') == false) return false;";
            }
        }

        protected void gvwCategories_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            gvwCategories.SelectedIndex = -1;
            gvwCategories.DataBind();
            dvwAlbum.ChangeMode(DetailsViewMode.Insert);
        }

        protected void gvwCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            dvwAlbum.ChangeMode(DetailsViewMode.Edit);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // if a ID param is present on the querystring, switch to Edit mode for that blog,
                // but only after checking that the current user is an Administrator
                if (!string.IsNullOrEmpty(Request.QueryString["ID"]))
                {
                    if (User.Identity.IsAuthenticated &&
                        (User.IsInRole("Administrators")))
                    {
                        dvwAlbum.ChangeMode(DetailsViewMode.Edit);
                    }
                    else
                    {
                        //   throw new SecurityException("You are not allowed to edit existent articles!");
                    }
                }
                lblNewAlbum.Text = string.Format(lblNewAlbum.Text, MPS.BLL.PhotoGallery.Photo.GetPhotoCount());
            }
        }


		#endregion Methods 

    }
}
