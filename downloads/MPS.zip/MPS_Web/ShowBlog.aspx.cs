﻿using System;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using MPS.BLL.Blogs;

namespace MPS.UI
{
    public partial class ShowBlog : PageBase
    {

		#region Fields (2) 

        private int blogID = 0;
        private bool userCanEdit = false;

		#endregion Fields 

		#region Properties (1) 

        protected bool UserCanEdit
        {
            get { return userCanEdit; }
            set { userCanEdit = value; }
        }

		#endregion Properties 

		#region Methods (12) 


		// Protected Methods (12) 

        protected void btnApprove_Click(object sender, ImageClickEventArgs e)
        {
            Blog.ApproveBlog(blogID);
            btnApprove.Visible = false;
        }

        protected void btnDelete_Click(object sender, ImageClickEventArgs e)
        {
            Blog.DeleteBlog(blogID);
            Response.Redirect("Default.aspx", false);
        }

        protected void dlstComments_ItemCommand(object sender, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                int commentID = int.Parse(e.CommandArgument.ToString());
                Comment.DeleteComment(commentID);
                dvwComment.ChangeMode(DetailsViewMode.Insert);
                dlstComments.SelectedIndex = -1;
                dlstComments.DataBind();
            }
        }

        protected void dlstComments_SelectedIndexChanged(object sender, EventArgs e)
        {
            dvwComment.ChangeMode(DetailsViewMode.Edit);
        }

        protected void dvwComment_ItemCommand(object sender, DetailsViewCommandEventArgs e)
        {
            if (e.CommandName == "Cancel")
            {
                dlstComments.SelectedIndex = -1;
                dlstComments.DataBind();
            }
        }

        protected void dvwComment_ItemCreated(object sender, EventArgs e)
        {
            // when in Insert Mode, pre-fill the username and e-mail fields with the
            // current user's information, if she is authenticated
            if (dvwComment.CurrentMode == DetailsViewMode.Insert &&
                User.Identity.IsAuthenticated)
            {
                MembershipUser user = Membership.GetUser();
                (dvwComment.FindControl("txtAddedBy") as TextBox).Text = user.UserName;
                (dvwComment.FindControl("txtAddedByEmail") as TextBox).Text = user.Email;
            }
        }

        protected void dvwComment_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
        {
            dlstComments.SelectedIndex = -1;
            dlstComments.DataBind();
        }

        protected void dvwComment_ItemInserting(object sender, DetailsViewInsertEventArgs e)
        {
            try
            {
                TextBox t1 = dvwComment.FindControl("txtAddedBy") as TextBox;
                TextBox t2 = dvwComment.FindControl("txtAddedByEmail") as TextBox;
                TextBox t3 = dvwComment.FindControl("txtAddedByHomePage") as TextBox;
                TextBox t4 = dvwComment.FindControl("txtBody") as TextBox;
                objCurrComment.InsertParameters.Add("addedBy", t1.Text);
                objCurrComment.InsertParameters.Add("addedByEmail", t2.Text);
                objCurrComment.InsertParameters.Add("addedByHomePage", t3.Text);
                objCurrComment.InsertParameters.Add("blogID", blogID.ToString());
                objCurrComment.InsertParameters.Add("commentText", t4.Text);
            }
            catch { }
        }

        protected void dvwComment_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
        {
            dlstComments.SelectedIndex = -1;
            dlstComments.DataBind();
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            UserCanEdit = (User.Identity.IsAuthenticated &&
                           (User.IsInRole("Administrators")));
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            this.Page.Title = (Request.RawUrl.ToString().Substring(Request.RawUrl.LastIndexOf('/') + 1, Request.RawUrl.Length - 5 - (Request.RawUrl.LastIndexOf('/') + 1))).Replace('-', ' ');

            if (Request.QueryString["ID"] != null)
            {
                blogID = Convert.ToInt32(Request.QueryString["ID"]);
            }
            else
            {
                if (string.IsNullOrEmpty(Request.QueryString["ID"]))
                    throw new ApplicationException("Missing parameter on the querystring.");
                else
                    blogID = int.Parse(Request.QueryString["ID"]);
            }

            if (!IsPostBack)
            {
                objComments.SelectParameters.Add("blogID", blogID.ToString());
            }

            // try to load the blog with the specified ID, and raise an exception
            // if it doesn't exist
            Blog blog = Blog.GetBlogByID(blogID);
            if (blog == null)
                throw new ApplicationException("No blog was found for the specified ID.");

            // Check whether the blog is published.
            // If not, continue only if the current user is an Administrator or an Editor
            if (!blog.Published)
            {
                if (!UserCanEdit)
                {
                    //                    throw new SecurityException(
                    //                        @"What are you trying to do??? 
                    //                  You're not allowed to do view this blog!");
                }
            }

            // if the blog has the OnlyForMembers = true, and the current user is anonymous,
            // redirect to the login page
            if (blog.IsOnlyForMembers && !User.Identity.IsAuthenticated)
                RequestLogin();

            blog.IncrementViewCount();

            // if we get here, display all blog's data on the page
            Title = string.Format(Title, blog.BlogTitle);
            lblNotApproved.Visible = !blog.IsPublished;
            lnkTitle.Text = blog.BlogTitle;
            //lnkTitle.NavigateUrl = "~/ShowBlog.aspx?ID=" + blogID;
            lnkTitle.NavigateUrl = Request.RawUrl;
            perma.NavigateUrl = Request.RawUrl;
            lblAddedBy.Text = blog.AddedBy;
            lblReleaseDate.Text = string.Format("{0:f}", blog.AddedDate);
            lblCategory.Text = blog.CategoryTitle;
            lblCategory.NavigateUrl = "~/Category/" + blog.CategoryID + "/Default.aspx";
            lblViews.Text = string.Format(lblViews.Text, blog.ViewCount);
            lblComments.Text = string.Format(lblComments.Text, blog.Comments.Count);
            lblBody.Text = blog.BlogText;
            panComments.Visible = blog.IsCommentsEnabled;
            panEditBlog.Visible = UserCanEdit;
            btnApprove.Visible = !blog.IsPublished;
            lnkEditBlog.NavigateUrl = string.Format(lnkEditBlog.NavigateUrl, blogID);
        }

        protected void valAntiBotImage_ServerValidate(object source, ServerValidateEventArgs args)
        {
            args.IsValid = (Session["antibotimage"] != null) && ((dvwComment.FindControl("txtAntiBotImage") as TextBox).Text.Trim().ToUpper() == (string)Session["antibotimage"]);
        }


		#endregion Methods 

    }
}
