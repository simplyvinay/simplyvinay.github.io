using System;

namespace MPS.UI
{
    public partial class AccessDenied : PageBase
    {

		#region�Methods�(1)�


		//�Protected�Methods�(1)�

        protected void Page_Load(object sender, EventArgs e)
        {
            lblInsufficientPermissions.Visible = User.Identity.IsAuthenticated;
            lblLoginRequired.Visible = (!User.Identity.IsAuthenticated &&
               string.IsNullOrEmpty(Request.QueryString["loginfailure"]));
            lblInvalidCredentials.Visible = (Request.QueryString["loginfailure"] != null &&
               Request.QueryString["loginfailure"] == "1");
        }


		#endregion�Methods�

    }
}
