using System;
using System.Net.Mail;

namespace MPS.UI
{
    public partial class EditProfile : PageBase
    {

		#region�Methods�(2)�


		//�Protected�Methods�(2)�

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            UserProfile1.SaveProfile();
            lblFeedbackOK.Visible = true;
        }

        protected void ChangePassword1_SendingMail(object sender, System.Web.UI.WebControls.MailMessageEventArgs e)
        {
            try
            {
                SmtpClient smtp = new SmtpClient(Globals.Settings.Mail.Smtp, Globals.Settings.Mail.Port);
                smtp.EnableSsl = true;

                smtp.Credentials = new System.Net.NetworkCredential(Globals.Settings.Mail.Username, Globals.Settings.Mail.Password);
                smtp.Send(e.Message);
                e.Cancel = true;
            }
            catch (Exception ex)
            {

            }
        }


		#endregion�Methods�

    }
}
