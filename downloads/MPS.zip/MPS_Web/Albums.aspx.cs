﻿using System;
using MPS.BLL.PhotoGallery;

namespace MPS.UI
{
    public partial class Albums : PageBase
    {

		#region Fields (1) 

        private bool userCanEdit = false;

		#endregion Fields 

		#region Properties (1) 

        public bool UserCanEdit
        {
            get { return userCanEdit; }
            set { userCanEdit = value; }
        }

		#endregion Properties 

		#region Methods (2) 


		// Protected Methods (2) 

        protected void Page_Init(object sender, EventArgs e)
        {
            UserCanEdit = (Page.User.Identity.IsAuthenticated &&
                           (Page.User.IsInRole("Administrators")));
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblHead.Text = string.Format(lblHead.Text, Photo.GetPhotoCount());
            }
        }


		#endregion Methods 

    }
}
