﻿using System;
using System.Net.Mail;
using System.Web.UI.WebControls;

namespace MPS.UI
{
    public partial class PasswordRecovery : PageBase
    {

		#region Methods (2) 


		// Protected Methods (2) 

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void PasswordRecovery1_SendingMail(object sender, MailMessageEventArgs e)
        {
            try
            {
                SmtpClient smtp = new SmtpClient(Globals.Settings.Mail.Smtp, Globals.Settings.Mail.Port);
                smtp.EnableSsl = true;

                smtp.Credentials = new System.Net.NetworkCredential(Globals.Settings.Mail.Username, Globals.Settings.Mail.Password);
                smtp.Send(e.Message);
                e.Cancel = true;
            }
            catch (Exception ex)
            {

            }
        }


		#endregion Methods 

    }
}