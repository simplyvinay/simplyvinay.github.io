using System;

namespace MPS.UI
{
    public partial class Controls_UserProfile : System.Web.UI.UserControl
    {

		#region�Fields�(1)�

        private string userName = "";

		#endregion�Fields�

		#region�Properties�(1)�

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }

		#endregion�Properties�

		#region�Methods�(5)�


		//�Public�Methods�(1)�

        public void SaveProfile()
        {
            // if the UserName property contains an emtpy string, save the current user's
            // profile, othwerwise save the profile for the specified user
            ProfileCommon profile = this.Profile;
            if (this.UserName.Length > 0)
                profile = this.Profile.GetProfile(this.UserName);

            profile.FirstName = txtFirstName.Text;
            profile.LastName = txtLastName.Text;
            profile.Gender = ddlGenders.SelectedValue;
            if (txtBirthDate.Text.Trim().Length > 0)
                profile.BirthDate = DateTime.Parse(txtBirthDate.Text);
            profile.Occupation = ddlOccupations.SelectedValue;
            profile.Website = txtWebsite.Text;
            profile.Address.Street = txtStreet.Text;
            profile.Address.City = txtCity.Text;
            profile.Address.PostalCode = txtPostalCode.Text;
            profile.Address.State = txtState.Text;
            profile.Address.Country = ddlCountries.SelectedValue;
            profile.Save();
        }



		//�Protected�Methods�(4)�

        protected override void LoadControlState(object savedState)
        {
            object[] ctlState = (object[])savedState;
            base.LoadControlState(ctlState[0]);
            userName = (string)ctlState[1];
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            this.Page.RegisterRequiresControlState(this);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ddlCountries.DataSource = Helpers.GetCountries();
                ddlCountries.DataBind();

                // if the UserName property contains an emtpy string, retrieve the profile
                // for the current user, otherwise for the specified user
                ProfileCommon profile = Profile;
                if (UserName.Length > 0)
                    profile = Profile.GetProfile(UserName);

                txtFirstName.Text = profile.FirstName;
                txtLastName.Text = profile.LastName;
                ddlGenders.SelectedValue = profile.Gender;
                if (profile.BirthDate != DateTime.MinValue)
                    txtBirthDate.Text = profile.BirthDate.ToShortDateString();
                ddlOccupations.SelectedValue = profile.Occupation;
                txtWebsite.Text = profile.Website;
                txtStreet.Text = profile.Address.Street;
                txtCity.Text = profile.Address.City;
                txtPostalCode.Text = profile.Address.PostalCode;
                txtState.Text = profile.Address.State;
                ddlCountries.SelectedValue = profile.Address.Country;
            }
        }

        protected override object SaveControlState()
        {
            object[] ctlState = new object[2];
            ctlState[0] = base.SaveControlState();
            ctlState[1] = userName;
            return ctlState;
        }


		#endregion�Methods�

    }
}
