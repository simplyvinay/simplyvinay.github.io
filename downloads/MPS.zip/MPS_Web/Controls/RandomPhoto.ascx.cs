﻿using System;
using MPS.BLL.PhotoGallery;

namespace MPS.UI
{
    public partial class Controls_RandomPhoto : System.Web.UI.UserControl
    {

		#region Methods (1) 


		// Protected Methods (1) 

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dlstRandom.DataSource = Photo.GetRandomPhoto();
                dlstRandom.DataBind();
            }
        }


		#endregion Methods 

    }
}
