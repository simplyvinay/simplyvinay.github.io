using System;
using System.Net.Mail;
using System.Web.Security;
using System.Web.UI.WebControls;

namespace MPS.UI
{
    public partial class Register : PageBase
    {

		#region�Fields�(1)�

        protected string Email = "";

		#endregion�Fields�

		#region�Methods�(4)�


		//�Protected�Methods�(4)�

        protected void CreateUserWizard1_CreatedUser(object sender, EventArgs e)
        {
            // add the current user to the Posters role
            Roles.AddUserToRole(CreateUserWizard1.UserName, "Users");
        }

        protected void CreateUserWizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
        {
            UserProfile1.SaveProfile();
        }

        protected void CreateUserWizard1_SendingMail(object sender, MailMessageEventArgs e)
        {
            try
            {
                SmtpClient smtp = new SmtpClient(Globals.Settings.Mail.Smtp, Globals.Settings.Mail.Port);
                smtp.EnableSsl = true;

                smtp.Credentials = new System.Net.NetworkCredential(Globals.Settings.Mail.Username, Globals.Settings.Mail.Password);
                smtp.Send(e.Message);
                e.Cancel = true;
            }
            catch (Exception ex)
            {

            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack && !string.IsNullOrEmpty(Request.QueryString["Email"]))
            {
                Email = Request.QueryString["Email"];
                CreateUserWizard1.DataBind();
            }
        }


		#endregion�Methods�

    }
}
