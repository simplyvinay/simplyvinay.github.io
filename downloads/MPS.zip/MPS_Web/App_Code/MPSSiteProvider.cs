﻿using System.Web;

namespace MPS
{
    public class MPSSiteProvider : XmlSiteMapProvider
    {

		#region Methods (1) 


		// Public Methods (1) 

        public override SiteMapNode FindSiteMapNode(string rawUrl)
        {
            if (rawUrl.Contains("Post"))
            {
                rawUrl = "~/ShowBlog.aspx";
            }
            if (rawUrl.Contains("Category"))
            {
                rawUrl = "~/Default.aspx";
            }
            if (rawUrl.Contains("Albums") && rawUrl.Contains("Photos"))
            {
                rawUrl = "~/Photos.aspx";
            }
            return base.FindSiteMapNode(rawUrl);
        }


		#endregion Methods 

    }
}
