using System.Web.Configuration;

namespace MPS
{
    public static class Globals
    {

		#region�Fields�(1)�

        public readonly static MPSSection Settings =
           (MPSSection)WebConfigurationManager.GetSection("MPS");

		#endregion�Fields�

    }
}
