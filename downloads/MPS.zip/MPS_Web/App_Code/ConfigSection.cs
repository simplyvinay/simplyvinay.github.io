using System.Configuration;
using System.Web.Configuration;

namespace MPS
{
    public class MPSSection : ConfigurationSection
    {

		#region�Properties�(8)�

        [ConfigurationProperty("blogs", IsRequired = true)]
        public BlogElement Blogs
        {
            get { return (BlogElement)base["blogs"]; }
        }

        [ConfigurationProperty("contactForm", IsRequired = true)]
        public ContactFormElement ContactForm
        {
            get { return (ContactFormElement)base["contactForm"]; }
        }

        [ConfigurationProperty("defaultCacheDuration", DefaultValue = "600")]
        public int DefaultCacheDuration
        {
            get { return (int)base["defaultCacheDuration"]; }
            set { base["defaultCacheDuration"] = value; }
        }

        [ConfigurationProperty("defaultConnectionStringName", DefaultValue = "LocalSqlServer")]
        public string DefaultConnectionStringName
        {
            get { return (string)base["defaultConnectionStringName"]; }
            set { base["connectionStdefaultConnectionStringNameringName"] = value; }
        }

        [ConfigurationProperty("guestBook", IsRequired = true)]
        public GuestBookElement GuestBook
        {
            get { return (GuestBookElement)base["guestBook"]; }
        }

        [ConfigurationProperty("mail", IsRequired = true)]
        public MailElement Mail
        {
            get { return (MailElement)base["mail"]; }
        }

        [ConfigurationProperty("photoGallery", IsRequired = true)]
        public PhotoGalleryElement PhotoGallery
        {
            get { return (PhotoGalleryElement)base["photoGallery"]; }
        }

        [ConfigurationProperty("siteSettings", IsRequired = true)]
        public SiteSettingsElement SiteSettings
        {
            get { return (SiteSettingsElement)base["siteSettings"]; }
        }

		#endregion�Properties�

    }

    public class ContactFormElement : ConfigurationElement
    {
        #region�Properties�(3)
        
        [ConfigurationProperty("mailSubject",
           DefaultValue = "Mail from MPS : {0}")]
        public string MailSubject
        {
            get { return (string)base["mailSubject"]; }
            set { base["mailSubject"] = value; }
        }

        [ConfigurationProperty("mailTo", IsRequired = true)]
        public string MailTo
        {
            get { return (string)base["mailTo"]; }
            set { base["mailTo"] = value; }
        }

        [ConfigurationProperty("mailCC")]
        public string MailCC
        {
            get { return (string)base["mailCC"]; }
            set { base["mailCC"] = value; }
        }

        #endregion�Properties
    }

    public class MailElement : ConfigurationElement
    {

		#region�Properties�(4)�

        [ConfigurationProperty("password", DefaultValue = "yourpassword")]
        public string Password
        {
            get { return (string)base["password"]; }
            set { base["password"] = value; }
        }

        [ConfigurationProperty("port", DefaultValue = "25")]
        public int Port
        {
            get { return (int)base["port"]; }
            set { base["port"] = value; }
        }

        [ConfigurationProperty("smtp",
           DefaultValue = "smtp.gmail.com")]
        public string Smtp
        {
            get { return (string)base["smtp"]; }
            set { base["smtp"] = value; }
        }

        [ConfigurationProperty("username", DefaultValue = "yourmailid")]
        public string Username
        {
            get { return (string)base["username"]; }
            set { base["username"] = value; }
        }

		#endregion�Properties�

    }

    public class BlogElement : ConfigurationElement
    {

		#region�Properties�(8)�

        [ConfigurationProperty("cacheDuration")]
        public int CacheDuration
        {
            get
            {
                int duration = (int)base["cacheDuration"];
                return (duration > 0 ? duration : Globals.Settings.DefaultCacheDuration);
            }
            set { base["cacheDuration"] = value; }
        }

        public string ConnectionString
        {
            get
            {
                string connStringName = (string.IsNullOrEmpty(this.ConnectionStringName) ?
                   Globals.Settings.DefaultConnectionStringName :
                   this.ConnectionStringName);
                return WebConfigurationManager.ConnectionStrings[
                   connStringName].ConnectionString;
            }
        }

        [ConfigurationProperty("connectionStringName")]
        public string ConnectionStringName
        {
            get { return (string)base["connectionStringName"]; }
            set { base["connectionStringName"] = value; }
        }

        [ConfigurationProperty("enableCaching", DefaultValue = "true")]
        public bool EnableCaching
        {
            get { return (bool)base["enableCaching"]; }
            set { base["enableCaching"] = value; }
        }

        [ConfigurationProperty("excerptLength", DefaultValue = "1024")]
        public int ExcerptLength
        {
            get { return (int)base["excerptLength"]; }
            set { base["excerptLength"] = value; }
        }

        [ConfigurationProperty("pageSize", DefaultValue = "10")]
        public int PageSize
        {
            get { return (int)base["pageSize"]; }
            set { base["pageSize"] = value; }
        }

        [ConfigurationProperty("providerType",
           DefaultValue = "MPS.DAL.SqlClient.SqlBlogsProvider")]
        public string ProviderType
        {
            get { return (string)base["providerType"]; }
            set { base["providerType"] = value; }
        }

        [ConfigurationProperty("rssItems", DefaultValue = "5")]
        public int RssItems
        {
            get { return (int)base["rssItems"]; }
            set { base["rssItems"] = value; }
        }

		#endregion�Properties�

    }

    public class GuestBookElement : ConfigurationElement
    {

		#region�Properties�(6)�

        [ConfigurationProperty("cacheDuration")]
        public int CacheDuration
        {
            get
            {
                int duration = (int)base["cacheDuration"];
                return (duration > 0 ? duration : Globals.Settings.DefaultCacheDuration);
            }
            set { base["cacheDuration"] = value; }
        }

        public string ConnectionString
        {
            get
            {
                string connStringName = (string.IsNullOrEmpty(this.ConnectionStringName) ?
                   Globals.Settings.DefaultConnectionStringName :
                   this.ConnectionStringName);
                return WebConfigurationManager.ConnectionStrings[
                   connStringName].ConnectionString;
            }
        }

        [ConfigurationProperty("connectionStringName")]
        public string ConnectionStringName
        {
            get { return (string)base["connectionStringName"]; }
            set { base["connectionStringName"] = value; }
        }

        [ConfigurationProperty("enableCaching", DefaultValue = "true")]
        public bool EnableCaching
        {
            get { return (bool)base["enableCaching"]; }
            set { base["enableCaching"] = value; }
        }

        [ConfigurationProperty("pageSize", DefaultValue = "10")]
        public int PageSize
        {
            get { return (int)base["pageSize"]; }
            set { base["pageSize"] = value; }
        }

        [ConfigurationProperty("providerType",
           DefaultValue = "MPS.DAL.SqlClient.SqlGuestBookProvider")]
        public string ProviderType
        {
            get { return (string)base["providerType"]; }
            set { base["providerType"] = value; }
        }

		#endregion�Properties�

    }

    public class PhotoGalleryElement : ConfigurationElement
    {

		#region�Properties�(6)�

        [ConfigurationProperty("albumsFolder", DefaultValue = "Albums")]
        public string AlbumsFolder
        {
            get { return (string)base["albumsFolder"]; }
            set { base["albumsFolder"] = value; }
        }

        [ConfigurationProperty("cacheDuration")]
        public int CacheDuration
        {
            get
            {
                int duration = (int)base["cacheDuration"];
                return (duration > 0 ? duration : Globals.Settings.DefaultCacheDuration);
            }
            set { base["cacheDuration"] = value; }
        }

        public string ConnectionString
        {
            get
            {
                string connStringName = (string.IsNullOrEmpty(this.ConnectionStringName) ?
                   Globals.Settings.DefaultConnectionStringName :
                   this.ConnectionStringName);
                return WebConfigurationManager.ConnectionStrings[
                   connStringName].ConnectionString;
            }
        }

        [ConfigurationProperty("connectionStringName")]
        public string ConnectionStringName
        {
            get { return (string)base["connectionStringName"]; }
            set { base["connectionStringName"] = value; }
        }

        [ConfigurationProperty("enableCaching", DefaultValue = "true")]
        public bool EnableCaching
        {
            get { return (bool)base["enableCaching"]; }
            set { base["enableCaching"] = value; }
        }

        [ConfigurationProperty("providerType",
           DefaultValue = "MPS.DAL.SqlClient.SqlPhotoGalleryProvider")]
        public string ProviderType
        {
            get { return (string)base["providerType"]; }
            set { base["providerType"] = value; }
        }

		#endregion�Properties�

    }

    public class SiteSettingsElement : ConfigurationElement
    {

		#region�Properties�(5)�

        [ConfigurationProperty("cacheDuration")]
        public int CacheDuration
        {
            get
            {
                int duration = (int)base["cacheDuration"];
                return (duration > 0 ? duration : Globals.Settings.DefaultCacheDuration);
            }
            set { base["cacheDuration"] = value; }
        }

        public string ConnectionString
        {
            get
            {
                string connStringName = (string.IsNullOrEmpty(this.ConnectionStringName) ?
                   Globals.Settings.DefaultConnectionStringName :
                   this.ConnectionStringName);
                return WebConfigurationManager.ConnectionStrings[
                   connStringName].ConnectionString;
            }
        }

        [ConfigurationProperty("connectionStringName")]
        public string ConnectionStringName
        {
            get { return (string)base["connectionStringName"]; }
            set { base["connectionStringName"] = value; }
        }

        [ConfigurationProperty("enableCaching", DefaultValue = "true")]
        public bool EnableCaching
        {
            get { return (bool)base["enableCaching"]; }
            set { base["enableCaching"] = value; }
        }

        [ConfigurationProperty("providerType",
           DefaultValue = "MPS.DAL.SqlClient.SqlSiteSettingsProvider")]
        public string ProviderType
        {
            get { return (string)base["providerType"]; }
            set { base["providerType"] = value; }
        }

		#endregion�Properties�

    }
}


