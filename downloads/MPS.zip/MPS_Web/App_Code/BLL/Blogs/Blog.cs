using System;
using System.Collections.Generic;
using MPS.DAL;

namespace MPS.BLL.Blogs
{
    public class Blog : BaseBlog
    {

		#region�Fields�(13)�

        private Uri absoluteLink;
        private string blogText = "";
        private string blogTitle = "";
        private Category category = null;
        private int categoryID = 0;
        private string categoryTitle = "";
        private List<Comment> comments = null;
        private string excerptBlogText = "";
        private bool isCommentsEnabled = true;
        private bool isOnlyForMembers = true;
        private bool isPublished = true;
        private DateTime releaseDate = DateTime.Now;
        private int viewCount = 0;

		#endregion�Fields�

		#region�Constructors�(1)�

        public Blog(int id, DateTime addedDate, string addedBy,
                       int categoryID, string categoryTitle, string blogTitle, 
                       string blogText, string excerptBlogText, DateTime releaseDate, 
                       bool isPublished, bool isCommentsEnabled, 
                       bool isOnlyForMembers, int viewCount)
        {
            Id = id;
            AddedDate = addedDate;
            AddedBy = addedBy;
            CategoryID = categoryID;
            CategoryTitle = categoryTitle;
            BlogTitle = blogTitle;
            BlogText = blogText;
            ExcerptBlogText = excerptBlogText;
            ReleaseDate = releaseDate;
            IsPublished = isPublished;
            IsCommentsEnabled = isCommentsEnabled;
            IsOnlyForMembers = isOnlyForMembers;
            ViewCount = viewCount;
        }

		#endregion�Constructors�

		#region�Properties�(14)�

        public Uri AbsoluteLink
        {
            get { return absoluteLink; }
            set { absoluteLink = value; }
        }

        public string BlogText
        {
            get 
            {
                if (blogText == null)
                    blogText = SiteProvider.Blogs.GetBlogBody(Id);
                return blogText; 
            }
            set { blogText = value; }
        }

        public string BlogTitle
        {
            get { return blogTitle; }
            set { blogTitle = value; }
        }

        public Category Category
        {
            get 
            {
                if (category == null)
                    category = Category.GetCategoryByID(CategoryID);
                return category; 
            }
        }

        public int CategoryID
        {
            get { return categoryID; }
            set { categoryID = value; }
        }

        public string CategoryTitle
        {
            get { return categoryTitle; }
            set { categoryTitle = value; }
        }

        public List<Comment> Comments
        {
            get 
            {
                if (comments == null)
                    comments = Comment.GetComments(Id, 0, BizObject.MAXROWS);
                return comments; 
            }
        }

        public string ExcerptBlogText
        {
            get { return excerptBlogText; }
            set { excerptBlogText = value; }
        }

        public bool IsCommentsEnabled
        {
            get { return isCommentsEnabled; }
            set { isCommentsEnabled = value; }
        }

        public bool IsOnlyForMembers
        {
            get { return isOnlyForMembers; }
            set { isOnlyForMembers = value; }
        }

        public bool IsPublished
        {
            get { return isPublished; }
            set { isPublished = value; }
        }

        public bool Published
        {
            get
            {
                return (isPublished && ReleaseDate <= DateTime.Now );
            }
        }

        public DateTime ReleaseDate
        {
            get { return releaseDate; }
            set { releaseDate = value; }
        }

        public int ViewCount
        {
            get { return viewCount; }
            set { viewCount = value; }
        }

		#endregion�Properties�

		#region�Methods�(33)�


		//�Public�Methods�(30)�

        public bool Approve()
        {
            bool success = Blog.ApproveBlog(Id);
            if (success)
                IsPublished = true;
            return success;
        }

        /// <summary>
        /// Approves/Publish an existing blog
        /// </summary>
        public static bool ApproveBlog(int id)
        {
            bool ret = SiteProvider.Blogs.ApproveBlog(id);
            BizObject.PurgeCacheItems("Blogs_Blog_" + id.ToString());
            BizObject.PurgeCacheItems("Blogs_Blogs");
            return ret;
        }

        public bool Delete()
        {
            bool success = Blog.DeleteBlog(Id);
            if (success)
                Id = 0;
            return success;
        }

        /// <summary>
        /// Deletes an existing blog
        /// </summary>
        public static bool DeleteBlog(int id)
        {
            bool ret = SiteProvider.Blogs.DeleteBlog(id);
            //new RecordDeletedEvent("blog", id, null).Raise();
            BizObject.PurgeCacheItems("Blogs_Blog");
            try
            {
                TechnoratiUpdatePing();
            }
            catch
            {
            }
            return ret;
        }

        /// <summary>
        /// Returns the excerpted blog content
        /// </summary>
        public static string Excerpt(string Contents)
        {
            string contents = Contents;
            int excerptLength = BaseBlog.Settings.ExcerptLength;

            if (contents.ToLowerInvariant().Contains("<pre class=\"code\">") || contents.ToLowerInvariant().Contains("<pre class=code>"))
            {
                int n;
                n = contents.ToLowerInvariant().IndexOf("<pre");
                contents = contents.Substring(0, n - 1);
            }
            if (contents.Length > excerptLength)
            {
                int n;
                if ((n = contents.LastIndexOf("</p>", excerptLength, excerptLength, StringComparison.CurrentCultureIgnoreCase)) != -1)
                {
                    contents = contents.Substring(0, n + 4) + "...";
                }
                else if ((n = contents.LastIndexOf(' ', excerptLength, excerptLength)) != -1)
                {
                    contents = contents.Substring(0, n) + "...";
                }
                else
                {
                    contents = contents.Substring(0, excerptLength) + "...";
                }
            }
            else
            {
                contents = contents + "...";
            }
            return contents;
        }

        /// <summary>
        /// Returns the archive
        /// </summary>
        public static List<String> GetArchive()
        {
            List<String> archive = new List<string>();
            string key = "Blogs_BlogArchive";

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                archive = (List<String>)BizObject.Cache[key];
            }
            else
            {
                archive = SiteProvider.Blogs.GetArchive();
                BaseBlog.CacheData(key, archive);
            }
            return archive;
        }

        /// <summary>
        /// Returns an Blog object with the specified ID
        /// </summary>
        public static Blog GetBlogByID(int blogID)
        {
            Blog blog = null;
            string key = "Blogs_Blog_" + blogID.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blog = (Blog)BizObject.Cache[key];
            }
            else
            {
                blog = GetBlogFromBlogDetails(SiteProvider.Blogs.GetBlogByID(blogID));
                BaseBlog.CacheData(key, blog);
            }
            //blog.AbsoluteLink = GetAbsoluteLink(blog.blogTitle);
            return blog;
        }

        /// <summary>
        /// Returns an Blog object with the specified ID
        /// </summary>
        public static Blog GetBlogByTitle(string blogTitle)
        {
            Blog blog = null;
            string key = "Blogs_Blog_" + blogTitle.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blog = (Blog)BizObject.Cache[key];
            }
            else
            {
                blog = GetBlogFromBlogDetails(SiteProvider.Blogs.GetBlogByTitle(blogTitle));
                BaseBlog.CacheData(key, blog);
            }
            //blog.AbsoluteLink = GetAbsoluteLink(blog.blogTitle);
            return blog;
        }

        /// <summary>
        /// Returns the number of total blogs
        /// </summary>
        public static int GetBlogCount()
        {
            int blogCount = 0;
            string key = "Blogs_BlogCount";

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogCount = (int)BizObject.Cache[key];
            }
            else
            {
                blogCount = SiteProvider.Blogs.GetBlogCount();
                BaseBlog.CacheData(key, blogCount);
            }
            return blogCount;
        }

        /// <summary>
        /// Returns the number of total blogs for the specified category
        /// </summary>
        public static int GetBlogCount(int categoryID)
        {
            if (categoryID <= 0)
                return GetBlogCount();

            int blogCount = 0;
            string key = "Blogs_BlogCount_" + categoryID.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogCount = (int)BizObject.Cache[key];
            }
            else
            {
                blogCount = SiteProvider.Blogs.GetBlogCount(categoryID);
                BaseBlog.CacheData(key, blogCount);
            }
            return blogCount;
        }

        /// <summary>
        /// Returns the number of total blogs for the specified archive
        /// </summary>
        public static int GetBlogCount(DateTime date)
        {
            //if (categoryID <= 0)
            //    return GetBlogCount();

            int blogCount = 0;
            string key = "Blogs_BlogCount_" + date.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogCount = (int)BizObject.Cache[key];
            }
            else
            {
                blogCount = SiteProvider.Blogs.GetBlogCount(date);
                BaseBlog.CacheData(key, blogCount);
            }
            return blogCount;
        }

        /// <summary>
        /// Returns the number of total published blogs
        /// </summary>
        public static int GetBlogCount(bool publishedOnly)
        {
            if (publishedOnly)
                return GetBlogCount();

            int blogCount = 0;
            string key = "Blogs_BlogCount_" + publishedOnly.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogCount = (int)BizObject.Cache[key];
            }
            else
            {
                blogCount = SiteProvider.Blogs.GetPublishedBlogCount(DateTime.Now);
                BaseBlog.CacheData(key, blogCount);
            }
            return blogCount;
        }

        /// <summary>
        /// Returns the number of total published blogs for the specified category
        /// </summary>
        public static int GetBlogCount(bool publishedOnly, int categoryID)
        {
            if (!publishedOnly)
                return GetBlogCount(categoryID);

            if (categoryID <= 0)
                return GetBlogCount(publishedOnly);

            int blogCount = 0;
            string key = "Blogs_BlogCount_" + publishedOnly.ToString() + "_" + categoryID.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogCount = (int)BizObject.Cache[key];
            }
            else
            {
                blogCount = SiteProvider.Blogs.GetPublishedBlogCount(categoryID, DateTime.Now);
                BaseBlog.CacheData(key, blogCount);
            }
            return blogCount;
        }

        /// <summary>
        /// Returns the number of total published blogs for the specified category
        /// </summary>
        public static int GetBlogCount(bool publishedOnly, DateTime date)
        {
            if (!publishedOnly)
                return GetBlogCount(date);

            //if (categoryID <= 0)
            //    return GetBlogCount(publishedOnly);

            int blogCount = 0;
            string key = "Blogs_BlogCount_" + publishedOnly.ToString() + "_" + date.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogCount = (int)BizObject.Cache[key];
            }
            else
            {
                blogCount = SiteProvider.Blogs.GetPublishedBlogCount(date, DateTime.Now);
                BaseBlog.CacheData(key, blogCount);
            }
            return blogCount;
        }

        /// <summary>
        /// Returns a collection with all blogs
        /// </summary>
        public static List<Blog> GetBlogs()
        {
            return GetBlogs(0, BizObject.MAXROWS);
        }

        /// <summary>
        /// Returns a collection with all blogs for the specified category
        /// </summary>
        public static List<Blog> GetBlogs(int categoryID)
        {
            return GetBlogs(categoryID, 0, BizObject.MAXROWS);
        }

        public static List<Blog> GetBlogs(int categoryID, int startRowIndex, int maximumRows)
        {
            if (categoryID <= 0)
                return GetBlogs(startRowIndex, maximumRows);

            List<Blog> blogs = null;
            string key = "Blogs_Blogs_" + categoryID.ToString() + "_" + startRowIndex.ToString() + "_" +
                         maximumRows.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogs = (List<Blog>)BizObject.Cache[key];
            }
            else
            {
                List<BlogDetails> recordset = SiteProvider.Blogs.GetBlogs(categoryID,
                                                                                   GetPageIndex(startRowIndex,
                                                                                                maximumRows),
                                                                                   maximumRows);
                blogs = GetBlogListFromBlogDetailsList(recordset);
                BaseBlog.CacheData(key, blogs);
            }
            return blogs;
        }

        /// <summary>
        /// Returns a collection with all blogs for the specified month
        /// </summary>
        public static List<Blog> GetBlogs(DateTime date)
        {
            return GetBlogs(date, 0, BizObject.MAXROWS);
        }

        public static List<Blog> GetBlogs(DateTime date, int startRowIndex, int maximumRows)
        {
            /*if (categoryID <= 0)
                return GetBlogs(startRowIndex, maximumRows);*/

            List<Blog> blogs = null;
            string key = "Blogs_Blogs_" + date.ToShortDateString() + "_" + startRowIndex.ToString() + "_" +
                         maximumRows.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogs = (List<Blog>)BizObject.Cache[key];
            }
            else
            {
                List<BlogDetails> recordset = SiteProvider.Blogs.GetBlogs(date,
                                                                                   GetPageIndex(startRowIndex,
                                                                                                maximumRows),
                                                                                   maximumRows);
                blogs = GetBlogListFromBlogDetailsList(recordset);
                BaseBlog.CacheData(key, blogs);
            }
            return blogs;
        }

        /// <summary>
        /// Returns a collection with all published blogs
        /// </summary>
        public static List<Blog> GetBlogs(bool publishedOnly)
        {
            return GetBlogs(publishedOnly, 0, BizObject.MAXROWS);
        }

        public static List<Blog> GetBlogs(bool publishedOnly, int startRowIndex, int maximumRows)
        {
            if (!publishedOnly)
                return GetBlogs(startRowIndex, maximumRows);

            List<Blog> blogs = null;
            string key = "Blogs_Blogs_" + publishedOnly.ToString() + "_" + startRowIndex.ToString() + "_" +
                         maximumRows.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogs = (List<Blog>)BizObject.Cache[key];
            }
            else
            {
                List<BlogDetails> recordset = SiteProvider.Blogs.GetPublishedBlogs(DateTime.Now,
                                                                                            GetPageIndex(startRowIndex,
                                                                                                         maximumRows),
                                                                                            maximumRows);
                blogs = GetBlogListFromBlogDetailsList(recordset);
                BaseBlog.CacheData(key, blogs);
            }
            return blogs;
        }

        /// <summary>
        /// Returns a collection with all published blogs for the specified category
        /// </summary>
        public static List<Blog> GetBlogs(bool publishedOnly, int categoryID)
        {
            return GetBlogs(publishedOnly, categoryID, 0, BizObject.MAXROWS);
        }

        public static List<Blog> GetBlogs(bool publishedOnly, int categoryID, int startRowIndex, int maximumRows)
        {
            if (!publishedOnly)
                return GetBlogs(categoryID, startRowIndex, maximumRows);

            if (categoryID <= 0)
                return GetBlogs(publishedOnly, startRowIndex, maximumRows);

            List<Blog> blogs = null;
            string key = "Blogs_Blogs_" + publishedOnly.ToString() + "_" + categoryID.ToString() + "_" +
                         startRowIndex.ToString() + "_" + maximumRows.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogs = (List<Blog>)BizObject.Cache[key];
            }
            else
            {
                List<BlogDetails> recordset = SiteProvider.Blogs.GetPublishedBlogs(
                    categoryID, DateTime.Now,
                    GetPageIndex(startRowIndex, maximumRows), maximumRows);
                blogs = GetBlogListFromBlogDetailsList(recordset);
                BaseBlog.CacheData(key, blogs);
            }
            return blogs;
        }

        /// <summary>
        /// Returns a collection with all published blogs for the specified archive
        /// </summary>
        public static List<Blog> GetBlogs(bool publishedOnly, DateTime date)
        {
            return GetBlogs(publishedOnly, date, 0, BizObject.MAXROWS);
        }

        public static List<Blog> GetBlogs(bool publishedOnly, DateTime date, int startRowIndex, int maximumRows)
        {
            if (!publishedOnly)
                return GetBlogs(date, startRowIndex, maximumRows);

            //if (categoryID <= 0)
            //    return GetBlogs(publishedOnly, startRowIndex, maximumRows);

            List<Blog> blogs = null;
            string key = "Blogs_Blogs_" + publishedOnly.ToString() + "_" + date.ToString() + "_" +
                         startRowIndex.ToString() + "_" + maximumRows.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogs = (List<Blog>)BizObject.Cache[key];
            }
            else
            {
                List<BlogDetails> recordset = SiteProvider.Blogs.GetPublishedBlogs(
                    date, DateTime.Now,
                    GetPageIndex(startRowIndex, maximumRows), maximumRows);
                blogs = GetBlogListFromBlogDetailsList(recordset);
                BaseBlog.CacheData(key, blogs);
            }
            return blogs;
        }

        /// <summary>
        /// Increments an blog's view count
        /// </summary>
        public static bool IncrementBlogViewCount(int id)
        {
            return SiteProvider.Blogs.IncrementBlogViewCount(id);
        }

        public bool IncrementViewCount()
        {
            return Blog.IncrementBlogViewCount(Id);
        }

        /// <summary>
        /// Creates a new blog
        /// </summary>
        public static int InsertBlog(int categoryID, string blogTitle,
                                        string blogText, DateTime releaseDate,
                                        bool isPublished, bool isCommentsEnabled, bool isOnlyForMembers)
        {
            // ensure that the "approved" option is false if the current user is not
            // an administrator or a editor (it may be a contributor for example)
            bool canPublish = (BizObject.CurrentUser.IsInRole("Administrators") ||
                               BizObject.CurrentUser.IsInRole("Editors"));
            if (!canPublish)
                isPublished = false;

            blogTitle = BizObject.ConvertNullToEmptyString(blogTitle);
            blogText = BizObject.ConvertNullToEmptyString(blogText);

            if (releaseDate == DateTime.MinValue)
                releaseDate = DateTime.Now;
           
            BlogDetails record = new BlogDetails(0, DateTime.Now, BizObject.CurrentUserName,
                                                       categoryID, "", blogTitle, blogText, Excerpt(blogText),
                                                       releaseDate,
                                                       isPublished, isCommentsEnabled, isOnlyForMembers, 0);
            int ret = SiteProvider.Blogs.InsertBlog(record);

            BizObject.PurgeCacheItems("Blogs_Blog");
            try
            {
                TechnoratiUpdatePing();
            }
            catch
            {
            }
            return ret;
        }

        public bool Update()
        {
            return Blog.UpdateBlog(Id, CategoryID, CategoryTitle,
                                         BlogText, ReleaseDate, IsPublished, 
                                         IsCommentsEnabled, IsOnlyForMembers);
        }

        /// <summary>
        /// Updates an existing blog
        /// </summary>
        public static bool UpdateBlog(int id, int categoryID, string blogTitle,
                                         string blogText, 
                                         DateTime releaseDate, bool isPublished,
                                         bool isCommentsEnabled, bool isOnlyForMembers)
        {
            blogTitle = BizObject.ConvertNullToEmptyString(blogTitle);
            blogText = BizObject.ConvertNullToEmptyString(blogText);
            
            if (releaseDate == DateTime.MinValue)
                releaseDate = DateTime.Now;

            BlogDetails record = new BlogDetails(id, DateTime.Now, "", categoryID,
                                                       "",blogTitle,blogText, Excerpt(blogText), releaseDate,
                                                       isPublished, isCommentsEnabled, isOnlyForMembers, 0);
            bool ret = SiteProvider.Blogs.UpdateBlog(record);

            BizObject.PurgeCacheItems("Blogs_Blog_" + id.ToString());
            BizObject.PurgeCacheItems("Blogs_Blogs");
            try
            {
                TechnoratiUpdatePing();
            }
            catch
            {
            }
            return ret;
        }



		//�Private�Methods�(3)�

        /// <summary>
        /// Returns a Blog object filled with the data taken from the input BlogDetails
        /// </summary>
        private static Blog GetBlogFromBlogDetails(BlogDetails record)
        {

            if (record == null)
                return null;
            else
            {
                return (new Blog(record.Id, record.AddedDate, record.AddedBy,
                                      record.CategoryID, record.CategoryTitle, record.BlogTitle, record.BlogText, record.ExcerptBlogText,
                                       record.ReleaseDate, record.IsPublished, record.IsCommentsEnabled, record.IsOnlyForMembers,
                                       record.ViewCount));
            }
        }

        /// <summary>
        /// Returns a list of Blog objects filled with the data taken from the input list of BlogDetails
        /// </summary>
        private static List<Blog> GetBlogListFromBlogDetailsList(List<BlogDetails> recordset)
        {
            List<Blog> blogs = new List<Blog>();
            foreach (BlogDetails record in recordset)
            {
                blogs.Add(GetBlogFromBlogDetails(record));
            }
            return blogs;
        }

        private static List<Blog> GetBlogs(int startRowIndex, int maximumRows)
        {
            List<Blog> blogs = null;
            string key = "Blogs_Blogs_" + startRowIndex.ToString() + "_" + maximumRows.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                blogs = (List<Blog>)BizObject.Cache[key];
            }
            else
            {
                List<BlogDetails> recordset = SiteProvider.Blogs.GetBlogs(
                GetPageIndex(startRowIndex, maximumRows), maximumRows);
                blogs = GetBlogListFromBlogDetailsList(recordset);
                BaseBlog.CacheData(key, blogs);
            }
            return blogs;
        }


		#endregion�Methods�

    }
}
