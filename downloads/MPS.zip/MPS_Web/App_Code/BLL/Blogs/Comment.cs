using System;
using System.Collections.Generic;
using MPS.DAL;

namespace MPS.BLL.Blogs
{
    public class Comment : BaseBlog
    {

		#region�Fields�(7)�

        private string addedByEmail = "";
        private string addedByHomePage = "";
        private string addedByIP = "";
        private Blog blog = null;
        private int blogID = 0;
        private string blogTitle = "";
        private string commentText = "";

		#endregion�Fields�

		#region�Constructors�(1)�

        public Comment(int id, DateTime addedDate, string addedBy, string addedByEmail, string addedByHomePage,
                       string addedByIP, int blogID,string blogTitle, string commentText)
        {
            Id = id;
            AddedDate = addedDate;
            AddedBy = addedBy;
            AddedByEmail = addedByEmail;
            AddedByHomePage = addedByHomePage;
            AddedByIP = addedByIP;
            BlogID = blogID;
            BlogTitle = blogTitle;
            CommentText = commentText;
        }

		#endregion�Constructors�

		#region�Properties�(8)�

        public string AddedByEmail
        {
            get { return addedByEmail; }
            set { addedByEmail = value; }
        }

        public string AddedByHomePage
        {
            get { return addedByHomePage; }
            set { addedByHomePage = value; }
        }

        public string AddedByIP
        {
            get { return addedByIP; }
            set { addedByIP = value; }
        }

        public Blog Blog
        {
            get 
            {
                if (blog == null)
                    blog = Blog.GetBlogByID(BlogID);
                return blog; 
            }
        }

        public int BlogID
        {
            get { return blogID; }
            set { blogID = value; }
        }

        public string BlogTitle
        {
            get { return blogTitle; }
            set { blogTitle = value; }
        }

        public string CommentText
        {
            get { return commentText; }
            set { commentText = value; }
        }

        public string EncodedBody
        {
            get { return Helpers.ConvertToHtml(CommentText); }
        }

		#endregion�Properties�

		#region�Methods�(14)�


		//�Public�Methods�(12)�

        public bool Delete()
        {
            bool success = Comment.DeleteComment(Id);
            if (success)
                Id = 0;
            return success;
        }

        /// <summary>
        /// Deletes an existing comment
        /// </summary>
        public static bool DeleteComment(int id)
        {
            bool ret = SiteProvider.Blogs.DeleteComment(id);
            //new RecordDeletedEvent("comment", id, null).Raise();
            BizObject.PurgeCacheItems("Blogs_comment");
            return ret;
        }

        /// <summary>
        /// Returns a Comment object with the specified ID
        /// </summary>
        public static Comment GetCommentByID(int commentID)
        {
            Comment comment = null;
            string key = "Blogs_Comment_" + commentID.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                comment = (Comment)BizObject.Cache[key];
            }
            else
            {
                comment = GetCommentFromCommentDetails(SiteProvider.Blogs.GetCommentByID(commentID));
                BaseBlog.CacheData(key, comment);
            }
            return comment;
        }

        /// <summary>
        /// Returns the number of total comments
        /// </summary>
        public static int GetCommentCount()
        {
            int commentCount = 0;
            string key = "Blogs_CommentCount";

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                commentCount = (int)BizObject.Cache[key];
            }
            else
            {
                commentCount = SiteProvider.Blogs.GetCommentCount();
                BaseBlog.CacheData(key, commentCount);
            }
            return commentCount;
        }

        /// <summary>
        /// Returns the number of total comments for the specified blog
        /// </summary>
        public static int GetCommentCount(int blogID)
        {
            int commentCount = 0;
            string key = "Blogs_CommentCount_" + blogID.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                commentCount = (int)BizObject.Cache[key];
            }
            else
            {
                commentCount = SiteProvider.Blogs.GetCommentCount(blogID);
                BaseBlog.CacheData(key, commentCount);
            }
            return commentCount;
        }

        /// <summary>
        /// Returns a collection with all comments
        /// </summary>
        public static List<Comment> GetComments()
        {
            List<Comment> comments = GetComments(0, BizObject.MAXROWS);
            comments.Sort(new CommentComparer("AddedDate ASC"));
            return comments;
        }

        public static List<Comment> GetComments(int startRowIndex, int maximumRows)
        {
            List<Comment> comments = null;
            string key = "Blogs_Comments_" + startRowIndex.ToString() + "_" + maximumRows.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                comments = (List<Comment>)BizObject.Cache[key];
            }
            else
            {
                List<CommentDetails> recordset = SiteProvider.Blogs.GetComments(GetPageIndex(startRowIndex, maximumRows), maximumRows);
                comments = GetCommentListFromCommentDetailsList(recordset);
                BaseBlog.CacheData(key, comments);
            }
            return comments;
        }

        /// <summary>
        /// Returns a collection with all comments for the specified blog
        /// </summary>
        public static List<Comment> GetComments(int blogID)
        {
            List<Comment> comments = GetComments(blogID, 0, BizObject.MAXROWS);
            comments.Sort(new CommentComparer("AddedDate ASC"));
            return comments;
        }

        public static List<Comment> GetComments(int blogID, int startRowIndex, int maximumRows)
        {
            List<Comment> comments = null;
            string key = "Blogs_Comments_" + blogID.ToString() + "_" + startRowIndex.ToString() + "_" +
                         maximumRows.ToString();

            if (BaseBlog.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                comments = (List<Comment>)BizObject.Cache[key];
            }
            else
            {
                List<CommentDetails> recordset = SiteProvider.Blogs.GetComments(blogID,
                                                                                GetPageIndex(startRowIndex,maximumRows),
                                                                                maximumRows);
                comments = GetCommentListFromCommentDetailsList(recordset);
                BaseBlog.CacheData(key, comments);
            }
            return comments;
        }

        /// <summary>
        /// Creates a new comment
        /// </summary>
        public static int InsertComment(string addedBy, string addedByEmail, string addedByHomePage, int blogID, string commentText)
        {
            CommentDetails record = new CommentDetails(0, DateTime.Now, addedBy, addedByEmail, addedByHomePage, BizObject.CurrentUserIP, blogID, "", commentText);
            int ret = SiteProvider.Blogs.InsertComment(record);
            BizObject.PurgeCacheItems("Blogs_comment");
            return ret;
        }

        public bool Update()
        {
            return Comment.UpdateComment(Id, CommentText);
        }

        /// <summary>
        /// Updates an existing comment
        /// </summary>
        public static bool UpdateComment(int id, string commentText)
        {
            CommentDetails record = new CommentDetails(id, DateTime.Now, "", "", "", "", 0, "", commentText);
            bool ret = SiteProvider.Blogs.UpdateComment(record);
            BizObject.PurgeCacheItems("Blogs_comment");
            return ret;
        }



		//�Private�Methods�(2)�

        /// <summary>
        /// Returns a Comment object filled with the data taken from the input CommentDetails
        /// </summary>
        private static Comment GetCommentFromCommentDetails(CommentDetails record)
        {
            if (record == null)
                return null;
            else
            {
                return new Comment(record.Id, record.AddedDate, record.AddedBy,
                                   record.AddedByEmail, record.AddedByHomePage, record.AddedByIP,
                                   record.BlogId, record.BlogTitle, record.CommentText);
            }
        }

        /// <summary>
        /// Returns a list of Comment objects filled with the data taken from the input list of CommentDetails
        /// </summary>
        private static List<Comment> GetCommentListFromCommentDetailsList(List<CommentDetails> recordset)
        {
            List<Comment> comments = new List<Comment>();
            foreach (CommentDetails record in recordset)
                comments.Add(GetCommentFromCommentDetails(record));
            return comments;
        }


		#endregion�Methods�

		#region�Nested�Classes�(1)�


        /// <summary>
        /// Comparer class, to be used with List<Comment>.Sort
        /// </summary>
        public class CommentComparer : IComparer<Comment>
        {

		#region�Fields�(2)�

            private bool _reverse;
            private string _sortBy;

		#endregion�Fields�

		#region�Constructors�(1)�

            public CommentComparer(string sortBy)
            {
                if (!string.IsNullOrEmpty(sortBy))
                {
                    sortBy = sortBy.ToLower();
                    _reverse = sortBy.EndsWith(" desc");
                    _sortBy = sortBy.Replace(" desc", "").Replace(" asc", "");
                }
            }

		#endregion�Constructors�

		#region�Methods�(2)�


		//�Public�Methods�(2)�

            public int Compare(Comment x, Comment y)
            {
                int ret = 0;
                switch (_sortBy)
                {
                    case "addeddate":
                        ret = DateTime.Compare(x.AddedDate, y.AddedDate);
                        break;
                    case "addedby":
                        ret = string.Compare(x.AddedBy, y.AddedBy, StringComparison.InvariantCultureIgnoreCase);
                        break;
                }
                return (ret * (_reverse ? -1 : 1));
            }

            public bool Equals(Comment x, Comment y)
            {
                return (x.Id == y.Id);
            }


		#endregion�Methods�










        }
		#endregion�Nested�Classes�

    }
}
