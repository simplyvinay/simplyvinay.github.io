﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Principal;
using System.Web.Security;
using CookComputing.XmlRpc;

namespace MPS.BLL.Blogs
{
    public class MetaWeblog : XmlRpcService, IMetaWeblog
    {

		#region Constructors (1) 

        public MetaWeblog()
        {
        }

		#endregion Constructors 

		#region Methods (10) 


		// Private Methods (10) 

        string IMetaWeblog.AddPost(string blogid, string username, string password, Post post, bool publish)
        {
            if (ValidateUser(username, password))
            {
                if (Roles.IsUserInRole(username, "Administrators"))
                {
                    GenericIdentity gI = new GenericIdentity(username);
                    GenericPrincipal gP = new GenericPrincipal(gI, new string[] { "Administrators" });
                    this.Context.User = gP;
                }

                int id = 0;

                string catName = post.categories[0];

                List<Category> catList = Category.GetCategories();
                Category cat = catList.Find(delegate(Category c) { return c.Title == catName; });

                if (cat != null)
                {
                    id = Blog.InsertBlog(cat.Id, post.title, post.description, post.dateCreated, publish, true, false);
                }
                else
                {
                    int catId = Category.InsertCategory(catName, 0, catName);
                    if (catId > 0)
                    {
                        id = Blog.InsertBlog(catId, post.title, post.description, post.dateCreated, publish, true, false);
                    }
                    else
                        throw new XmlRpcFaultException(0, "Unable to Post");
                }

                return id.ToString();
            }
            throw new XmlRpcFaultException(0, "User is not valid!");
        }

        bool IMetaWeblog.DeletePost(string key, string postid, string username, string password, bool publish)
        {
            if (ValidateUser(username, password))
            {
                bool result = false;

                result = Blog.DeleteBlog(Convert.ToInt32(postid));

                return result;
            }
            throw new XmlRpcFaultException(0, "User is not valid!");
        }

        CategoryInfo[] IMetaWeblog.GetCategories(string blogid, string username, string password)
        {
            if (ValidateUser(username, password))
            {
                List<CategoryInfo> categoryInfos = new List<CategoryInfo>();

                List<Category> catList= Category.GetCategories();

                foreach (Category cat in catList)
                {
                    CategoryInfo c = new CategoryInfo();
                    c.categoryid = cat.Id.ToString();
                    c.description = cat.Description;
                    c.title = cat.Title;
                    c.htmlUrl = "http://www.simplyvinay.com/Category/" + cat.Id + "/Default.aspx";
                    c.rssUrl = "http://www.simplyvinay.com/GetBlogRss.aspx?CatID=" + cat.Id;
                    categoryInfos.Add(c);
                }

                return categoryInfos.ToArray();
            }
            throw new XmlRpcFaultException(0, "User is not valid!");
        }

        Post IMetaWeblog.GetPost(string postid, string username, string password)
        {
            if (ValidateUser(username, password))
            {
                Post post = new Post();

                Blog b = Blog.GetBlogByID(Convert.ToInt32(postid));

                post.postid = b.Id;
                post.categories = new string[] { b.CategoryTitle }; 
                post.dateCreated = b.AddedDate;
                post.description = b.BlogText;
                post.title = b.BlogTitle;
                post.userid = username;

                return post;
            }
            throw new XmlRpcFaultException(0, "User is not valid!");
        }

        Post[] IMetaWeblog.GetRecentPosts(string blogid, string username, string password, int numberOfPosts)
        {
            if (ValidateUser(username, password))
            {
                List<Post> posts = new List<Post>();

                List<Blog> blogList = Blog.GetBlogs(true, 0, numberOfPosts);

                foreach (Blog b in blogList)
                {
                    Post p = new Post();
                    p.categories = new string[] { b.CategoryTitle };
                    p.dateCreated = b.AddedDate;
                    p.description = b.BlogText;
                    p.postid = b.Id;
                    p.title = b.BlogTitle;
                    p.userid = username;

                    posts.Add(p);
                }

                return posts.ToArray();
            }
            throw new XmlRpcFaultException(0, "User is not valid!");
        }

        UserInfo IMetaWeblog.GetUserInfo(string key, string username, string password)
        {
            if (ValidateUser(username, password))
            {
                UserInfo info = new UserInfo();

                // TODO: Implement your own logic to get user info objects and set the info

                return info;
            }
            throw new XmlRpcFaultException(0, "User is not valid!");
        }

        [XmlRpcMethod("blogger.getUsersBlogs")]
        BlogInfo[] IMetaWeblog.GetUsersBlogs(string key, string username, string password)
        {
            if (ValidateUser(username, password))
            {
                List<BlogInfo> infoList = new List<BlogInfo>();

                BlogInfo bI = new BlogInfo();

                bI.blogid = "Vinay's Blog";
                bI.blogName = "Vinay's Blog";
                bI.url = "http://www.simplyvinay.com/Default.aspx";

                infoList.Add(bI);

                return infoList.ToArray();
            }
            throw new XmlRpcFaultException(0, "User is not valid!");
        }

        MediaObjectInfo IMetaWeblog.NewMediaObject(string blogid, string username, string password, MediaObject mediaObject)
        {
            if (ValidateUser(username, password))
            {
                MediaObjectInfo objectInfo = new MediaObjectInfo();

                String basePath = this.Context.Server.MapPath("~/images/blogimages/");
                String fixedName = mediaObject.name.Replace("/", "\\");
                FileInfo fi = new FileInfo(basePath + "\\" + fixedName);

                if (!fi.Exists)
                {
                    if (!fi.Directory.Exists)
                    {
                        fi.Directory.Create();
                    }
                    using (FileStream fs = fi.Create())
                    {
                        fs.Write(mediaObject.bits, 0, mediaObject.bits.Length);
                    }
                }

                objectInfo.url = "http://www.simplyvinay.com/images/blogimages/" + mediaObject.name.ToString();

                return objectInfo;
            }
            throw new XmlRpcFaultException(0, "User is not valid!");
        }

        bool IMetaWeblog.UpdatePost(string postid, string username, string password, Post post, bool publish)
        {
            if (ValidateUser(username, password))
            {
                bool result = false;
                
                string catName = post.categories[0];

                List<Category> catList = Category.GetCategories();
                Category cat = catList.Find(delegate(Category c) { return c.Description.Contains(catName); });

                if (cat != null)
                {
                    result = Blog.UpdateBlog(Convert.ToInt32(postid), cat.Id, post.title, post.description, post.dateCreated, publish, true, false);
                }
                else
                {
                    int catId = Category.InsertCategory(catName, 0, catName);
                    if (catId > 0)
                    {
                        result = Blog.UpdateBlog(Convert.ToInt32(postid), catId, post.title, post.description, post.dateCreated, publish, true, false);
                    }
                    else
                        throw new XmlRpcFaultException(0, "Unable to Post");
                }

                return result;
            }
            throw new XmlRpcFaultException(0, "User is not valid!");
        }

        private bool ValidateUser(string username, string password)
        {
            bool result = false;

            result = Membership.ValidateUser(username, password);

            return true;
        }


		#endregion Methods 

    }
}