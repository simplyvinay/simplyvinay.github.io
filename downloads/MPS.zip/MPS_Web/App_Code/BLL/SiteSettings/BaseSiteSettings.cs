﻿using System;

namespace MPS.BLL.SiteSettings
{
    public class BaseSiteSettings : BizObject
    {

		#region Fields (1) 

        private int id = 0;

		#endregion Fields 

		#region Properties (2) 

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        protected static SiteSettingsElement Settings
        {
            get
            {
                return Globals.Settings.SiteSettings;
            }
        }

		#endregion Properties 

		#region Methods (1) 


		// Protected Methods (1) 

        /// <summary>
        /// Cache the input data, if caching is enabled
        /// </summary>
        protected static void CacheData(string key, object data)
        {
            if (Settings.EnableCaching && data != null)
            {
                BizObject.Cache.Insert(key, data, null,
                                       DateTime.Now.AddSeconds(Settings.CacheDuration), TimeSpan.Zero);
            }
        }


		#endregion Methods 

    }
}
