﻿using System.Collections.Generic;
using MPS.DAL;

namespace MPS.BLL.SiteSettings
{
    public class SiteSettings : BaseSiteSettings
    {

		#region Fields (6) 

        private string footer = "";
        private string metaDescription = "";
        private string metaKeywords = "";
        private string siteName = "";
        private string sitePageTitle = "";
        private string siteSlogan = "";

		#endregion Fields 

		#region Constructors (1) 

        public SiteSettings(int id, string siteName, string siteSlogan, string sitePageTitle, string metaDescription, string metaKeywords, string footer)
        {
            Id = id;
            SiteName = siteName;
            SiteSlogan = siteSlogan;
            SitePageTitle = sitePageTitle;
            MetaDescription = metaDescription;
            MetaKeywords = metaKeywords;
            Footer = footer;
        }

		#endregion Constructors 

		#region Properties (6) 

        public string Footer
        {
            get { return footer; }
            set { footer = value; }
        }

        public string MetaDescription
        {
            get { return metaDescription; }
            set { metaDescription = value; }
        }

        public string MetaKeywords
        {
            get { return metaKeywords; }
            set { metaKeywords = value; }
        }

        public string SiteName
        {
            get { return siteName; }
            set { siteName = value; }
        }

        public string SitePageTitle
        {
            get { return sitePageTitle; }
            set { sitePageTitle = value; }
        }

        public string SiteSlogan
        {
            get { return siteSlogan; }
            set { siteSlogan = value; }
        }

		#endregion Properties 

		#region Methods (6) 


		// Public Methods (4) 

        /// <summary>
        /// Returns a collection with all Site settings
        /// </summary>
        public static List<SiteSettings> GetSiteSettings()
        {
            List<SiteSettings> siteSettings = null;
            List<SiteSettingsDetails> recordset = SiteProvider.SiteSettings.GetSiteSettings();
            siteSettings = GetSiteSettingsListFromSiteSettingsDetailsList(recordset);
            return siteSettings;
        }

        /// <summary>
        /// Returns site settings for specified ID
        /// </summary>
        public static SiteSettings GetSiteSettings(int siteID)
        {
            SiteSettings siteSettings = null;
            string key = "SiteSettings_SiteSettings_" + siteID.ToString();

            if (BaseSiteSettings.Settings.EnableCaching && BizObject.Cache[key] != null)
            {
                siteSettings = (SiteSettings)BizObject.Cache[key];
            }
            else
            {
                siteSettings = GetSiteSettingsFromSiteSettingsDetails(SiteProvider.SiteSettings.GetSiteSettingsByID(siteID));
                BaseSiteSettings.CacheData(key, siteSettings);
            }
            return siteSettings;
        }

        public bool Update()
        {
            return SiteSettings.UpdateSiteSettings(Id, SiteName, SiteSlogan, SitePageTitle, MetaDescription, MetaKeywords, Footer);
        }

        /// <summary>
        /// Updates site settings
        /// </summary>
        public static bool UpdateSiteSettings(int id, string siteName, string siteSlogan, string sitePageTitle, string metaDescription, string metaKeywords, string footer)
        {
            siteName = BizObject.ConvertNullToEmptyString(siteName);
            siteSlogan = BizObject.ConvertNullToEmptyString(siteSlogan);
            sitePageTitle = BizObject.ConvertNullToEmptyString(sitePageTitle);
            metaDescription = BizObject.ConvertNullToEmptyString(metaDescription);
            metaKeywords = BizObject.ConvertNullToEmptyString(metaKeywords);
            footer = BizObject.ConvertNullToEmptyString(footer);
            SiteSettingsDetails record = new SiteSettingsDetails(id, siteName, siteSlogan, sitePageTitle, metaDescription, metaKeywords, footer);
            bool ret = SiteProvider.SiteSettings.UpdateSiteSettings(record);
            BizObject.PurgeCacheItems("SiteSettings_SiteSetting");
            return ret;
        }



		// Private Methods (2) 

        /// <summary>
        /// Returns a SIteSettings object filled with the data taken from the input SiteSettingsDetails
        /// </summary>
        private static SiteSettings GetSiteSettingsFromSiteSettingsDetails(SiteSettingsDetails record)
        {
            if (record == null)
                return null;
            else
            {
                return new SiteSettings(record.Id, record.SiteName, record.SiteSlogan,
                                   record.SitePageTitle, record.MetaDescription,
                                   record.MetaKeywords,record.Footer);
            }
        }

        /// <summary>
        /// Returns a list of GuestBook objects filled with the data taken from the input list of GuestBookDetails
        /// </summary>
        private static List<SiteSettings> GetSiteSettingsListFromSiteSettingsDetailsList(List<SiteSettingsDetails> recordset)
        {
            List<SiteSettings> siteSettings = new List<SiteSettings>();
            foreach (SiteSettingsDetails record in recordset)
                siteSettings.Add(GetSiteSettingsFromSiteSettingsDetails(record));
            return siteSettings;
        }


		#endregion Methods 

    }
}
