﻿using System;

namespace MPS.DAL
{
    public class AlbumDetails
    {

		#region Fields (3) 

        private string caption = "";
        private int id = 0;
        private bool isPublic = true;

		#endregion Fields 

		#region Constructors (2) 

        public AlbumDetails(int id, string caption, bool isPublic)
        {
            Id = id;
            Caption = caption;
            IsPublic = isPublic;
        }

        public AlbumDetails()
        {
        }

		#endregion Constructors 

		#region Properties (3) 

        public string Caption
        {
            get { return caption; }
            set { caption = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public bool IsPublic
        {
            get { return isPublic; }
            set { isPublic = value; }
        }

		#endregion Properties 

    }
}
