﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace MPS.DAL.SqlClient
{
    public class SqlPhotoGalleryProvider : PhotoGalleryProvider
    {

		#region Methods (14) 


		// Public Methods (14) 

        /// <summary>
        /// Deletes a album
        /// </summary>
        public override bool DeleteAlbum(int albumID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_DeleteAlbum", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@AlbumID", SqlDbType.Int).Value = albumID;
                cn.Open();
                //always returning -1. Have to fix this
                //int ret = ExecuteNonQuery(cmd);
                //return (ret >= 1);
                int ret = Convert.ToInt32(ExecuteScalar(cmd));
                return (ret >= 1);
            }
        }

        /// <summary>
        /// Deletes a photo
        /// </summary>
        public override bool DeletePhoto(int photoID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_DeletePhoto", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@PhotoID", SqlDbType.Int).Value = photoID;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }

        /// <summary>
        /// Returns an existing album with the specified ID
        /// </summary>
        public override AlbumDetails GetAlbumByID(int albumID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_GetAlbumByID", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@AlbumID", SqlDbType.Int).Value = albumID;
                cn.Open();
                IDataReader reader = ExecuteReader(cmd, CommandBehavior.SingleRow);
                if (reader.Read())
                    return GetAlbumFromReader(reader);
                else
                    return null;
            }
        }

        /// <summary>
        /// Returns a collection with all the albums
        /// </summary>
        public override List<AlbumDetails> GetAlbums()
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_GetAlbums", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetAlbumCollectionFromReader(ExecuteReader(cmd));
            }
        }

        /// <summary>
        /// Retrieves the photo with the specified ID
        /// </summary>
        public override PhotoDetails GetPhotoByID(int photoID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_GetPhotoByID", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@PhotoID", SqlDbType.Int).Value = photoID;
                cn.Open();
                IDataReader reader = ExecuteReader(cmd, CommandBehavior.SingleRow);
                if (reader.Read())
                    return GetPhotoFromReader(reader);
                else
                    return null;
            }
        }

        /// <summary>
        /// Returns the total number of photos
        /// </summary>
        public override int GetPhotoCount()
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_GetPhotoCount", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return (int)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Returns the total number of photos for the specified album
        /// </summary>
        public override int GetPhotoCount(int albumID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_GetPhotoCountByAlbum", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@AlbumID", SqlDbType.Int).Value = albumID;
                cn.Open();
                return (int)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Retrieves all photos for the specified album
        /// </summary>
        public override List<PhotoDetails> GetPhotos(int albumID, int pageIndex, int pageSize)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_GetPhotosByAlbum", cn);
                cmd.Parameters.Add("@AlbumID", SqlDbType.Int).Value = albumID;
                cmd.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                cmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetPhotoCollectionFromReader(ExecuteReader(cmd));
            }
        }

        /// <summary>
        /// Returns a collection with all the public albums
        /// </summary>
        public override List<AlbumDetails> GetPublicAlbums()
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_GetPublicAlbums", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetAlbumCollectionFromReader(ExecuteReader(cmd));
            }
        }

        /// <summary>
        /// Increments the ViewCount of the specified photo
        /// </summary>
        public override bool IncrementPhotoViewCount(int photoID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_IncrementViewCount", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@PhotoID", SqlDbType.Int).Value = photoID;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }

        /// <summary>
        /// Inserts a album
        /// </summary>
        public override int InsertAlbum(AlbumDetails album)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_InsertAlbum", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Caption", SqlDbType.NVarChar).Value = album.Caption;
                cmd.Parameters.Add("@IsPublic", SqlDbType.Bit).Value = album.IsPublic;
                cmd.Parameters.Add("@AlbumID", SqlDbType.Int).Direction = ParameterDirection.Output;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (int)cmd.Parameters["@AlbumID"].Value;
            }
        }

        /// <summary>
        /// Adds a photo
        /// </summary>
        public override int InsertPhoto(PhotoDetails photo)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_InsertPhoto", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@AlbumID", SqlDbType.Int).Value = photo.AlbumId;
                cmd.Parameters.Add("@PhotoCaption", SqlDbType.NVarChar).Value = photo.PhotoCaption;
                cmd.Parameters.Add("@Location", SqlDbType.NText).Value = photo.Location;
                cmd.Parameters.Add("@PhotoID", SqlDbType.Int).Direction = ParameterDirection.Output;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (int)cmd.Parameters["@PhotoID"].Value;
            }
        }

        /// <summary>
        /// Updates a album
        /// </summary>
        public override bool UpdateAlbum(AlbumDetails album)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_UpdateAlbum", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@AlbumID", SqlDbType.Int).Value = album.Id;
                cmd.Parameters.Add("@Caption", SqlDbType.NVarChar).Value = album.Caption;
                cmd.Parameters.Add("@IsPublic", SqlDbType.Bit).Value = album.IsPublic;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }

        /// <summary>
        /// Updates a photo
        /// </summary>
        public override bool UpdatePhoto(PhotoDetails photo)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_PhotoGallery_UpdatePhoto", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@PhotoID", SqlDbType.Int).Value = photo.Id;
                cmd.Parameters.Add("@AlbumID", SqlDbType.Int).Value = photo.AlbumId;
                cmd.Parameters.Add("@PhotoCaption", SqlDbType.NVarChar).Value = photo.PhotoCaption;
                cmd.Parameters.Add("@Location", SqlDbType.NVarChar).Value = photo.Location;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }


		#endregion Methods 

    }
}
