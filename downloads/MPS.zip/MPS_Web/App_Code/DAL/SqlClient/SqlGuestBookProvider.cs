﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace MPS.DAL.SqlClient
{
    public class SqlGuestBookProvider : GuestBookProvider
    {

		#region Methods (6) 


		// Public Methods (6) 

        /// <summary>
        /// deletes a GuestBook entry
        /// </summary>
        public override bool DeleteGuestBook(int guestBookID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_GuestBook_DeleteGuestBook", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@GuestBookID", SqlDbType.Int).Value = guestBookID;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }

        /// <summary>
        /// Retrieves all GuestBook entries
        /// </summary>
        public override List<GuestBookDetails> GetGuestBook(int pageIndex, int pageSize)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_GuestBook_GetGuestBook", cn);
                cmd.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                cmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return GetGuestBookCollectionFromReader(ExecuteReader(cmd));
            }
        }

        /// <summary>
        /// Retrieves the GuestBook with the specified ID
        /// </summary>
        public override GuestBookDetails GetGuestBookByID(int guestBookID)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_GuestBook_GetGuestBookByID", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@GuestBookID", SqlDbType.Int).Value = guestBookID;
                cn.Open();
                IDataReader reader = ExecuteReader(cmd, CommandBehavior.SingleRow);
                if (reader.Read())
                    return GetGuestBookFromReader(reader);
                else
                    return null;
            }
        }

        /// <summary>
        /// Returns the total number of GuestBook entries
        /// </summary>
        public override int GetGuestBookCount()
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_GuestBook_GetGuestBookCount", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                return (int)ExecuteScalar(cmd);
            }
        }

        /// <summary>
        /// Inserts a new GuestBook
        /// </summary>
        public override int InsertGuestBook(GuestBookDetails guestBook)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_GuestBook_InsertGuestBook", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@AddedDate", SqlDbType.DateTime).Value = guestBook.AddedDate;
                cmd.Parameters.Add("@AddedBy", SqlDbType.NVarChar).Value = guestBook.AddedBy;
                cmd.Parameters.Add("@AddedByEmail", SqlDbType.NVarChar).Value = guestBook.AddedByEmail;
                cmd.Parameters.Add("@AddedByIP", SqlDbType.NVarChar).Value = guestBook.AddedByIP;
                cmd.Parameters.Add("@GuestBookText", SqlDbType.NVarChar).Value = guestBook.GuestBookText;
                cmd.Parameters.Add("@GuestBookID", SqlDbType.Int).Direction = ParameterDirection.Output;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (int)cmd.Parameters["@GuestBookID"].Value;
            }
        }

        /// <summary>
        /// Updates a GuestBook
        /// </summary>
        public override bool UpdateGuestBook(GuestBookDetails guestBook)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("mps_GuestBook_UpdateGuestBook", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@GuestBookID", SqlDbType.Int).Value = guestBook.Id;
                cmd.Parameters.Add("@GuestBookText", SqlDbType.NVarChar).Value = guestBook.GuestBookText;
                cn.Open();
                int ret = ExecuteNonQuery(cmd);
                return (ret == 1);
            }
        }


		#endregion Methods 

    }
}
