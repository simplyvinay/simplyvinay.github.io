﻿using System;
using System.Collections.Generic;
using System.Data;

namespace MPS.DAL
{
    public abstract class GuestBookProvider : DataAccess
    {

		#region Fields (1) 

        private static GuestBookProvider instance = null;

		#endregion Fields 

		#region Constructors (1) 

        public GuestBookProvider()
        {
            ConnectionString = Globals.Settings.GuestBook.ConnectionString;
            EnableCaching = Globals.Settings.GuestBook.EnableCaching;
            CacheDuration = Globals.Settings.GuestBook.CacheDuration;
        }

		#endregion Constructors 

		#region Properties (1) 

        /// <summary>
        /// Returns an instance of the provider type specified in the config file
        /// </summary>
        public static GuestBookProvider Instance
        {
            get 
            {
                if (instance == null)
                    instance = (GuestBookProvider)Activator.CreateInstance(Type.GetType(Globals.Settings.GuestBook.ProviderType));
                return instance; 
            }
        }

		#endregion Properties 

		#region Methods (8) 


		// Public Methods (6) 

        public abstract bool DeleteGuestBook(int guestBookID);

        // methods that work with guestBook
        public abstract List<GuestBookDetails> GetGuestBook(int pageIndex, int pageSize);

        public abstract GuestBookDetails GetGuestBookByID(int guestBookID);

        public abstract int GetGuestBookCount();

        public abstract int InsertGuestBook(GuestBookDetails guestBook);

        public abstract bool UpdateGuestBook(GuestBookDetails guestBook);



		// Protected Methods (2) 

        /// <summary>
        /// Returns a collection of GuestBookDetails objects with the data read from the input DataReader
        /// </summary>
        protected virtual List<GuestBookDetails> GetGuestBookCollectionFromReader(IDataReader reader)
        {
            List<GuestBookDetails> guestBook = new List<GuestBookDetails>();
            while (reader.Read())
                guestBook.Add(GetGuestBookFromReader(reader));
            return guestBook;
        }

        /// <summary>
        /// Returns a new GuestBookDetails instance filled with the DataReader's current record data
        /// </summary>
        protected virtual GuestBookDetails GetGuestBookFromReader(IDataReader reader)
        {
            return new GuestBookDetails(
                (int)reader["GuestBookID"],
                (DateTime)reader["AddedDate"],
                reader["AddedBy"].ToString(),
                reader["AddedByEmail"].ToString(),
                reader["AddedByIP"].ToString(),
                reader["GuestBookText"].ToString());
        }


		#endregion Methods 

    }
}
