using System;

namespace MPS.DAL
{
    public class CategoryDetails
    {

		#region�Fields�(6)�

        private string addedBy = "";
        private DateTime addedDate = DateTime.Now;
        private string description = "";
        private int id = 0;
        private int importance = 0;
        private string title = "";

		#endregion�Fields�

		#region�Constructors�(2)�

        public CategoryDetails(int id, DateTime addedDate, string addedBy, string title, int importance, string description)
        {
            Id = id;
            AddedDate = addedDate;
            AddedBy = addedBy;
            Title = title;
            Importance = importance;
            Description = description;
        }

        public CategoryDetails()
        {
        }

		#endregion�Constructors�

		#region�Properties�(6)�

        public string AddedBy
        {
            get { return addedBy; }
            set { addedBy = value; }
        }

        public DateTime AddedDate
        {
            get { return addedDate; }
            set { addedDate = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public int Importance
        {
            get { return importance; }
            set { importance = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

		#endregion�Properties�

    }
}
