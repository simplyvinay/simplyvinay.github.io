using System;
using System.Collections.Generic;
using System.Data;

namespace MPS.DAL
{
    public abstract class BlogsProvider : DataAccess
    {

		#region�Fields�(1)�

        private static BlogsProvider instance = null;

		#endregion�Fields�

		#region�Constructors�(1)�

        public BlogsProvider()
        {
            ConnectionString = Globals.Settings.Blogs.ConnectionString;
            EnableCaching = Globals.Settings.Blogs.EnableCaching;
            CacheDuration = Globals.Settings.Blogs.CacheDuration;
        }

		#endregion�Constructors�

		#region�Properties�(1)�

        /// <summary>
        /// Returns an instance of the provider type specified in the config file
        /// </summary>
        public static BlogsProvider Instance
        {
            get 
            {
                if (instance == null)
                    instance = (BlogsProvider)Activator.CreateInstance(Type.GetType(Globals.Settings.Blogs.ProviderType));
                return instance; 
            }
        }

		#endregion�Properties�

		#region�Methods�(42)�


		//�Public�Methods�(34)�

        public abstract bool ApproveBlog(int blogID);

        public abstract bool DeleteBlog(int blogID);

        public abstract bool DeleteCategory(int categoryID);

        public abstract bool DeleteComment(int commentID);

        public abstract List<String> GetArchive();

        public abstract string GetBlogBody(int blogID);

        public abstract BlogDetails GetBlogByID(int blogID);

        public abstract BlogDetails GetBlogByTitle(string blogTitle);

        public abstract int GetBlogCount();

        public abstract int GetBlogCount(int categoryID);

        public abstract int GetBlogCount(DateTime date);

        // methods that work with blogs
        public abstract List<BlogDetails> GetBlogs(int pageIndex, int pageSize);

        public abstract List<BlogDetails> GetBlogs(int categoryID, int pageIndex, int pageSize);

        public abstract List<BlogDetails> GetBlogs(DateTime date, int pageIndex, int pageSize);

        // methods that work with categories
        public abstract List<CategoryDetails> GetCategories();

        public abstract CategoryDetails GetCategoryByID(int categoryID);

        public abstract CommentDetails GetCommentByID(int commentID);

        public abstract int GetCommentCount();

        public abstract int GetCommentCount(int blogID);

        // methods that work with comments
        public abstract List<CommentDetails> GetComments(int pageIndex, int pageSize);

        public abstract List<CommentDetails> GetComments(int blogID, int pageIndex, int pageSize);

        public abstract int GetPublishedBlogCount(DateTime currentDate);

        public abstract int GetPublishedBlogCount(int categoryID, DateTime currentDate);

        public abstract int GetPublishedBlogCount(DateTime date, DateTime currentDate);

        public abstract List<BlogDetails> GetPublishedBlogs(DateTime currentDate, int pageIndex, int pageSize);

        public abstract List<BlogDetails> GetPublishedBlogs(int categoryID, DateTime currentDate, int pageIndex, int pageSize);

        public abstract List<BlogDetails> GetPublishedBlogs(DateTime date, DateTime currentDate, int pageIndex, int pageSize);

        public abstract bool IncrementBlogViewCount(int blogID);

        public abstract int InsertBlog(BlogDetails blog);

        public abstract int InsertCategory(CategoryDetails category);

        public abstract int InsertComment(CommentDetails comment);

        public abstract bool UpdateBlog(BlogDetails blog);

        public abstract bool UpdateCategory(CategoryDetails category);

        public abstract bool UpdateComment(CommentDetails comment);



		//�Protected�Methods�(8)�

        /// <summary>Returns a collection of BlogDetails objects with the
        /// data read from the input DataReader</summary>
        protected virtual List<BlogDetails> GetBlogCollectionFromReader(IDataReader reader)
        {
            return GetBlogCollectionFromReader(reader, true);
        }

        protected virtual List<BlogDetails> GetBlogCollectionFromReader(IDataReader reader, bool readBody)
        {
            List<BlogDetails> blogs = new List<BlogDetails>();
            while (reader.Read())
                blogs.Add(GetBlogFromReader(reader, readBody));
            return blogs;
        }

        /// <summary>Returns a new BlogDetails instance filled with the
        /// DataReader's current record data</summary>
        protected virtual BlogDetails GetBlogFromReader(IDataReader reader)
        {
            return GetBlogFromReader(reader, true);
        }

        protected virtual BlogDetails GetBlogFromReader(IDataReader reader, bool readBody)
        {
            BlogDetails blog = new BlogDetails(
               (int)reader["BlogID"],
               (DateTime)reader["AddedDate"],
               reader["AddedBy"].ToString(),
               (int)reader["CategoryID"], 
               reader["CategoryTitle"].ToString(),
               reader["BlogTitle"].ToString(),
               reader["BlogText"].ToString(),
               reader["ExcerptBlogText"].ToString(),
               (reader["ReleaseDate"] == DBNull.Value ? DateTime.Now : (DateTime) reader["ReleaseDate"]),
               (bool)reader["isPublished"],
               (bool)reader["isCommentsEnabled"],
               (bool)reader["isOnlyForMembers"],
               (int)reader["ViewCount"]
               );

            if (readBody)
                blog.BlogText = reader["BlogText"].ToString();

            return blog;
        }

        /// <summary>
        /// Returns a collection of CategoryDetails objects with the data read from the input DataReader
        /// </summary>
        protected virtual List<CategoryDetails> GetCategoryCollectionFromReader(IDataReader reader)
        {
            List<CategoryDetails> categories = new List<CategoryDetails>();
            while (reader.Read())
                categories.Add(GetCategoryFromReader(reader));
            return categories;
        }

        /// <summary>
        /// Returns a new CategoryDetails instance filled with the DataReader's current record data
        /// </summary>
        protected virtual CategoryDetails GetCategoryFromReader(IDataReader reader)
        {
            return new CategoryDetails(
                (int)reader["CategoryID"],
                (DateTime)reader["AddedDate"],
                reader["AddedBy"].ToString(),
                reader["Title"].ToString(),
                (int)reader["Importance"],
                reader["Description"].ToString());
        }

        /// <summary>
        /// Returns a collection of CommentDetails objects with the data read from the input DataReader
        /// </summary>
        protected virtual List<CommentDetails> GetCommentCollectionFromReader(IDataReader reader)
        {
            List<CommentDetails> comments = new List<CommentDetails>();
            while (reader.Read())
                comments.Add(GetCommentFromReader(reader));
            return comments;
        }

        /// <summary>
        /// Returns a new CommentDetails instance filled with the DataReader's current record data
        /// </summary>
        protected virtual CommentDetails GetCommentFromReader(IDataReader reader)
        {
            return new CommentDetails(
                (int)reader["CommentID"],
                (DateTime)reader["AddedDate"],
                reader["AddedBy"].ToString(),
                reader["AddedByEmail"].ToString(),
                reader["AddedByHomePage"].ToString(),
                reader["AddedByIP"].ToString(),
                (int)reader["BlogID"],
                reader["BlogTitle"].ToString(),
                reader["CommentText"].ToString());
        }


		#endregion�Methods�

    }
}
