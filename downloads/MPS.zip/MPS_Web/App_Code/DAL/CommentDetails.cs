using System;

namespace MPS.DAL
{
    public class CommentDetails
    {

		#region�Fields�(9)�

        private string addedBy = "";
        private string addedByEmail = "";
        private string addedByHomePage = "";
        private string addedByIP = "";
        private DateTime addedDate = DateTime.Now;
        private int blogId = 0;
        private string blogTitle = "";
        private string commentText = "";
        private int id = 0;

		#endregion�Fields�

		#region�Constructors�(2)�

        public CommentDetails(int id, DateTime addedDate, string addedBy, string addedByEmail,string addedByHomePage, string addedByIP, int blogId,string blogTitle, string commentText)
        {
            Id = id;
            AddedDate = addedDate;
            AddedBy = addedBy;
            AddedByEmail = addedByEmail;
            AddedByHomePage = addedByHomePage;
            AddedByIP = addedByIP;
            BlogId = blogId;
            BlogTitle = blogTitle;
            CommentText = commentText;
        }

        public CommentDetails()
        {
        }

		#endregion�Constructors�

		#region�Properties�(9)�

        public string AddedBy
        {
            get { return addedBy; }
            set { addedBy = value; }
        }

        public string AddedByEmail
        {
            get { return addedByEmail; }
            set { addedByEmail = value; }
        }

        public string AddedByHomePage
        {
            get { return addedByHomePage; }
            set { addedByHomePage = value; }
        }

        public string AddedByIP
        {
            get { return addedByIP; }
            set { addedByIP = value; }
        }

        public DateTime AddedDate
        {
            get { return addedDate; }
            set { addedDate = value; }
        }

        public int BlogId
        {
            get { return blogId; }
            set { blogId = value; }
        }

        public string BlogTitle
        {
            get { return blogTitle; }
            set { blogTitle = value; }
        }

        public string CommentText
        {
            get { return commentText; }
            set { commentText = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

		#endregion�Properties�

    }
}
