﻿using System;
using System.Collections.Generic;
using System.Data;

namespace MPS.DAL
{
    public abstract class SiteSettingsProvider : DataAccess
    {

		#region Fields (1) 

        private static SiteSettingsProvider instance = null;

		#endregion Fields 

		#region Constructors (1) 

        public SiteSettingsProvider()
        {
            ConnectionString = Globals.Settings.SiteSettings.ConnectionString;
        }

		#endregion Constructors 

		#region Properties (1) 

        /// <summary>
        /// Returns an instance of the provider type specified in the config file
        /// </summary>
        public static SiteSettingsProvider Instance
        {
            get
            {
                if (instance == null)
                    instance = (SiteSettingsProvider)Activator.CreateInstance(Type.GetType(Globals.Settings.SiteSettings.ProviderType));
                return instance;
            }
        }

		#endregion Properties 

		#region Methods (5) 


		// Public Methods (3) 

        // methods that work with site settings
        public abstract List<SiteSettingsDetails> GetSiteSettings();

        public abstract SiteSettingsDetails GetSiteSettingsByID(int siteID);

        //public abstract bool DeleteSiteSettings(int siteID);
        public abstract bool UpdateSiteSettings(SiteSettingsDetails siteSettings);



		// Protected Methods (2) 

        //public abstract int InsertSiteSettings(SiteSettingsDetails siteSettings);
        /// <summary>
        /// Returns a collection of SiteSettingsDetails objects with the data read from the input DataReader
        /// </summary>
        protected virtual List<SiteSettingsDetails> GetSiteSettingsCollectionFromReader(IDataReader reader)
        {
            List<SiteSettingsDetails> siteSettings = new List<SiteSettingsDetails>();
            while (reader.Read())
                siteSettings.Add(GetSiteSettingsFromReader(reader));
            return siteSettings;
        }

        /// <summary>
        /// Returns a new SiteSettingsDetails instance filled with the DataReader's current record data
        /// </summary>
        protected virtual SiteSettingsDetails GetSiteSettingsFromReader(IDataReader reader)
        {
            return new SiteSettingsDetails(
                (int)reader["SiteID"],
                reader["SiteName"].ToString(),
                reader["SiteSlogan"].ToString(),
                reader["SitePageTitle"].ToString(),
                reader["MetaDescription"].ToString(),
                reader["MetaKeywords"].ToString(),
                reader["Footer"].ToString());
        }


		#endregion Methods 

    }
}
